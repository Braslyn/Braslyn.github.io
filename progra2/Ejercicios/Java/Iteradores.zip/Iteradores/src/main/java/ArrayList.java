public class ArrayList<T> implements list<T>{
    private int cant;
    private Object[] array;
    private int tam=100;

    public ArrayList(){
        cant=0;
        array=new Object[tam];
    }

    public T get(int pos) {
        return (T) array[pos];
    }

    @Override
    public int count() {
        return cant;
    }

    @Override
    public iterador<T> createIterator() {
        return new IteradorArray<T>(this);
    }

    @Override
    public void add(T data) {
        if(cant<tam){
            array[cant++]=data;
            return ;
        }
        tam+=10;
        Object[] aux= new Object[tam];
        for (int i=0;i<cant;i++){
            aux[i]=array[i];
        }
        array=aux;
    }



}
