public interface list <T>{
    public int count();
    public void add(T data);
    public iterador<T> createIterator();
}
