public class IteradorLinkedList<T> implements iterador<T>{

    private final Nodo<T> finalnode;
    private Nodo<T> currentnode;

    public IteradorLinkedList(LinkedList<T> list){
        currentnode=list.get(0);
        finalnode=list.get(list.count());
    }
    @Override
    public void next() {
        if(currentnode!=finalnode)
            currentnode = currentnode.getNext();
    }
    @Override
    public T current() {
        return currentnode.getData();
    }
    @Override
    public boolean isDone() {
        return currentnode==finalnode;
    }
}
