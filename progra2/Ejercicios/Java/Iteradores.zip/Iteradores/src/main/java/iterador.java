public interface iterador<T> {
   public T current();
   public void next();
   public  boolean isDone();
}
