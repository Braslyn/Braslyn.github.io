import java.util.stream.*;

public class Ejemplo {

    public static void main(String[] args){
        System.out.println("Lista de punteros");
        LinkedList<Integer> lista= new LinkedList<>();
        for (int i=10;i>0;i--) {
            lista.add(i);
        }
        var iterador= lista.createIterator();
        while (!iterador.isDone()){
            System.out.println(iterador.current());
            iterador.next();
        }

        System.out.println("Lista de array");

        ArrayList<Integer> lista2= new ArrayList<>();
        for (int i=10;i>0;i--) {
            lista2.add(i);
        }

    }

}
