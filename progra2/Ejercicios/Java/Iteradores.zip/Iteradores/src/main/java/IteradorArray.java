public class IteradorArray<T> implements iterador<T>{

    private Object[] array;
    private T Final;
    public IteradorArray(ArrayList list){
        //array = list.get(0);
        //Final = list.get(list.count()-1);
    }

    @Override
    public boolean isDone() {
        return false;
    }

    @Override
    public T current() {
        return null;
    }

    @Override
    public void next() {

    }
}
