public class LinkedList<T> implements list<T> {
    private int cant;
    private Nodo<T> primer;

    public LinkedList(){
        cant=0;
        primer=null;
    }

    public Nodo<T> get(int pos) {
        if(!isEmpty()) {
            if (pos >= 0 && pos < cant) {
                Nodo<T> aux = primer;
                while (pos-- != 0) {
                    aux = aux.getNext();
                }
                return aux;
            }
        }
        return null;
    }

    @Override
    public int count() {
        return cant;
    }

    @Override
    public iterador<T> createIterator() {
        return new IteradorLinkedList<>(this);
    }

    @Override
    public void add(T data) {
        if (isEmpty()){
            primer = new Nodo<>(data, null);
            cant++;
            return ;
        }
        Nodo<T> aux = primer;
        while(aux.getNext() != null) {
            aux = aux.getNext();
        }
        cant++;
        aux.setNext(new Nodo<>(data, null));

    }

    private boolean isEmpty(){
        return primer==null;
    }

}
