public class Prueba {

    public static void main(String[] args){
        List<Integer> lista= new List<Integer>();
        for(var x=10;x>0;x--)
            lista.add(x);
        System.out.println(lista.toString());
    }

}
