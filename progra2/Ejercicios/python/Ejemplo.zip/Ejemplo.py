from functools import reduce

class Iterador:
    def __init__(self,rango):#Constrcutor
        self.__rango=rango

    def __repr__(self)->str:#toString
        return f"Iterador hasta {self.__rango}"

    def __iter__(self)->int:#faceta iterable
        for x in range(1,self.__rango):
            yield x

    def getRango(self)->int:
        return self.__rango
    def setRango(self,rango)->None:
        self.__rango=rango



def sumList(lista):
    var=0
    for x in lista:
        var+=x
    return var

def sumListR(lista):
    if len(lista)==0:
        return 0
    return lista[0]+sumListR(lista[1:])

def sumListRC(lista,cola):
    if len(lista)==0:
        return cola
    return sumListRC(lista[1:],cola+lista[0])

def sumListDV(lista):
    return reduce(lambda x,y:x+y,lista,0)

if __name__=="__main__":
    """a=Iterador(10)
    for x in a:
        print(x,end=",")"""
    #with open("success.html",'r') as file:
    #    print(file.read().split("\n"))
    print(f"sumList([1,2,3])={sumList([1,2,3])}\nsumListR([1,2,3])={sumListR([1,2,3])}\nsumListRC([1,2,3],0)={sumListRC([1,2,3],0)}\nsumListDV([1,2,3])={sumListDV([1,2,3])}")