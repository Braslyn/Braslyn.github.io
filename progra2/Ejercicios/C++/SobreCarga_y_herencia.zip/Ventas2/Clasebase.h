#ifndef CLASEBASE_H
#define CLASEBASE_H
#include <iostream>
class ClaseBase{
public:
	ClaseBase(double din,double imp);
	~ClaseBase();
	double getDinero();
	double getImpuesto();
	virtual double pagar() = 0;
protected:
	double dinero;
	double impuesto;
};

#endif // !CLASEBASE_H

