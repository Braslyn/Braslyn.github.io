#include "Ventas.h"

Venta::Venta(std::string n, double d, double i):ClaseBase(d,i),nombre(n){}

Venta::~Venta(){}

std::string Venta::getNombre()
{
	return nombre;
}

double Venta::pagar()
{
	return dinero/impuesto;
}

Venta* Venta::operator+(ClaseBase& cb){
	return new Venta(this->nombre+"0",this->dinero+cb.getDinero(),this->impuesto+cb.getImpuesto());
}

std::ostream& operator<<(std::ostream& out, Venta* v)
{
	out << "Venta " << v->nombre << "\n";
	out << "Dinero: " << v->dinero << ", Impuesto" << v->impuesto << "\n";
	return out;
}
