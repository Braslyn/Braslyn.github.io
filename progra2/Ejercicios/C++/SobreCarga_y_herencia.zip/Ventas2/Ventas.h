#ifndef VENTAS_H
#define VENTAS_H
#include "Clasebase.h"
#include <string>
class Venta :public ClaseBase {
public:
	Venta(std::string n, double d, double i);
	~Venta();
	std::string getNombre();
	double pagar();
	Venta* operator+(ClaseBase& cb);
	friend std::ostream& operator<<(std::ostream& out, Venta* );
private:
	std::string nombre;
};

#endif // !BANCO_H
