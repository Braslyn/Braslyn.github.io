#include "Banco.h"

Banco::Banco(std::string n, double d, double i):ClaseBase(d,i),nombre(n){}

Banco::~Banco(){}

std::string Banco::getNombre()
{
    return nombre;
}

double Banco::pagar(){
    return this->getDinero()*this->getImpuesto();
}

Banco* Banco::operator+(ClaseBase& cb){
    return new Banco(this->nombre, this->dinero+cb.getDinero(),this->impuesto+cb.getImpuesto());
}

std::ostream& operator<<(std::ostream& out, Banco* b){
    out << "Banco " << b->nombre << "\n";
    out << "Dinero: " << b->dinero << ", Impuesto" << b->impuesto<<"\n";
    return out;
}
