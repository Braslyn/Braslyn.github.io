#ifndef BANCO_H
#define BANCO_H
#include "Clasebase.h"
#include <string>
class Banco:public ClaseBase{
public:
	Banco(std::string n,double d,double i);
	~Banco();
	std::string getNombre();
	double pagar();
	Banco* operator+(ClaseBase& cb);
	friend std::ostream& operator<<(std::ostream& out, Banco*);
private:
	std::string nombre;
};

#endif // !BANCO_H
