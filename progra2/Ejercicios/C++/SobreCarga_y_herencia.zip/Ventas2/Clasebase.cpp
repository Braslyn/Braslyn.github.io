#include "Clasebase.h"

ClaseBase::ClaseBase(double din, double imp):dinero(din),impuesto(imp){}

ClaseBase::~ClaseBase(){}

double ClaseBase::getDinero()
{
	return dinero;
}

double ClaseBase::getImpuesto()
{
	return impuesto;
}
