#include "Ventas.h"
#include "Banco.h"
#include <vector>//STL -> list , colas , pilas

int main() {
	std::vector<ClaseBase&> list;
	Banco x("xtv", 50, 1);
	Banco y("tv", 25, 2);
	Venta z("Pali", 100, 2.5);
	Venta a("El chino", 10, 0.5);
	std::cout<<x + y;
	list.push_back(*(y+x));
	list.push_back(*(z + x));
	list.push_back(*(a + x));
	list.push_back(*(y + a));
    std::cout<<&dynamic_cast<Banco&>(list[0]);
	std::cout << &dynamic_cast<Venta&>(list[2]);
	return 0;
}