#ifndef LISTA_H
#define LISTA_H
#include "Nodo.h"

using std::string;//using namespace std;
template<class T>
class Lista{
public:
	Lista();
	~Lista();
	static Nodo<T>* Crearnodo(T x);
	void operator+(T& x);
	void operator+(T* x);
	void insertar(Nodo<T>& nodo);
	void borrar(int num);
	T* get(int pos);//to do
	T* operator[](int pos);
	void BorrarTodo();
	void swap(int pos1,int pos2);
	bool IsEmpty();
	string toString();// muy java
	template<class U>
	friend std::ostream& operator<<(std::ostream& out, Lista<U>& lista);
private:
	Nodo<T>* primero;
	int cant;
};

#endif // !LISTA_H
