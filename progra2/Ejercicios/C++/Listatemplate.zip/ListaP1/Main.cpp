#include "Lista.h"
#include "Lista.cpp"
#include <iostream>
#include <memory>
int main() {
	Lista<int> lista;
	for (auto i = 0; i < 10; i++){
		lista + i;
	}
	std::cout << lista;
	return 0;
}