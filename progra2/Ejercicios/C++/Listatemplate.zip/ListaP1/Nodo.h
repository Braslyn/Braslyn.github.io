#ifndef NODO_H
#define NODO_H
#include <string>
#include <sstream>

template<class T>
struct Nodo{
	T data;
	Nodo* next;
	Nodo(T& elemento, Nodo* n=nullptr):data(elemento), next(n){}
	//get,set ?
};
//[X|*]->[Nodo]
#endif // !NODO_H
