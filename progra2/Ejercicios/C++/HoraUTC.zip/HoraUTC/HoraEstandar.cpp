#include "HoraEstandar.h"

HoraEstandar::HoraEstandar(){}

HoraEstandar::~HoraEstandar(){
}

std::string HoraEstandar::Encabezado(){
	return "Hora Estandar\n";
}

std::string HoraEstandar::Mostrar(Hora* h){
	std::stringstream out;
	out << h->getHora() << ":" << h->getMinutos() << ":" << h->getSegundos() << " " << h->getAmPm()<<"\n";
	return out.str();
}
