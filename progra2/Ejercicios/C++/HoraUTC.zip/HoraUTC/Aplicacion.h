#ifndef APLICACION_H
#define APLICACION_H
#include "HoraEstandar.h"
#include "HoraMilitar.h"
#include <memory>
class Aplicacion{
public:
	Aplicacion();
	~Aplicacion();
	Hora* getHora();
	void InsertarHora(Hora&);
	std::string imprimeEnFormato(FormatoDeHora& formato);
private:
	std::unique_ptr<Hora> hora;
}; // 

#endif // !APLICACION
