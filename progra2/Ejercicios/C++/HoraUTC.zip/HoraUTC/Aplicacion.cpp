#include "Aplicacion.h"

Aplicacion::Aplicacion():hora(std::make_unique<Hora>(new Hora())){}

Aplicacion::~Aplicacion(){}

Hora* Aplicacion::getHora(){
	return hora.get();
}

void Aplicacion::InsertarHora(Hora& h){
	hora = std::make_unique<Hora>(new Hora(h));
}

std::string Aplicacion::imprimeEnFormato(FormatoDeHora& formato){
	std::stringstream out;
	out << "imprimiendo en " << formato.Encabezado();
	out << "Hora: " << formato.Mostrar(hora.get());
	return  out.str();
}
