#include "Aplicacion.h"
#include <iostream>
int main() {
	Aplicacion ap;
	ap.InsertarHora(*new Hora(5, 40, 8, "pm"));
	std::cout<<ap.imprimeEnFormato(*new HoraMilitar());
	return 0;
}