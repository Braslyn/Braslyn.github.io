#ifndef HORA_H
#define HORA_H
#include <string>
#include <sstream>

class Hora{
public:
	Hora(int hora=0,int min=0,int seg=0,std::string AmPm="");
	Hora(Hora* hora);
	int getHora();
	int getMinutos();
	int getSegundos();
	std::string getAmPm();
	~Hora();
private:
	int hora;
	int min;
	int seg;
	std::string AmPm;
};

#endif // !HORA_H
