#ifndef HORAMILITAR_H
#define HORAMILITAR_H
#include "FormatoDeHora.h"
class HoraMilitar : public FormatoDeHora{
public:
	HoraMilitar();
	~HoraMilitar();
	std::string Encabezado();
	std::string Mostrar(Hora*);
};

#endif // !HORAMILITAR_H
