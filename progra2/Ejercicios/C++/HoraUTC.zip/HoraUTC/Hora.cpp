#include "Hora.h"

Hora::Hora(int hora, int min, int seg, std::string AmPm):hora(hora),min(min),seg(seg),AmPm(AmPm){}

Hora::Hora(Hora* hora):hora(hora->hora),min(hora->min),seg(hora->seg),AmPm(hora->AmPm){}

int Hora::getHora(){
	return hora;
}

int Hora::getMinutos()
{
	return min;
}

int Hora::getSegundos()
{
	return seg;
}

std::string Hora::getAmPm()
{
	return AmPm;
}

Hora::~Hora(){}
