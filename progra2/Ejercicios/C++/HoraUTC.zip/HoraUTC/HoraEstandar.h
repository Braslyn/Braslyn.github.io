#ifndef HORAESTANDAR_H
#define HORAESTANDAR_H
#include "FormatoDeHora.h"

class HoraEstandar :public FormatoDeHora{
public:
	HoraEstandar();
	~HoraEstandar();
	std::string Encabezado();
	std::string Mostrar(Hora*);
};
#endif // !HORAESTANDAR_H
