#include "HoraMilitar.h"

HoraMilitar::HoraMilitar()
{
}

HoraMilitar::~HoraMilitar()
{
}

std::string HoraMilitar::Encabezado()
{
	return "Hora Militar\n";
}

std::string HoraMilitar::Mostrar(Hora* h){
	std::stringstream out;
	if (h->getAmPm() == "am" || h->getAmPm() == "AM") {
		out << h->getHora() << ":" << h->getMinutos() << ":" << h->getSegundos() << "\n";
	}else{
		out << 12+h->getHora()<< ":" << h->getMinutos() << ":" << h->getSegundos()<<"\n";
	}

	return out.str();
}
