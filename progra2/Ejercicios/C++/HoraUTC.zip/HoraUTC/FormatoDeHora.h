#ifndef FORMATODEHORA_H
#define FORMATODEHORA_H
#include "Hora.h"

class FormatoDeHora{
public:
	virtual std::string Encabezado()=0;
	virtual std::string Mostrar(Hora*)=0;
};
#endif // !FORMATODEHORA_H
