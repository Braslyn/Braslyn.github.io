#include "Jugador.h"

int main() {
	Jugador j1;
	std::cout << j1.getx()<<"\t";
	j1.setx(30);
	Jugador j2("Ana");
	std::cout << j2.getx()<<"\n";
	Jugador* vec[2];
	vec[0] = &j1;
	vec[1] = &j2;
	int j, k;
	for (short int i = 0; Gato::getInstance()->win() == ' ';i++){
		std::cout << *vec[i % 2];
		std::cout << "Digite la fila";
		std::cin >> j;
		std::cout << "Digite la columna";
		std::cin >> k;
		vec[i % 2]->jugar(j,k);
	}
	std::cout << "Juego termino\n" << Gato::getInstance();
	return 0;
}