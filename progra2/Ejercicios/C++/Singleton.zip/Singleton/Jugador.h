#ifndef JUGADOR_H
#define JUGADOR_H
#include "Gato.h"


static int x = 21;
class Jugador{
public:
	Jugador(std::string nom="Paco");
	~Jugador();
	std::string getNombre();
	int getMark();
	bool jugar(int,int);
	static int getx();
	static void setx(int y);
	friend std::ostream& operator<<(std::ostream& out, Jugador& jug);
private:
	std::string nombre;
	int mark;
};


#endif // !JUGADOR
