#ifndef GATO_H
#define GATO_H
#include <iostream>
#include <string>
#include <sstream>



class Gato{
public:
	~Gato();
	static Gato* getInstance();
	bool select(int i,int j,int x);
	int getmark();
	char campo(int i,int j);
	char win();

	friend std::ostream& operator<<(std::ostream& out, Gato* gato);
	friend std::ostream& operator<<(std::ostream& out, Gato& gato);
private:
	Gato();
	char** matrix;
	char xo[2];
	int get;
	static Gato* instance;
};

#endif // !GATO_H
