#include "Jugador.h"


Jugador::Jugador(std::string nom):nombre(nom){
	mark = Gato::getInstance()->getmark();
}

Jugador::~Jugador(){}
std::string Jugador::getNombre(){
	return nombre;
}
int Jugador::getMark()
{
	return mark;
}
bool Jugador::jugar(int i, int j){
	return Gato::getInstance()->select(i,j,mark);
}

int Jugador::getx()
{
	return x;
}

void Jugador::setx(int y)
{
	x = y;
}
std::ostream& operator<<(std::ostream& out, Jugador& jug){
	out << "Turno de Jugador " << jug.getNombre()<<" juega con '"<<jug.getMark()<<"'\n";
	out << Gato::getInstance();
	return out;
}
