#include "Gato.h"

Gato* Gato::instance = nullptr;

Gato::Gato():get(0),matrix(new char*[3]){
    for (short int i = 0; i < 3; i++)
        matrix[i] = new char[3];
    for (short int i = 0; i < 3; i++)
        for (short int j = 0; j < 3; j++)
            matrix[i][j] = ' ';
    xo[0] = 'x';
    xo[1] = 'o';
}
Gato::~Gato(){
}

Gato* Gato::getInstance(){
    if (!instance)
        instance = new Gato();
    return instance;
}

bool Gato::select(int i, int j, int x){
    return matrix[i][j]= xo[x];
}

int Gato::getmark(){
    return get++;
}

char Gato::campo(int i, int j)
{
    return matrix[i][j];
}

char Gato::win(){
    char m = matrix[0][0];
    for (int i = 1; i < 3; i++){
        if (matrix[i][i] != m)
            return ' ';
    }
    return m;
}


std::ostream& operator<<(std::ostream& out, Gato* gato){
    out << "Juego de Gato\n";
    for (short int i = 0; i < 3; i++){
        for (short int j = 0; j < 3; j++)
            out << gato->campo(i,j)<<" ";
        out << "\n";
    }
    return out;
}

std::ostream& operator<<(std::ostream& out, Gato& gato)
{
    out << "Juego de Gato\n";
    for (short int i = 0; i < 3; i++) {
        for (short int j = 0; j < 3; j++)
            out << gato.campo(i,j) << " ";
        out << "\n";
    }
    return out;
}
