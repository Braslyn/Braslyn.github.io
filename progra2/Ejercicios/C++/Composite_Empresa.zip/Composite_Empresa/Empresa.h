#ifndef EMPRESA_H
#define EMPRESA_H
#include <iostream>
#include <string>
#include <sstream>
using std::string;
class Empresa
{
public:
	Empresa(int cod=1, string nom="ep");
	~Empresa();
	string getNombre();
	int getCodigo();
	virtual double Salario() = 0;
	virtual string toString()=0;
protected:
	string nombre;
	int codigo;
};

#endif // !EMPRESA_H

