#include "Apartamento.h"

Apartamento::Apartamento(int cod, string nom):Edificio(cod,nom){}

Apartamento::~Apartamento(){}

string Apartamento::toString(){
	std::stringstream out;
	out << "--------------------------------------------\n";
	out << "Apartamento " << this->getNombre() << " codigo: " << this->getCodigo() << "\n";
	out << "Empleados y subpartes:\n";
	for (unsigned short int i = 0; i < list.size(); i++) {
		out << list[i]->toString()<< "\n";
		out << "*****************************\n";
	}
	out << "--------------------------------------------\n";
	return out.str();
}
