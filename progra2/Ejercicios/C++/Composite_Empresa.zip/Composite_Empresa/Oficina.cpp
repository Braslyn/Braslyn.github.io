#include "Oficina.h"

Oficina::Oficina(int cod, string nombre):Edificio(cod,nombre){}

Oficina::~Oficina(){}

string Oficina::toString(){
	std::stringstream out;
	out << "--------------------------------------------\n";
	out << "Oficina " << this->getNombre() << " codigo: " << this->getCodigo() << "\n";
	out << "Empleados y subpartes:\n";
	for (unsigned short int  i = 0; i < list.size(); i++){
		out << list[i]->toString() <<"\n";
		out << "*****************************\n";
	}
	out << "--------------------------------------------\n";
	return out.str();
}
