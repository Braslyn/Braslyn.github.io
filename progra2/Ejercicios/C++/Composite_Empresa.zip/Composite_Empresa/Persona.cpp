#include "Persona.h"


Persona::Persona(int cod, string nom, double sal):Empresa(cod,nom),salario(sal){}

Persona::~Persona(){}
