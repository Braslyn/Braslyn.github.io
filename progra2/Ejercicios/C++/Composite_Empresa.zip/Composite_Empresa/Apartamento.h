#ifndef APARTAMENTO_H
#define APARTAMENTO_H
#include "Edificio.h"
class Apartamento:public Edificio{
public:
	Apartamento(int cod,string nom);
	~Apartamento();
	string toString();
};


#endif // !APARTAMENTO_H
