#include "Jefe.h"
#include "Trabajador.h"
#include "Apartamento.h"
#include "Oficina.h"


int main() {
	Oficina of(01,"seguridad");
	of.add(new Jefe(01, "Paco", 100000));
	of.add(new Apartamento(01,"Armas"));
	dynamic_cast<Apartamento*>(of.get(1))->add(new Trabajador(01,"Rene",50000));
	dynamic_cast<Apartamento*>(of.get(1))->add(new Trabajador(02, "Axel", 40000));
	std::cout << of.toString();
	std::cout << "Suma de todos los salarios -> " << of.Salario();
	return 0;
}