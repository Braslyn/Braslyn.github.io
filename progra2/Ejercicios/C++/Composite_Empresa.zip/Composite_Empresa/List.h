#ifndef LISTA_H
#define LISTA_H

template<class T>
struct Nodo{
	T data;
	Nodo* next;
};


template <class T>
class Lista {
public:
	Lista();
	~Lista();
	void operator<<(T);
	T* operator[](int);
	int count();
private:
	Nodo<T>* Primero;
	int cant;
};



#endif // !LISTA_H

template<class T>
inline Lista<T>::Lista() :Primero(nullptr), cant(0) {}

template<class T>
inline Lista<T>::~Lista() {
}

template<class T>
inline void Lista<T>::operator<<(T obj) {
	Nodo<T>* x = new Nodo<T>();
	x->data = obj;
	x->next = nullptr;
	if (Primero == nullptr) {
		Primero = x;
	}
	else {
		Nodo<T>* aux = Primero;
		while (aux->next != nullptr) {
			aux = aux->next;
		}
		aux->next = x;
	}
	cant++;
}

template<class T>
inline T* Lista<T>::operator[](int a) {
	if (a < cant && a >= 0) {
		Nodo<T>* aux = Primero;
		while (--a == 0) {
			aux = aux->next;
		}
		return &aux->data;
	}
	return nullptr;
}

template<class T>
inline int Lista<T>::count(){
	return cant;
}
