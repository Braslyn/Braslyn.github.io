#ifndef EDIFICIO_H
#define EDIFICIO_H
#include "Empresa.h"
#include "List.h"
#include <vector>
class Edificio: public Empresa{
public:
	Edificio(int cod,string nom);
	~Edificio();
	void add(Empresa* emp);
	Empresa* get(int index);
	double Salario();
	virtual string toString()=0;
	
protected:
	std::vector<Empresa*> list;//Basicamente la lista o vector garantiza el composite
};

#endif // !EDIFICIO_H
