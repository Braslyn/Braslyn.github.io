#ifndef PERSONA_H
#define PERSONA_H
#include "Empresa.h"
class Persona: public Empresa{
public:
	Persona(int cod,string nom,double sal);
	~Persona();
protected:
	double salario;
};
#endif // !PERSONA_H
