#include "Trabajador.h"

Trabajador::Trabajador(int cod, string nom, double sal):Persona(cod,nom,sal){}

Trabajador::~Trabajador(){}

string Trabajador::toString(){
	std::stringstream out;
	out << "Trabajador:\n" << "codigo: " << this->getCodigo() << "\nNombre: " << this->getNombre() << "\nSalario: " << this->Salario();
	return out.str();
}

double Trabajador::Salario(){
    return salario;
}
