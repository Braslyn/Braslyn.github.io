#ifndef TRABAJADOR_H
#define TRABAJADOR_H
#include "Persona.h"
class Trabajador:public Persona
{
public:
	Trabajador(int cod,string nom,double sal);
	~Trabajador();
	string toString();
	double Salario();
};

#endif // !TRABAJADOR_H
