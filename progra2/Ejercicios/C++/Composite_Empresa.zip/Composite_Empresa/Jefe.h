#ifndef JEFE_H
#define JEFE_H
#include "Persona.h"
class Jefe : public Persona
{
public:
	Jefe(int cod,string nom,double salario);
	~Jefe();
	string toString();
	double Salario();
};
#endif // !JEFE_H
