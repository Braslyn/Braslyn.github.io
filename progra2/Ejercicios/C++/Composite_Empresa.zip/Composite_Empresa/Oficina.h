#ifndef OFICINA_H
#define OFICINA_H
#include "Edificio.h"
class Oficina:public Edificio{
public:
	Oficina(int cod,string nombre);
	~Oficina();
	string toString();
};
#endif // !OFINA_H
