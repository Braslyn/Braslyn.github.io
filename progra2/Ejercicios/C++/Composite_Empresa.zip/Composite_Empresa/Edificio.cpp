#include "Edificio.h"

Edificio::Edificio(int cod, string nom):Empresa(cod,nom){}

Edificio::~Edificio(){}

void Edificio::add(Empresa* emp){
	list.push_back(emp);
}

Empresa* Edificio::get(int index){
	return list[index];
}



double Edificio::Salario(){
	double result=0;
	for (unsigned short int i = 0; i < list.size(); i++) {
		result += list[i]->Salario();
	}
	return result;
}

