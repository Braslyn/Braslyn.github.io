#include "Empresa.h"

Empresa::Empresa(int cod, string nom):codigo(cod),nombre(nom){}

Empresa::~Empresa(){}

string Empresa::getNombre()
{
    return nombre;
}

int Empresa::getCodigo()
{
    return codigo;
}
