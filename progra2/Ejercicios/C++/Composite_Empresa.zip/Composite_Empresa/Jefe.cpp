#include "Jefe.h"

Jefe::Jefe(int cod, string nom, double salario):Persona(cod,nom,salario){}

Jefe::~Jefe(){}

string Jefe::toString(){
	std::stringstream out;
	out << "Jefe:\n" << "codigo: " << this->getCodigo()<<"\nNombre: "<<this->getNombre()<<"\nSalario: "<<this->Salario();
	return out.str();
}

double Jefe::Salario(){
	return salario*0.9;
}
