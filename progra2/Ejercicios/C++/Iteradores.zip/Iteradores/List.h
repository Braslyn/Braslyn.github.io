#ifndef LIST_H
#define LIST_H
#include "iterator.h"
template <class T>
class  List{
public:
	virtual Iterator<T>* CreateIterator() = 0;
	virtual unsigned int Count() const = 0;
	virtual void operator<<(T item)= 0;
};
#endif // !LISTA_H

// [1|2|3|4|5|6|7|8|9|0]
// [2]->[3]->[8]
