#ifndef LISTA_H
#define LISTA_H
#include "List.h"

template <class T>
struct Nodo{
	T data;
	Nodo* next;
};

template <class T>
class Lista:public List<T>{
public:
	Lista();
	~Lista();
	typedef Iterator<T>* iterador;
	void operator<<(T);
	Nodo<T>* operator[](int);
	unsigned int Count()const;
	Iterator<T>* CreateIterator();
private:
	Nodo<T>* Primero;
	int cant;
};

template<class T>
class IteradorLista :public Iterator<T> {
public:
	IteradorLista(Lista<T>& list);
	~IteradorLista();
	void First();
	void Next();
	bool IsDone() const;
	T CurrentItem() const;
private:
	Nodo<T>* first;
	Nodo<T>* current;
	Nodo<T>* Final;
};

#endif // !LISTA_H

template<class T>
inline Lista<T>::Lista() :Primero(nullptr), cant(0){}

template<class T>
inline Lista<T>::~Lista() {}

template<class T>
inline void Lista<T>::operator<<(T obj) {
	Nodo<T>* x = new Nodo<T>();
	x->data = obj;
	x->next = nullptr;
	if (Primero == nullptr) {
		Primero = x;
	}else {
		Nodo<T>* aux = Primero;
		while (aux->next != nullptr) {
			aux = aux->next;
		}
		aux->next = x;
	}
	cant++;
}

template<class T>
inline Nodo<T>* Lista<T>::operator[](int a) {
	if (a < cant && a >= 0) {
		Nodo<T>* aux = Primero;
		while (--a == 0) {
			aux = aux->next;
		}
		return aux;
	}
	return nullptr;
}

template<class T>
inline unsigned int Lista<T>::Count() const{
	return cant;
}

template<class T>
inline Iterator<T>* Lista<T>::CreateIterator(){
	return new IteradorLista<T>(*this);
}
template<class T>
inline IteradorLista<T>::IteradorLista(Lista<T>& list) {
	first = list[0];
	current = first;
	Final = list[list.Count()];
}

template<class T>
inline IteradorLista<T>::~IteradorLista() {
	first = nullptr;
	current = nullptr;
	Final = nullptr;
}

template<class T>
inline void IteradorLista<T>::First() {
	current = first;
}

template<class T>
inline void IteradorLista<T>::Next() {
	current = current->next;
}

template<class T>
inline bool IteradorLista<T>::IsDone() const
{
	return current == Final;
}

template<class T>
inline T IteradorLista<T>::CurrentItem() const
{
	return current->data;
}

