#include "File.h"

File::File(Persona* persona):persona(persona){
	if (persona) {
		person = new Person(persona->cedula, persona->apellidos, persona->nombre);
	}
	else {
		person = nullptr;
	}
}

File::File():persona(nullptr){}

File::~File() { if (!persona)delete persona; persona = nullptr; }
