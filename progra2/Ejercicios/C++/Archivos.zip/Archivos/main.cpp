#include "binary.h"
#include "Json.h"
#include "Text.h"
#include <Windows.h>


int main(int arg, char* args[]) {
	if (std::atoi(args[1])==1) {
		JsonC file(new Persona(402420750, "Paco", "Montes"));
		file.write();
	}else{
		JsonC file(nullptr);
		Persona* per= &file.Read();
		std::cout<<*per;
	}
	string x = "otorinolaringologo";
	enum Palabra {oto = 'oto',rino='rino',lan='lan',gol='gol',ogo='ogo'};
	for ( unsigned short int i = 0; i < x.size(); i++){
		for (unsigned short int j = i+1; j < x.size(); j++) {
			switch (int(x.substr(i, j).c_str())){
			case 'oto':
				std::cout << "Se encontro oto! se movio " << "x" << "espacios";
				break;
			case rino:
				std::cout << "Se encontro rino! se movio " << "x" << "espacios";
				break;
			case lan:
				std::cout << "Se encontro lan! se movio " << "x" << "espacios";
				break;
			case gol:
				std::cout << "Se encontro gol! se movio " << "x" << "espacios";
			case ogo:
				std::cout << "Se encontro ogo! se movio " << "x" << "espacios";
				break;
			default:
				break;
			}
		}
	}
	return 0;
}                                                                                                                                                                                                                                                                                                                                                                                                         