#ifndef BINARY_H
#define BINARY_H
#include "File.h"

class Binary: public File{
	string deserializadorStrings(std::ifstream& in);
public:
	Binary(Persona* persona=nullptr);
	~Binary();
	bool write();
	bool writeS();
	Persona& Read();
	Person& ReadS();
};
#endif // !BINARY_H
