#include "Text.h"

Text::Text(Persona* persona):File(persona){}

Text::~Text(){}

bool Text::write(){
	if (persona) {
		std::ofstream archivo("obj.txt", std::ios::out);
		archivo << *persona;
		if (archivo.fail())
			throw new std::exception("Fallo la lectura");
		archivo.close();
		return true;
	}
	return false;
}

Persona& Text::Read(){
	persona = new Persona();
	std::ifstream archivo("obj.txt", std::ios::in);
	archivo >> persona->cedula;//" ",\n \t \r , -> getline(x,',');
	archivo >> persona->nombre;
	archivo >> persona->apellidos;//tama�o -> stream -> write 
	archivo.close();
	return *persona;
}
