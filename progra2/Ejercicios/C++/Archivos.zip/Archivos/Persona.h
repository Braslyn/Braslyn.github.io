#ifndef PERSONA_H
#define PERSONA_H
#include <string>
#include <fstream>
#include <iostream>
#include <exception>
#include <sstream>
using std::string;

struct Person{
	int identification;
	string name;
	string surnames;
	Person(int id,string name ,string sur):name(name),identification(id),surnames(sur){}
};

class Persona{
public:
	int cedula;
	string nombre;
	string apellidos;
	Persona(int cedula=0,string nombre="",string apellidos="");
	~Persona();
	friend std::ostream& operator<<(std::ostream& out, Persona&);
};
#endif // !PERSONA_H

