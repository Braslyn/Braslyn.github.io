#include "Json.h"

JsonC::JsonC(Persona* persona):File(persona){}

JsonC::~JsonC(){}

bool JsonC::write(){
	Json::Value root;//[]
	Json::StreamWriterBuilder builder;
	const std::unique_ptr<Json::StreamWriter> writer(builder.newStreamWriter());//{"cedula": 4024,...,...}
	root["cedula"] = persona->cedula;
	root["nombre"] = persona->nombre;
	root["apellido"] = persona->apellidos;
	writer->write(root, &std::ofstream("obj.json",std::ios::out));
	return true;
}

Persona& JsonC::Read(){
	Json::Value root;
	Json::String errs;
	std::ifstream archivo("obj.json", std::ios::in);
	Json::CharReaderBuilder builder;
	builder["collectComments"] = true;
	if (!parseFromStream(builder, archivo, &root, &errs)) {
		std::cout << errs << std::endl;
	}
	std::cout << root;
	
	for (unsigned short int i = 0; i < root["Lista"].size(); i++){
		auto per = new Persona(root["Lista"][i]["cedula"].asInt(), root["Lista"][i]["nombre"].asCString(), root["Lista"][i]["apellido"].asCString());
		std::cout << *per<<"\n";
		delete per;
		per = nullptr;
	}
	std::cout<<"Id: "<<root["Lista"][2]["recidencia"]["id"].asInt()<<"\n";
	
	persona = new Persona(root["Lista"][0]["cedula"].asInt(),root["Lista"][0]["nombre"].asCString(),root["Lista"][0]["apellido"].asCString());
	return *persona;
}
