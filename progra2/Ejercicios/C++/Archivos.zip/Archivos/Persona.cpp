#include "Persona.h"

std::ostream& operator<<(std::ostream& out, Persona& p){
    out << p.cedula << "\n" << p.nombre << "\n" << p.apellidos << "\n";
    return out;
}

Persona::Persona(int cedula, string nombre, string apellidos):cedula(cedula),nombre(nombre),apellidos(apellidos){}

Persona::~Persona(){}
