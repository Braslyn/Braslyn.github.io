#ifndef FILE_H
#define FILE_H
#include "Persona.h"
class File{//intefaz
public:
	File(Persona* persona=nullptr);
	File();
	~File();
	virtual bool write()=0;
	virtual Persona& Read()=0;
protected:
	Persona* persona;
	Person* person;
};
#endif // !FILE_H
