#ifndef TEXT_H
#define TEXT_H
#include "File.h"

class Text :public File{
public:
	Text(Persona* persona=nullptr);
	~Text();
	bool write();
	Persona& Read();
};


#endif // !TEXT_H
