#include "binary.h"

string Binary::deserializadorStrings(std::ifstream& in){
	string field;
	int largoString = 0;//variable con mayor capacidad numerico
	in.read(reinterpret_cast<char*>(&largoString), sizeof(int));
	char* caracteres = new char[largoString];
	in.read(caracteres, (std::streamsize)largoString);
	field = string(caracteres);
	delete[] caracteres;
	std::cout<<in.good();
	return field;
}

Binary::Binary(Persona* persona):File(persona){}

Binary::~Binary(){}

bool Binary::write(){
	if (persona) {
		std::ofstream archivo("obj.dat",std::ios::out|std::ios::binary);
		archivo.write(reinterpret_cast<char*>(persona->cedula), sizeof(int));
		if (archivo.fail())
			throw new std::exception("Fallo la escritura");
		archivo.close();
		return true;
	}
	return false;
}

bool Binary::writeS()//101010101|101010101;
{
	if (person) {
		std::ofstream archivo("obj.dat", std::ios::out | std::ios::binary);
		archivo.write(reinterpret_cast<char*>(&person), sizeof(*person));
		if (archivo.fail())
			throw new std::exception("Fallo la escritura");
		archivo.close();
		return true;
	}
	return false;
}


Persona& Binary::Read(){
	int id;
	std::ifstream archivo("obj.dat", std::ios::in | std::ios::binary);
	if (archivo.fail())
		throw new std::exception("Fallo la lectura");
	archivo.read(reinterpret_cast<char*>(&id), sizeof(int));
	string nombre = deserializadorStrings(archivo);
	string apellido= deserializadorStrings(archivo);//falla
	persona = new Persona(id,nombre,apellido);
	archivo.close();
	return *persona;
}

Person& Binary::ReadS(){
	std::ifstream archivo("obj.dat", std::ios::in | std::ios::binary);
	archivo.read(reinterpret_cast<char*>(&person), sizeof(Person));
	return *person;
}
