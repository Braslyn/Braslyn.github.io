#ifndef JSON_H
#define JSON_H
#include "File.h"
#include  "json/json.h"

class JsonC:public File{
public:
	JsonC(Persona* persona=nullptr);
	~JsonC();
	bool write();
	Persona& Read();
};

#endif // !JSON_H
