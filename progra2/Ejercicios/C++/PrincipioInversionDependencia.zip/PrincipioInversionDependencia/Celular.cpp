#include "Celular.h"

Celular::Celular(AdaptadorPantalla* reproductor){
	this->reproductorVideo = reproductor;
}

Celular::~Celular() { if (reproductorVideo != nullptr)delete reproductorVideo; reproductorVideo = nullptr; }

std::string Celular::Reproducir(std::string URL)
{
	return reproductorVideo->Reproducir(URL);
}
