#include "AdaptadorStreaming.h"

AdaptadorStreaming::AdaptadorStreaming(Intenet* streaming):streaming(streaming){}

AdaptadorStreaming::~AdaptadorStreaming(){}

std::string AdaptadorStreaming::Reproducir(std::string URL)
{
	streaming->setInternetURL(URL);
	return streaming->Navegar() ?streaming->Reproducir():"No se encontro el video en internet";
}
