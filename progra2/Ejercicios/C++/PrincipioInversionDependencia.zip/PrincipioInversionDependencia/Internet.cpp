#include "Internet.h"

Intenet::Intenet():URL(""),Buffer("axsas54das654asd1"){}

Intenet::~Intenet()
{
}

void Intenet::setInternetURL(std::string URL) { this->URL = URL; }

bool Intenet::Navegar()
{
	return URL!="";
}

std::string Intenet::Reproducir()
{
	return std::string("Reproduciendo video de Internet: "+Buffer);
}
