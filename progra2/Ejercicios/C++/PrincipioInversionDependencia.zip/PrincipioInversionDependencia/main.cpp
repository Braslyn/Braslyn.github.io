#include "Celular.h"
#include <iostream>


int main(int arg,const char* args[]) {
	
	if (arg > 2) {
		std::string aux = args[1];
		AdaptadorPantalla* adaptador;
		if (aux == "Galeria") {
			adaptador = new AdaptadorGaleria(new Galeria());
		}
		else if(aux=="Internet"){
			adaptador = new AdaptadorStreaming(new Intenet());
		}else {
			std::cout << "Parametro invalido";
			return 0;
		}
		Celular cel(adaptador);
		std::cout << cel.Reproducir(args[2]);
	}else {
		std::cout << "Argumentos Insuficientes";
	}
	return 0;
}