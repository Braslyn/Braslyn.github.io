#ifndef ADAPTADOR_STREAMING_H
#define ADAPTADOR_STREAMING_H
#include "AdapatadorPantalla.h"
class AdaptadorStreaming: public AdaptadorPantalla{
public:
	AdaptadorStreaming(Intenet* streaming=nullptr);
	~AdaptadorStreaming();
	std::string Reproducir(std::string URL = "");
private:
	Intenet* streaming;
};


#endif // !ADAPTADOR_STREAMING
