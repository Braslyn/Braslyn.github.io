#ifndef INTERNET_H
#define INTERNET_H
#include <string>
class Intenet
{
public:
	Intenet();
	~Intenet();
	void setInternetURL(std::string URL="");
	bool Navegar();
	std::string Reproducir();
private:
	std::string URL;
	std::string Buffer;
};


#endif // !Internet
