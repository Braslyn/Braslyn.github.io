#ifndef ADAPTADORPANTALLA_H
#define ADAPTADORPANTALLA_H
#include <memory>
#include "Galeria.h"
#include "Internet.h"
class AdaptadorPantalla {

public:
	virtual std::string Reproducir(std::string URL = "") = 0;
};

#endif // !ADAPTADORPANTALLA_H
