#ifndef GALERIA_H
#define GALERIA_H
#include <string>

class Galeria
{
public:
	Galeria();
	~Galeria();
	void setLocalURL(std::string Url="");
	bool buscar();
	std::string Reproducir();
private:
	std::string URL;
};


#endif // !GALERIA_H
