#ifndef ADAPTADOR_GALERIA_H
#define ADAPTADOR_GALERIA_H
#include "AdapatadorPantalla.h"

class AdaptadorGaleria:public AdaptadorPantalla
{
public:
	AdaptadorGaleria(Galeria* galeria=nullptr);
	~AdaptadorGaleria();
	std::string Reproducir(std::string URL = "");
private:
	Galeria* galeria;
};

#endif // !ADAPTADOR_GALERIA_H
