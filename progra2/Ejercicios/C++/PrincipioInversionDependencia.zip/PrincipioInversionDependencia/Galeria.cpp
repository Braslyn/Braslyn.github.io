#include "Galeria.h"

Galeria::Galeria():URL(""){}

Galeria::~Galeria()
{
}

void Galeria::setLocalURL(std::string Url)
{
	this->URL = Url;
}

bool Galeria::buscar()
{
	return URL!="";
}

std::string Galeria::Reproducir(){

	return "Reproduciendo video de galeria";
}
