#ifndef CELULAR_H
#define CELULAR_H
#include "AdaptadorGaleria.h"
#include "AdaptadorStreaming.h"
class Celular
{
public:
	Celular(AdaptadorPantalla* reproductor=nullptr);
	~Celular();
	std::string Reproducir(std::string URL = "");
private:
	AdaptadorPantalla* reproductorVideo;
};

#endif // !CELULAR_H
