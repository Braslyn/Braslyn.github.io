#include "AdaptadorGaleria.h"

AdaptadorGaleria::AdaptadorGaleria(Galeria* galeria):galeria(galeria){}

AdaptadorGaleria::~AdaptadorGaleria(){}

std::string AdaptadorGaleria::Reproducir(std::string URL){
	galeria->setLocalURL(URL);
	return galeria->buscar() ? galeria->Reproducir() : "No se pudo encontrar el video";

}
