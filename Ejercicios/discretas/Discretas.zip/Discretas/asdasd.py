def fbus(x,a):
    n=len(a)
    def buscando(i):
        if i >= n: return -1
        if x==a[i]: return i
        return buscando(i+1)
    return buscando(0)


def fbus_ins(x,a):
    ins=0
    n=len(a)
    def buscando(i):
        ins+=1
        if i >= n: ins
        ins+=1
        if x==a[i]: ins
        return buscando(i+1)
    return buscando(0)

if __name__=='__main__':
    a=[1,2,3,4,5]
    print(fbus_ins(6,a))