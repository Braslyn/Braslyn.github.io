def Pow(a,n):
    def pow2(n):
        n-=1
        return 1 if n<1 else a*pow2(n)
    return 1 if n<1 else a*pow2(n/2)*a*pow2((n/2)-1)