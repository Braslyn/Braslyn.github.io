def exponenciar(x,n):
    return 1 if n==0 else x* exponenciar(x,n-1)

def exponenciar_iter(n):
    for i in range(1,n+1):
        for j in range(i+1,n+1):
            print("hola!")

""" Exponencias_iterativo es mas rapido porque no tiene que 'subir' para dar un resultado """

if __name__=="__main__":
    exponenciar_iter(5)