"""
    Demo de juguete para ejercitar relaciones binarias
    loriacarlos@gmail.com
    I-2019
"""
from abc import ABC, abstractmethod

class Relation(ABC):
    """
        Abstract Relation Model
    """
    def __init__(self, domain, range, name):
        self._domain = domain
        self._range = range if range else domain
        self._name  = name
        
    @abstractmethod
    def __iadd__(self, other): # Allows R += (x, y)
        pass
    def extend(self, pair_list): # Allows R.extend([(.,.), ..., (.,.)]
        for p in pair_list:
            self += p
    @abstractmethod
    def rel(x, y): # True iff x R y
        pass
    @abstractmethod
    def neighbors(self, x):
        pass
    @property
    def domain(self):  # Returns the domain
        return self._domain
    @property
    def range(self):  # Returns the range
        return self._range
    @abstractmethod
    def __len__(self): # Allows len(R)
        pass
    @property
    def name(self):  # A name for the relation
        return self._name
    
class SelfRelation(Relation):
    """
        Simple implementation of a relation using lists
        Just for learning purposes
    """
    def __init__(self, domain, pairs=None, name="R"):
        super().__init__(domain, domain, name)
        self._pairs = []
        if pairs:
            for p in pairs:
                self += p
                
    def rel(self, x, y):
        return (x, y) in self._pairs
     
    def neighbors(self, x):
        raise RelException("*** To do: Method 'neighbors' not implemented!! ***")
        
    def __contains__(self, p):
        x,y = p
        return self.rel(x, y)
        
    def __iadd__(self, pair):
        x, y = pair
        if x not in self.domain or y not in self.domain:
            raise RelException(f"{x} or {y} not in domain")
        if (x, y) in self._pairs:
            raise RelException(f"Duplicated pair ({x}, {y})")
            
        self._pairs.append(pair)
        return self
        
    def __len__(self):
        return len(self._pairs)
        
    def __repr__(self):
        return f"{self._name}({self._pairs})"
        
class RelException(BaseException):
    pass
        
        
class RelClassifier:
    """
        Abstract classifier of a relation (assumed to be SelfRelation)
        Exercise: Implement all of them
        Requirement: You must return a witness of falsehood in case a property fails
    """
    @staticmethod
    def is_function(R):
        pass
    @staticmethod
    def is_reflexiv(R):
        pass
    @staticmethod
    def is_irreflexiv(R):
        pass
    @staticmethod
    def is_symmetric(R):
        pass
    @staticmethod
    def is_antisymmetric(R):
        pass
    @staticmethod
    def is_transitive(R):
        pass
    @staticmethod
    def is_equiv(R):
        pass
    @staticmethod
    def is_po(R):
        pass

if __name__ == "__main__":
    #
    print()
    print("*** Toy Demo for playing with relations ***")
    print("*** EIF203 I-2019 ***")
    print()
    #
    try:
        R = SelfRelation(domain=[1,2,3,4], pairs=[(1,2)],name="divideA")
        print(f"R={R}, R.domain={R.domain}, R.range={R.range}")
        p = 1,3
        print(f"Adding {p} to {R.name}")
        R += p
        print(R)
        print((1,3) in R)
        print(R.neighbors(1))
    except RelException as e:
        print(e)
    
    
    
    