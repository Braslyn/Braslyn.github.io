def f(n):
    if n==0:
        for i in range(0,5,2):
            print('Final')
        return
    print('Antes')
    f(n-1)
    for i in range(n):
        print('Despues')


def f_ins(n):
    m=0
    if n==0:
        for i in range(0,5,2):
            m+=1
            print('Final')
        return m
    print('Antes')
    m+=1
    m=f(n-1)
    for i in range(n):
        m+=1
        print('Despues')
        return m

if __name__=='__main__':
    print(f(5))