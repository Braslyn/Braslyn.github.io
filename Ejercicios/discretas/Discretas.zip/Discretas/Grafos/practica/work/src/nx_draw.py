"""
    loriacarlos@gmail.com
    EIF203 I-2018
    Dibuja grafos de networkx (nx)
    Ver https://networkx.github.io/documentation/networkx-1.10/_modules/networkx/drawing/nx_pylab.html#draw_networkx
"""
import networkx as nx
import matplotlib.pyplot as plt
import sys
test_graph = '../data/miniGraph2.xml'
def nx_draw(graph=test_graph, dim=20, labels=True, font_size=12, mag=60):
    """
        Dibuja un grafo usando nx
        Lo lee de disco en formato Graphml
        Ver ejemplos de grafos en ../data
    """
    print(f'*** Reading {graph} ***')
    g = nx.read_graphml(graph)
    fig = plt.figure(0, figsize=(dim, dim)) 
    fig.canvas.set_window_title('EIF203 2019')

    plt.title(f"Graph: '{graph}':")
    d = {k:v for k,v in nx.degree(g)}
   
    
    #General option is nx.draw(g)
    nx.draw_spring(g,  nodelist= g.nodes(), 
                       with_labels=labels,
                       node_size=[v * mag for v in d.values()], 
                       font_size=font_size,
                       node_color="lightblue", 
                       edge_color="grey"
                       )
    #another option is nx.draw_circular(g)
    
    plt.show()
    

if __name__ == "__main__":
    print('Testing nx_draw Script')
    argv = sys.argv
    if len(argv) == 2:
        nx_draw(argv[1], labels=False, mag=20)
    else:
        nx_draw()