from btree import *

class Leaves(IVisitor):
    """
    Count the number of leaves in the visitable
    """
    def __init__(self):
        self.__leaves = 0
    
    def visit(self, visitable):
        if not isinstance(visitable, BTree.BNode):
            raise TypeError(f" Provided type'{type(visitable)}' is not the expected one")
            
        if visitable.is_leaf():
            self.do_something(visitable)
            return
            
        if visitable.left:
            visitable.left.accept(self)
        
        if visitable.right: 
            visitable.right.accept(self)
    @property
    def leaves(self):  
        return self.__leaves
    
    def do_something(self, visitable):
            self.__leaves += 1
    
    
    
    