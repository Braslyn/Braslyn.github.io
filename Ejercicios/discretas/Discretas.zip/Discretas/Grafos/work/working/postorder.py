from btree import *

class Post_order(IVisitor):
    """
        Post order visitor of a BNode
    """
    
    def visit(self, visitable):
        if not isinstance(visitable, BTree.BNode):
            raise TypeError(f" Provided type'{type(visitable)}' is not the expected one")
 
        if visitable.left:
            visitable.left.accept(self)
            
        if visitable.right:
            visitable.right.accept(self)
            
        self.do_something(visitable)

        
    