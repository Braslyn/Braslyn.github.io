from btree import *

class Pre_order(IVisitor):
    """
        Pre order visitor of a BNode
    """
    
    def visit(self, visitable):
        if not isinstance(visitable, BTree.BNode):
            raise TypeError(f" Provided type'{type(visitable)}' is not the expected one")
        self.do_something(visitable)
        if visitable.left:
            visitable.left.accept(self)
            
        if visitable.right:
            visitable.right.accept(self)
    