"""
 loriacarlos@gmail.com
 EIF203 I-2019
 Demo Binary Tree for Expressions
 It illustrates the visitor pattern

"""
import sys
from abc import ABC, abstractmethod
from functools import total_ordering


class BTree:
    """
        Class representing a simple Binary tree.
        All logic is delegated (bypased) to BNode
        It contains a header (__header) that points to the real root of the tree using the left pointer. 
        The root of tree is __header.left being a BNode
    """
    class BNode:
        
        def __init__(self, data=None, left=None, right=None):
            self.data = data
            self.left = left
            self.right = right
        
        def is_leaf(self):
            return not self.left and not self.right
        
        def height(self):
            if self.is_leaf(): return 0
            if not self.right: return self.left.height()
            if not self.left: return self.right.height()
            return 1 + max(self.left.height(), self.right.height())
        
        def accept(self, visitor):
            visitor.visit(self)
        
        def __str__(self):
            if self.is_leaf(): return str(self.data)
            return f"{self.data}({self.left}, {self.right})"
        
        def __repr__(self):
            return f"BNode(data={self.data}, left={self.left.__repr__()}, right={self.right.__repr__()})"
    """
        Class representing a Binary Node
        Contains all the logic required for binary usual operations
    """
    def __init__(self, header=None):
        if not header:
            header = BTree.BNode()
        self.__header = header
    
    def root(self):
        return self.__header.left
    
    def is_empty(self):
        return not self.__header.left
        
    @staticmethod
    def from_node(node):
        """
            Convenience method. It builds a BTree from a given BNode node
        """
        return BTree(BTree.BNode(left=node))
        
    def height(self):
        if self.is_empty(): return 0
        return self.root().height()
    
    def accept(self, visitor):
        if self.is_empty(): return
        self.root().accept(visitor)
    
    def __str__(self):
        return str(self.root())
    
    def __repr__(self):
        return repr(self.root())
        
    @property
    def left(self):
        if self.is_empty(): return None
        return BTree(BTree.BNode(left=self.root().left))
    
    @property
    def right(self):
        if self.is_empty(): return None
        return BTree(BTree.BNode(left=self.root().right))
            
class IVisitor(ABC):
    """
         Visitor interface.
    """
    @abstractmethod
    def visit(self, visitable):
        pass
    def do_something(self, visitable):
        print(visitable.data, end='')
    


MAX_PRECEDENCE = sys.maxsize
@total_ordering            
class Data:
    """
     Class representing data in BNodes
     It allows a precedence for comparison, for instance "+" having less than "*".
     Associativity is always assumed to be 'left' (to do: accept 'right' and 'none')
    """
    def __init__(self, value, precedence=MAX_PRECEDENCE):
        self.value = value
        self.precedence = precedence
    def __eq__(self, other):
        return isinstance(other, type(self)) and self.precedence == other.precedence
    def __le__(self, other):
        return isinstance(other, type(self)) and self.precedence <= other.precedence
    def __str__(self):
        return str(self.value)
    def __repr__(self):
        return "Data({repr(self.value)}, {repr(self.precedence)})"

