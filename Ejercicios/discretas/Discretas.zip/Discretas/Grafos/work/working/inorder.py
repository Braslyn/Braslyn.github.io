from btree import *

class In_order(IVisitor):
    """
    In order visitor of a BNode
    """
    
    def visit(self, visitable):
        if not isinstance(visitable, BTree.BNode):
            raise TypeError(f" Provided type'{type(visitable)}' is not the expected one")
        
        if visitable.left:
            visitable.left.accept(self)
            
        self.do_something(visitable)
        
        
        if visitable.right:
            visitable.right.accept(self)
            
    
    
    
    