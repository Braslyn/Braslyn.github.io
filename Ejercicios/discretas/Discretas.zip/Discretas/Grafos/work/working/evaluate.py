from btree import *

class Eval(IVisitor):
    """
    Count the number of leaves in the visitable
    """
    def __init__(self):
        self.__result = 0
        self.left_value, self.right_value = None, None 
        
    def visit(self, visitable):
        if not isinstance(visitable, BTree.BNode):
            raise TypeError(f" Provided type'{type(visitable)}' is not the expected one")
        self.left_value, self.right_value = None, None   
        if visitable.left:
            visitable.left.accept(self)
            self.left_value = self.result
        if visitable.right: 
            saved_left = self.left_value
            visitable.right.accept(self)
            self.left_value = saved_left
            self.right_value = self.result
        self.do_something(visitable)
        
    @property
    def result(self):  
        return self.__result
    
    def do_something(self, visitable):
        value = visitable.data.value
        if visitable.is_leaf():
            self.__result = int(value)
            return
        operator = value
        # Select operator (a dictionary of lambdas would be much better)
        if operator == "+":
            self.__result = self.left_value + self.right_value
        elif operator == "*":
            self.__result = self.left_value * self.right_value
        #more cases here...
        else:
            raise Exception(f'Evaluate: Operator {operator} not implemented yet')
            
    
    
    
    