"""
 loriacarlos@gmail.com
 EIF203 I-2019
 Testing Binary Tree for Expressions
 Quiz # 7 "Hay tanto caminos por andar" 5/10/2019
"""
from btree import *
from inorder import In_order
from postorder import Post_order
from preorder import Pre_order

from leaves import Leaves
from evaluate import Eval

AUTHORS = [('Carlos Loria-Saenz', '123456789')]
def show_authors(authors=AUTHORS):
    for (i, (author, id)) in enumerate(AUTHORS):
        print(f"({i}) Author:{author} ID:{id}")
    print()
    
def test_order(order_type, visitor_class, verbose=True):
    if verbose:
        print(f'\n*** {order_type} ***')
    results = []
    for i, tree in enumerate(trees):
        visitor = visitor_class()
        if verbose:
            print(f"\n{i:2d}) Original Tree = {tree}")
            print(f'{order_type} => ', end='')
        tree.accept(visitor)
        results.append((tree, visitor))
    if verbose: print()
    return results
    
# Main testing
if __name__ == "__main__":
    print("*** Testing Expression Trees (EIF203 I-2019) ***")
    show_authors()
    ################################################################
    # Setup test cases
    #Some data
    A, B, C = Data("A"), Data("B"), Data("C")
    TIMES = Data("*", 5)
    PLUS  = Data("+", 2)
    #################################################################
    #Some nodes
    nodeA = BTree.BNode(A) # A
    nodeB = BTree.BNode(B) # B
    nodeC = BTree.BNode(C) # C
    nodePBC = BTree.BNode(PLUS, nodeB, nodeC)     # B + C
    nodeTBC = BTree.BNode(TIMES, nodeB, nodeC)    # B * C
    nodeAPBC = BTree.BNode(TIMES, nodeA, nodePBC) # A * (B + C)
    nodePBCA = BTree.BNode(TIMES, nodePBC, nodeA) # (B + C) * A
    nodeATBC = BTree.BNode(TIMES, nodeA, nodeTBC) # A * (B * C)
    nodeTBCA = BTree.BNode(TIMES, nodeTBC, nodeA) # (B * C) * A
    nodePPBCA = BTree.BNode(PLUS, nodePBC, nodeA) # (B + C) + A
    ##################################################################
    # Some trees
    nodes = [nodeA, nodePBC, nodeTBC,  nodeAPBC, nodePBCA, nodeATBC, nodeTBCA, nodePPBCA]
    trees = [BTree.from_node(node) for node in nodes ]
    ###########################################################
    # Visit each tree using visitor and print it in order
    test_order('IN-ORDER', In_order)
    ############################################################
    # Visit each tree using visitor and print it in post-order
    test_order('POST-ORDER', Post_order)
    ############################################################
    # Visit each tree using visitor and print it in pre-order
    test_order('PRE-ORDER', Pre_order)
    ############################################################
    # Visit to count the number of leaves
    order_type = 'LEAVES'
    results = test_order('', Leaves, verbose=False)
    print(f'\n*** {order_type} ***')
    for (tree, visitor) in results:
        print(f"{tree} => {visitor.leaves} leaves")
    print()
    ###########################################################
    # Visit to evaluate tree of *, + and numbers
    A, B, C = Data("10"), Data("20"), Data("30")
    nodeA = BTree.BNode(A) # A=10
    nodeB = BTree.BNode(B) # B=20
    nodeC = BTree.BNode(C) # C=30
    nodePBC = BTree.BNode(PLUS, nodeB, nodeC)     # B + C
    nodeTBC = BTree.BNode(TIMES, nodeB, nodeC)    # B * C
    nodeAPBC = BTree.BNode(TIMES, nodeA, nodePBC) # A * (B + C)
    nodePBCA = BTree.BNode(TIMES, nodePBC, nodeA) # (B + C) * A
    nodeATBC = BTree.BNode(TIMES, nodeA, nodeTBC) # A * (B * C)
    nodeTBCA = BTree.BNode(TIMES, nodeTBC, nodeA) # (B * C) * A
    nodePPBCA = BTree.BNode(PLUS, nodePBC, nodeA) # (B + C) + A
    nodes = [nodeA, nodePBC, nodeTBC,  nodeAPBC, nodePBCA, nodeATBC, nodeTBCA, nodePPBCA]
    trees = [BTree.from_node(node) for node in nodes ]
    order_type = 'EVALUATOR'
    results = test_order('', Eval, verbose=False)
    print(f'\n*** {order_type} ***')
    for (tree, visitor) in results:
        print(f"{tree} => {visitor.result}")
    print()
    
    
    