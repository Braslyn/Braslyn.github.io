"""
 loriacarlos@gmail.com
 EIF203 I-2019
 Testing Binary Tree for Expressions
 Quiz # 7 "Hay tanto caminos por andar" 5/10/2019
"""
from btree import *
from inorder import In_order
from postorder import Post_order
from preorder import Pre_order

AUTHORS = [('Carlos Loria-Saenz', '123456789')]
def show_authors(authors=AUTHORS):
    for (i, (author, id)) in enumerate(AUTHORS):
        print(f"({i}) Author:{author} ID:{id}")
    print()
    
def test_order(order_type, visitor_class):
    print(f'\n*** {order_type} ***')
    visitor = visitor_class()
    for i, tree in enumerate(trees):
        print(f"\n{i:2d}) Original Tree = {tree}")
        print(f'{order_type} => ', end='')
        tree.accept(visitor)
    print()
    
# Main testing
if __name__ == "__main__":
    print("*** Testing Expression Trees (EIF203 I-2019) ***")
    show_authors()
    ################################################################
    # Setup test cases
    #Some data
    A, B, C = Data("A"), Data("B"), Data("C")
    TIMES = Data("*", 5)
    PLUS  = Data("+", 2)
    #################################################################
    #Some nodes
    nodeA = BTree.BNode(A) # A
    nodeB = BTree.BNode(B) # B
    nodeC = BTree.BNode(C) # C
    nodePBC = BTree.BNode(PLUS, nodeB, nodeC)     # B + C
    nodeTBC = BTree.BNode(TIMES, nodeB, nodeC)    # B * C
    nodeAPBC = BTree.BNode(TIMES, nodeA, nodePBC) # A * (B + C)
    nodePBCA = BTree.BNode(TIMES, nodePBC, nodeA) # (B + C) * A
    nodeATBC = BTree.BNode(TIMES, nodeA, nodeTBC) # A * (B * C)
    nodeTBCA = BTree.BNode(TIMES, nodeTBC, nodeA) # (B * C) * A
    nodePPBCA = BTree.BNode(PLUS, nodePBC, nodeA) # (B + C) + A
    ##################################################################
    # Some trees
    nodes = [nodeA, nodePBC, nodeTBC,  nodeAPBC, nodePBCA, nodeATBC, nodeTBCA, nodePPBCA]
    trees = [BTree.from_node(node) for node in nodes ]
    ###########################################################
    # Visit each tree using visitor and print it in order
    test_order('IN-ORDER', In_order)
    ############################################################
    # Visit each tree using visitor and print it in post-order
    test_order('POST-ORDER', Post_order)
    ############################################################
    # Visit each tree using visitor and print it in pre-order
    test_order('PRE-ORDER', Pre_order)
    
    
    