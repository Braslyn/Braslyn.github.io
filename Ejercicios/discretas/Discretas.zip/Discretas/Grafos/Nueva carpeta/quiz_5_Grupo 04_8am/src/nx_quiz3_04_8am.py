"""
    Autor:Braslyn Rodriguez
    Fecha:25/04/19
    Correo:Braslynrrr999@gmail.com
    Tema: Quiz n5 funciones de grafos
    Horario 8am
"""
import networkx as nx
import sys
test_graph = '../data/euler_test_17_190.xml'
def apreton(graph):
    """
        La funcion nos ofrece la consulta de la suma de los grados del cada vertice mas cada arco multiplicado
        por dos para comporbar el teorema del apreton de manos
    """
    aux=sorted(graph.degree())
    grados=0
    for i in range(len(aux)):
        aux2=aux[i]
        grados+=aux2[1]
    arcos=graph.edges()
    return (grados,2*len(arcos))

def mayor_y_vecinos(graph):
    """
        Busca el vertice con mayor grado y retorna los neighbors
    """
    mayor=0
    aux=sorted(nx.degree(graph))
    for i in range(len(aux)-1):
        if aux[mayor][1]<aux[i+1][1]:
            mayor=i+1
    name=aux[mayor][0]
    return (name,tuple(sorted(graph[name])))

def paridad(graph):
    """
        Verifica que los arcos de cada vertices sean pares y devuelve true , en caso contrario
        devulve una excepcion
    """
    aux=sorted(graph.degree())
    i=0
    try:
        for i in range(len(aux)):
            if aux[i][1]%2!=0:
                leave
    except:
        return f"No se cumple paridad en el grafo en el nodo ----> {aux[i][0]}"
    return True

if __name__=="__main__":
    print("Autor:Braslyn Rodriguez\nFecha:25/04/19\nCorreo:Braslynrrr999@gmail.com\nTema: Quiz n5 funciones de grafos\nHorario: 8am\n")
    argv = sys.argv
    if len(argv)==2:
        Ruta=argv[1]
        print(Ruta)
        grafo=nx.read_graphml(Ruta)
    else:
        Ruta=test_graph
        grafo=nx.read_graphml(Ruta)
    print(f"Prueba de Grafo {Ruta}\n")
    print(f"Apreton de manos (Suma de grados , arcos * 2) = {apreton(grafo)}\n")
    vecinos=mayor_y_vecinos(grafo)
    print(f"Mayor y vecinos \nVertice con mayor grado = {vecinos[0]}")
    print(f"Con {vecinos[1]} como vecinos\n")
    print(f"Teorema de Euler(Paridad) = {paridad(grafo)}")
    