"""
 Base de rspuesta a trivia  de fechas 
 29/5/2019
 loriacarlos@gmail.com
"""
import re
# Test case
h = r'2019/31/12 y 2020/1/05 sería válidas, pero no 2018/31/66 (año invalido) ni 2019-20-10 (mes invalido), ni 2019-6/7, ni 2019-55-33. Pero si 2020-10-1 y 2019/12/'

# Raw patttern
#pat = r'(?P<y>(20(:?19|20)))(?P<sep>[-/])(?P<m>\d\d)(?P=sep)(?P<d>\d{2})?'

#Verbose pattern (month and day validation are pending)
vpat = """
      (?P<y>(20(:?19|20))) #year
      (?P<sep>[-/])        #separator hyphen or slash
      (?P<m>\d{1,2})       #month
      (?P=sep)             #matching previous separator
      (?P<d>\d{1,2})?      #day (optional)
      """
# Compile vpat
pat = re.compile(vpat, re.VERBOSE)
print(f"TEST CASE = {h}")
print("*** RESULTS ****")
for i, mo in enumerate(pat.finditer(h)):
    [y, m, d] = map(lambda x: int(x) if x else 30, (mo.group('y'), mo.group('m'), mo.group('d')))
    print()
    print(f"Match #{i}")
    print(f"{y} {m} {d} (day was replaced by 30 if was absent)")
    # Check pending checks
    if y not in [2020, 2019]:
        print(f"Case {i}) Invalid year {y}")
    if not ( 1 <= m <= 12):
         print(f"Case {i}) Invalid month {m}")
    if not ( 1 <= d <= 31):
         print(f"Case {i}) Invalid day {d}")
    
    
