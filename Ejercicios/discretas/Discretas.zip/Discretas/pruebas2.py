"""
author: Braslyn Rodriguez Ramirez
fecha: 011/03/2019
Uso: Ejercicios
"""

def ejer2B(a):
    if a==0: return 6
    if a==1: return 8
    return 4*ejer2B(a-1)-4*ejer2B(a-2)

def ejer2B_formula(a):
    return 6*2**a-2*a*2**a

if __name__=="__main__":
    for n in range(5):
        print(f"{n}, ejer2B(n)={ejer2B(n)} ")
    print("\n")
    for n in range(5):
        print(f"{n}, ejer2B_formula(n)={ejer2B_formula(n)} ")