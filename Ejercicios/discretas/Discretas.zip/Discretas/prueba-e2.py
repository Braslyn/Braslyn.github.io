for i in range(0,5,1)
    print(5*(i+1)-i)

