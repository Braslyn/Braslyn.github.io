"""
   author: Braslyn Rodriguez Ramirez
fecha: 9/03/2019
Uso: Permutar
"""

def insertar_en_cada_pos(x,p):
    """
    inserta x en cada posible posicion de p
    """
    #recursivo como tarea
    return [p[:i]+[x]+p[i:] for i in range(len(p)+1)]

def insertar_en_cada_pos_ins(x,p):
    """
    inserta x en cada posible posicion de p
    """
    ac=2
    for i in range(len(p)+1):
        ac+=2
    print(f'Total = {ac}')
    return [p[:i]+[x]+p[i:] for i in range(len(p)+1)]

def insertar_en_cada_pos2(x,p): #Good
    lista=[]
    def proceso(i):
        lista.extend([p[:i]+[x]+p[i:]])
        if i==len(p): return lista
        return proceso(i+1)
    return proceso(0)
    
    
def insert(x,lista_perm):
    """
    para cada permutacion p in lista_perm x en cada posible
    posicion en p
    """
    nuevas_permutaciones=[]
    for p in lista_perm:
        nuevas_permutaciones.extend(insertar_en_cada_pos_ins(x,p))
    return nuevas_permutaciones

def insert_ins(x,lista_perm):
    """
    para cada permutacion p in lista_perm x en cada posible
    posicion en p
    """
    nuevas_permutaciones=[]
    for p in lista_perm:
        nuevas_permutaciones.extend(insertar_en_cada_pos_ins(x,p))
    return nuevas_permutaciones

def insert2(x,lista_perm):
    nuevas_permutaciones=[]
    def proceso(p):
        if p in lista_perm: proceso(p+1)
        else: nuevas_permutaciones.extend(insertar_en_cada_pos(x,p))
    return proceso(0)
    
    
def perm(a):
    if len(a)==0:return [[]]
    if len(a)==1:return [a]
    return insert((a[0]),perm(a[1:]))
    
def formula(n):
    return 2*n+2
    
def fact(n):
    """
    if n==0:return 1
    return n*fact(n-1)
    """ 
    return 1 if n==0 else n*fact(n-1)

def fact_iterativo(n):
    f=1
    for i in range(1,n+1):f*=i
    return f
    
if __name__=="__main__":
    a=list('ab')#constructor de list
    print(f"a={a}")
    for i,p in enumerate(perm(a)):#añadimos features con enumerate
        print(f"{(i+1)}) ---> {p}")
    print(formula(len(a)))