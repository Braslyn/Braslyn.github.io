""" 
author: Braslyn Rodriguez Ramirez
fecha: 06/03/2019
Uso: Factorial
"""

def Factorial(a):
    def Proceso(n):
        if n==a: return a
        return n*Proceso(n+1)
    return Proceso(1)
    
def factorialDescompositor(a):
    permutaciones={}
    for i in range(proceso(len(a))):
        permutaciones[i]=
    return permutaciones
    
print(Factorial(5))
