"""
loriacarlos@gmail.com
EIF203 I-2019
Ve+ry inefficient demo implementations of string sets operations
Using (lazy) generators would be quite better
"""
EPSILON = ""

def cat(S, T):
	return [ s + t  for s in S for t in T]
	
def pow(S, n): # Exercise: Use exponentiation by squaring to obtain O(log(n)) time
	if n == 0 :
		return [EPSILON]
	return cat(S, pow(S, n - 1))
	
def kleene(A, n, m=None):
	"""
		@return A**n + A**(n+1) + ... + A**m
		n is required m is optional
		If m is not provided assumes n=0 and m = n
	"""
	if not m:
		n, m = 0, n
	all = []
	for i in range(n, m + 1):
		all.extend(pow(A, i))
	return all
	
class KList(list):
	"""
		List Wrapper for adding Kleene operations
	"""
	def __pow__(self, n): # self ** n
		return KList(pow(self, n))
		
	def __mul__(self, other): # self * other
		return KList(cat(self, other))
		
	def kleene(self, n, m):
		return KList(kleene(self, n, m))


if __name__ == "__main__":
	#
	print("\n*** Testing operations as functions of lists ***")
	A = ["a", "e"]
	Y = ["y"]
	Y3 = pow(Y, 3)
	print(f"A={A}, Y**3={Y3}, A * Y3={cat(A, Y3)}")
	print(f"{A}.kleene(1, 4)={kleene(A, 1, 4)}")
	

	# Now using KList
	print("\n*** The same with KList ***")
	X = KList(["a", "e"])
	Y = KList(["y"])
	print(f"X={X}, Y**3={Y**3}, X * Y3={X * Y ** 3}")
	print(f"{X}.kleene(1, 4)={X.kleene(1, 4)}")