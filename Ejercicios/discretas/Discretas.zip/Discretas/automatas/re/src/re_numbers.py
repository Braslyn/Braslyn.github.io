"""
	Demo of re
	loriacarlos@gmail.com
	EF203 I-2019
"""
import re
list = ["21.5", "-1.33", "a1.5bc", ".25", "xyz", "  666.0%$ ", "  123 abc 345.67"  ]
pat = r"([+-]?\d+(?:\.\d+)?)"
# Notice ".25" is not accepted
def test_re(list):
	""" Test without pre-compile pattern """
	print(f"Testing '{pat}' against {list}")
	for case, h in enumerate(list):
		print()
		print(f"case={case:2d}) h='{h}'")
		resp_match = re.match(pat, h)
		resp_search= re.search(pat, h)

		if resp_match:
			print(f"Match results  for '{h}': {resp_match.groups()}")
		else:
			print(f"No match results for  '{h}'")

		if resp_search:
			print(f"Search results for '{h}': {resp_search.groups()}")
		else:
			print(f"No search results for  '{h}'")
	# Using findall
	as_string = " ".join(list)
	numbers = re.findall(pat, as_string)
	print()
	print(f"*** Now all numbers extracted from whole list= {list}***")
	for n in numbers:
		print(n, end=' ')
	print()

if __name__ == "__main__":
	print("*** Running test ***")
	test_re(list)