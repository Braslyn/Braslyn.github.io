"""
 loriacarlos@gmail.com
 EIF203 I-2019
"""
import re
TEST_FILE = '../data/out_office.txt'
lines = [ line.rstrip() for line in open(TEST_FILE, 'r', encoding='utf-8')]
RE = """^(\w+)   #name      
         (?:.*?) #skip
         (\d?\d)(?:[-/])(\d?\d)(?:[-/])(\d{4}) #from
         (?:.*?) #skip
         (\d?\d)(?:[-/])(\d?\d)(?:[-/])(\d{4}) #to
     """
if __name__ == "__main__":
	print("*** Testing date extraction using re ***")
	p = re.compile(RE, re.VERBOSE)
	for i, line in enumerate(lines):
		print(f"{i:2d}) Line='{line}'")
		print(f"--> Extracted data={p.findall(line)} ")