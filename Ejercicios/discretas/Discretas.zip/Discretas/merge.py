def merge_sort(a):
    def merge(b):
        if len(b)==2:
            if b[len(b)//2-1]>b[len(b)//2]:
                print(f"{b[len(b)//2-1]}   ,  {b[len(b)//2]}")
                b[len(b)//2-1],b[len(b)//2]=b[len(b)//2],b[len(b)//2-1]
                return b
            return [merge(b[:len(b)//2]) + merge(b[len(b)//2:])]
    return [merge(a[:len(a)//2])]+[merge(a[len(a)//2:])]




if __name__=="__main__":
    a=[9,5,4,7]
    print(merge_sort(a))