""" 
fecha:02/03/2019
Author Braslyn Rodriguez Ramirez 
Factor Redundnaica de una lista

"""
import timeit
margin=0
def enter(a):
    global margin
    margin+=1
    print(f"{' ' * margin}-> {a}")
    
def leave(res):
    global margin
    print(f"{' ' * margin} <- {res}")
    margin-=1
    return res

def redundancia(a):
    if a==[]: return 0
    if a[0] in a[1:]: return 0+redundancia(a[1:])
    if not a[0] in a[1:]: return 1+redundancia(a[1:])
    
def redundanciainstrumentado(a):
    enter(a)
    if a==[]: return leave(0)
    if a[0] in a[1:]: return leave(0+redundancia(a[1:]))
    if not a[0] in a[1:]: return leave(1+redundancia(a[1:]))
    
    
def redundancia2(a):
    return 1-redundancia(a)/len(a)


if __name__=="__main__":
    b =[4, 3, 6, 1, 4, 2, 1, 5, 7, 4, 2 ]
    print(f"redundancia({b})={redundancia2(b)}")
    #prueba de tiempos por csv
    a=list(range(100))
    with open("Factor_redundancia.csv","w")as file:
        file.write(f"n;Redundancia;\n")
        for i in range(len(a)):
            time_redundancia=timeit.timeit("redundancia(a)",globals=globals(),number=10)
            file.write(f"{i};{time_redundancia}\n")
        print("Listo")