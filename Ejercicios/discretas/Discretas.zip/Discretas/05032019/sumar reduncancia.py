""" 
fecha:02/03/2019
Author Braslyn Rodriguez Ramirez 
sumar elementos de un array

"""
import timeit

def sumar(a):
    if a==[]: return 0
    return a[0]+sumar(a[1:])
    
    
def buscar(x,a):
    for i in range(len(a)):
        if x==a[i]: return i
    return -1
    
def buscarinstrumentado(x,a):
    c=0
    for i in range(len(a)):
        c+=1
        if x==a[i]: return i
    return c

margin=0

def enter(a):
    global margin
    margin+=1
    print(f"{' ' * margin}-> {a}")
    
def leave(res):
    global margin
    print(f"{' ' * margin} <- {res}")
    margin-=1
    return res
    
    
def sumarinstrumentado(a):
    enter(a)
    if a==[]: 
        return leave(0)
    return leave(a[0]+sumarinstrumentado(a[1:]))

if __name__=="__main__":
    b=[1,8,6,5,4]
    print(f"sumarinstrumentado({b})={sumarinstrumentado(b)}")
    print(f"Buscar -> {buscarinstrumentado(-1,b)}")
    #prueba de tiempos por csv
    a=list(range(100))
    with open("Sumar.csv","w")as file:
        file.write(f"n;sumar;buscar\n")
        for i in range(len(a)):
            time_sumar=timeit.timeit("sumar(a)",globals=globals(),number=10)
            time_buscar=timeit.timeit("buscar(-1,a)",globals=globals(),number=10)
            file.write(f"{i};{time_sumar};{time_buscar}\n")
        print("Listo")
    
    