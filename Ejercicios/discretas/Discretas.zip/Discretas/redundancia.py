""" 
fecha:02/03/2019
Author Braslyn Rodriguez Ramirez 
sumar elementos de un array

"""

a =[4, 3, 6, 1, 4, 2, 1, 5, 7, 4, 2 ]

def redundancia(a):
    if a==[]: return 0
    if a[0] in a[1:]: return 0+redundancia(a[1:])
    if not a[0] in a[1:]: return 1+redundancia(a[1:])

def redundancia2(a):
    return 1-redundancia(a)/len(a)

print(redundancia2(a))