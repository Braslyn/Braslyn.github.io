lista=[1,2,3,4,5]
ele=5

def bytow(x,a):
    for i in range(0,len(a),2):
        if x==a[i]:return i
    return -1


def bytoworem(x,a):
    i=0
    while i<len(a):
        if i%2==0 and x==a[i]:return i
        i=i+1
    return -1

print(bytow(ele,lista))

print(bytoworem(ele,lista))

