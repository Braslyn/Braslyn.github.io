for i in range(0, 100, 1):
    print((4*i)+i//2 +5)