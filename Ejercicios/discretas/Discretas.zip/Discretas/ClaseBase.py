"""
Trabajo Karatsuba
Nombre: Braslyn Rodriguez Ramirez
"""
#from abc import ABC , abstractmethod
#@abstractmethod
class Numero:#Hay que hacer cambio y convertirlo en una clase base / interfaz
    
    def __init__(self,numero):
        """
        convierte los numeros del compilador a numeros propios de la clase
        """
        self.ListaN=self.crealista(numero)
        

    def crealista(numero):
        """
        crea una lista con un numero de python
        """
        lista=[]
        if numero==0:
            listaN.append(0)
        while numero!=0:
            lista.append(numero%10)
            numero//=10
        return lista


    def int(self):
        """
        Muestra la lista como numeros del compilador
        """
        aux=0
        inc=1
        for i in range(len(self.ListaN)):
            aux+=self.ListaN[i]*inc
            inc*=10
        return aux

    def __getitem__(self,index):
        """
        Muetra los numeros dentro de la lista (eje invertido "Provicional")
        """
        if type(index)==type(1):
            if index<len(self.ListaN) and index>-(len(self.ListaN)+1):
                return self.ListaN[-index]
        return -1

    def __repr__(self):
        """
        aprovecha la funcion int para mostrar los valores por string
        """
        return f"{self.int()}"

    def __mul__(self, mult):
        """
        Funcion basada en Karatsuba
        """
        return self.int()*mult.int()

    def __eq__(self,other):
        if type(other)==type(Numero):
            return self.int()==other.int()
        if type(other)==type(int):
            return self.int==other

    def __add__(self,lista2):
        """
        suma de dos numeros de la propia clase
        """
        aux=0#lleva los decimales centenas ... que superen la capacidad de la respectiva unidad
        aux=0#ayuda a llevar los decimales ....
        suma=0
        for i in range(len(self.ListaN)):
            suma=self.listaN[i]+lista2.listaN[i]
            
        return Karatsuba

    def multiplica_ortopedico(self, mult):
        """
        multiplicacion Tradicional
        """
        pass