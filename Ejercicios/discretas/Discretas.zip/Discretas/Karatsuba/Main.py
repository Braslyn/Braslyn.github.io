from ClaseBase import*
if __name__=="__main__":
    kar=Karatsuba(892)
    kar2=Karatsuba(102)