#from abc import ABC , abstractmethod
#@abstractmethod
class Karatsuba:
    
    def __init__(self,numero):
        self.ListaN=[]
        while numero!=0:
            self.ListaN.append(numero%10)
            numero//=10

    def int(self):
        aux=0
        inc=1
        for i in range(len(self.ListaN)):
            aux+=self.ListaN[i]*inc
            inc*=10
        return aux


    def __repr__(self):
        return f"{self.int()}"

    def __mul__(self, mult):
        return self.int()*mult.int()
    
    
    def multiplica_ortopedico(self, mult):
        pass