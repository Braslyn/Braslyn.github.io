"""
   Prueba warmup.py
   eif203 I-2019
    autores:Braslyn Rodriguez Ramirez
    fecha: 24/02/2019
    Uso:  Practica warm-up
"""

from warmup import *
def test_quadratic():
    print("--- Test Quadratic ---")
    sol = solve_quadratic(1, 2, 1)
    print(sol)
    sol = solve_quadratic(1, -2, 1)
    print(sol)
    sol = solve_quadratic(1, -1, -1)
    print(sol)
    sol = solve_quadratic(1, 0, 1)
    print(sol)
    print()
    
def test_odd_positions():
    print("--- Test Odd positions ---")
    a = [10,1,3,2,3,3,6,4,8,5]
    print(a, " -> ", sum_odd_positions(a))
    print()

def test_frequencies():
    print("--- Test Frequencies ---")
    a = ["c", "b", "a", "c", "c", "a", "z", "w", "a", "c"]
    print(a, " -> ", frequencies(a))
    print()
    
def test_invert():
    print("--- Test Invert ---")
    a = ["a", "b", "c", "d", "e"]
    print(a, " -> ", invert(a))
    print()

def test_cartesian():
    print("--- Test cartesian ---")
    a = [1, 2]
    b = ["c", "a", "d"]
    print(a, "X", b, " -> ", cartesian(a, b))
    print()
#
if __name__ == "__main__":
    print("*** Testing warmup ***")
    test_quadratic()
    test_odd_positions()
    test_frequencies()
    test_invert()
    test_cartesian()