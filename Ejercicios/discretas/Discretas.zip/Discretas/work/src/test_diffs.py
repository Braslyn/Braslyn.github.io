"""
    Tests diffs.py randomly
    loriacarlos@gmail.com
    EIF203 I-2019
"""
import diff
import random

if __name__ == "__main__":
    print("*** Testing diffs ***")
    random.seed(666999) # Seed is fixed such that results are the same always
    # 6 test cases will be tested
    for case in range(1, 7):
        print(f"Case {case}")
        pop = range(20)
        len_a = random.randint(3, 7)
        a = random.sample(pop, len_a)
        b = []
        len_b = random.randint(3, 14)
        # Produces changes randomly
        for _ in range(len_b):
            x = random.choice(a)
            r = random.randint(0, 100)
            if r <= 33: # 33% chance of preserving
                #x will be preserved if not repeated
                if x not in b: b.append(x)
                continue
            if r % 2 == 0: 
                y = random.choice(pop)
                # x will be replaced by y (if not the same)
                if y not in b: b.append(y)
                continue
            # x will be deleted
        
        print(f"{case})Testing with a={a}, b={b}")
        print("*** Results ***")
        ia, ca, da = diff.diff(a, b)
        print(f"added={ia}, preserved={ca}, deleted={da}")
        print()
            