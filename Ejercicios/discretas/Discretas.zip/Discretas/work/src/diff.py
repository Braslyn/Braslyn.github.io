"""
   Prueba warmup.py
   eif203 I-2019
    autores:Braslyn Rodriguez Ramirez
			Juan Manuel Sandi Angulo
			Brandon Mendez Cano
			Victor Andres Ampie Cabezas
    fecha: 26/02/2019
"""
def diff(a,b):
	add=[]
	pres=[]
	deli=[]
	for j in range(len(b)):
		if (buscarItm(a,b[j])):
			pres.append(b[j])
		elif (not buscarItm(a,b[j])):
			add.append(b[j])
	for i in range(len(a)):
		if (not buscarItm(b,a[i])):
			deli.append(a[i])
	return (add, pres, deli)
	
def buscarItm(a, b):
	for j in range(len(a)):
		if (a[j]==b):
			return True
	return False