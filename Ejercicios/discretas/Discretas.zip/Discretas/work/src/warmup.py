"""
    Ejercicio warm-up
    eif203 I-2019
    autores:Braslyn Rodriguez Ramirez
			Juan Manuel Sandi Angulo
			Brandon Mendez Cano
			Victor Andres Ampie Cabezas
    fecha: 26/02/2019
    Uso:  Practica warm-up
       import warmup as wu
       o
       from warmup import *
"""
import math

def solve_quadratic(a, b, c):
    """
      Resuelve la cuadratica a*x**2 + b*x + c = 0
    """
    respuestas=str(a)+"*X**2 + "+str(b)+"*x + "+str(c)+"=0 \n"
    calculo=0
    if((b**2-4*a*c)<0):
        return respuestas+"none"
    elif((b**2-4*a*c)==0):
        respuestas+=str((-b / (2*a)))
        return respuestas
    else:
        calculo=b**2-4*a*c
        respuestas+=str((-b + math.sqrt(calculo)) / (2*a))+" , "
        respuestas+=str((-b - math.sqrt(calculo)) / (2*a))
        return respuestas
    pass

def sum_odd_positions(a):
    """
      Suma los elementos a[i] tales que i es impar
    """
    acumulador=0
    for i in range(1,len(a),2):
        acumulador+=a[i]
    return acumulador
    pass

def frequencies(a):
    """
      Devuelve un diccionario {..., a[i]: vi, ...} donde vi es la frecuencia 
      de a[i] para cada i 
    """
    dicc={}
    for i in range(len(a)):
        analiz=a[i]
        counter=0
        for j in range(len(a)):
            if(analiz==a[j]):
                counter+=1
        dicc[a[i]]=counter
    return dicc
    pass

def invert(a):
    b = list(range(len(a)))
    r=0
    for i in range(len(a)):
        b[r]=a[-(i+1)]
        r+=1
    return b
    pass

def cartesian(a, b):
    cartesiano="["
    for i in range(len(a)):
        for j in range(len(b)):
            cartesiano+="( "+str(a[i])+" , '"+b[j]+"'), "
    cartesiano+="]"
    return cartesiano
    pass
 