import timeit
def F(n):
	for i in range(1,n+1):
		for j in range(1,n+1):
			print("Hola mundo")

if __name__=="__main__":
    with open("Ejercicio_12.csv","w")as file:
        file.write(f"n;ejer_12;\n")
        for i in range(100):
            time_F=timeit.timeit("F(i)",globals=globals(),number=50)
            file.write(f"{i};{time_F}\n")
        print("Listo")