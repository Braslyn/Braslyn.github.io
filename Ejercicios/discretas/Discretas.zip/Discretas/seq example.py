from abc import ABC , abstractmethod
from sympy import *
#from functools import total_ordering
#functools me presta el decorador para añadir funciones      extra a lo que ya tenemos @total_ordering 
class Seq(ABC):#si no especifica hereda de object
    @abstractmethod

    def term(self,n):
        pass



class ArithSeq(Seq):
    @staticmethod #para definir metodos estaicos para "servivios"
    def foo(x):return x**.5
    

    def __init__(self,base,incr):
        self.base=base
        self.incr=incr

    def __str__(self):
        return f"""
        s(n) = {self.base}          si n=0
        s(n) = {self.incr} + s(n-1) si n>0
        """

    def __mul__(self, other):
        return ArithSeq(self.base*other.base,self.incr*other.incr)

    def __repr__(self):
        return self.__str__()

    def term(self, n):
        return self.base if n==0 else self.incr + self.term(n-1)

    def __getitem__(self,n):
        return self.term(n)

    def __call__(self,n):
        return self.term(n)
        
    def __add__(self,other):
        return ArithSeq(self.base+other.base,self.incr+other.incr)

class HLCC(Seq):
    def __init__(self,a,b,s0,s1):
        self.A=a
        self.B=b
        self.S0=s0
        self.S1=s1
        
        
    def term(self,n):
        if n==0:
            return self.S0
        if n==1:
            return self.S1
        return self.A*self.term(n-1) + self.B*self.term(n-2)
        
    def solve(self):#seria oportuno usar un chache en esta funcion
        def solve_one(r):#investigar como evaluar una expresion en sympy
            raise Exception("to do")
        def solve_two(r1,r2):
            A=Matrix([[1,1],[r1,r2]])
            B=Matrix([[self.S0],[self.S1]])
            (alpha,beta)= simplify(self.A**-1*self.B)
            n=symbols('n')
            return alpha*r1**n + beta*r2**n
        x=symbols('x')
        pc= x**2-self.A*x-self.B*x
        root=solve(pc)
        if len(root)==1:
            return solve_one(root)
        else:
            return solve_two(root[0],root[1])

if __name__=="__main__":
    arit=ArithSeq(5,8)
    arit2=ArithSeq(3,6)
    n=3
    print(f"base=={arit.base} , increment=={arit.incr} , arit({n})={arit.term(n)}")
    
    
    fibo=HLCC(1,1,1,1)
    notable=HLCC(2,-1,1,0)
    print(fibo.term(5))
    print(fibo.solve())