"""
author: Braslyn Rodriguez Ramirez
fecha: 011/03/2019
Uso: Ejercicios
"""
def S(n):
    return -1 if n==0 else -S(n-1)
def S_iter(n):
    f=-1
    for i in range(n):
        f=f*-1
    return f
 
def S_formula(n):
    return (-1)**n*-1
    
def S2(n):
    return 1 if n==0 else 2*S2(n//2)+5*n

def S2_iter(n):
    return 2*n+5*n
    
def S2_iter2(n):
    return (n+1)*((7*n)//2)
    return (7*n**2+7*n)//2
  
def a(n):
    return 5 if n==0 else 2*n*a(n-1)
    
def a_iter(n):
    return 2**n-1 * n**n-1/-1 *5

if __name__=="__main__":
    for n in range(5):
        print(f"{n}, s(n)={S(n)} ")
    print("\n")
    for n in range(5):
        print(f"{n}, s_formula(n)={S_formula(n)} ")
    print("\n")
    for n in range(5):
        print(f"{n}, S2(n)={S2(n)} ")
    print("\n")
    for n in range(5):
        print(f"{n}, S2_iter(n)={S2_iter(n)} ")
    print("\n")
    for n in range(5):
        print(f"{n}, S2_iter2(n)={S2_iter2(n)} ")
    print("\n")
    for n in range(5):
        print(f"{n}, a(n)={a(n)} ")
    print("\n")
    for n in range(5):
        print(f"{n}, a_iter(n)={a_iter(n)} ")
    print("\n")
        
        