public class Nodo<T>{
    private T data;
    private Nodo<T> next;

    public Nodo(T data,Nodo<T> next){
        this.data=data;
        this.next=next;
    }
    public void setNext(Nodo<T> nodo){
        this.next=nodo;
    }
    public void setData(T data){
        this.data=data;
    }
    public Nodo<T> getNext(){
        return next;
    }
    public T getData(){
        return data;
    }
}
