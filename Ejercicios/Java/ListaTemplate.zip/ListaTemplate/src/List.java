import java.security.KeyStore;

public class List<T>{

    private int cant;
    private Nodo<T> primer;

    public List(){
        primer =null;
        cant=0;
    }

    public void deleteAll(){
        primer =null;
    }

    public boolean add(T data) {
        if (isEmpty()) {
            primer = new Nodo<>(data, null);
            cant++;
            return true;
        }
        Nodo<T> aux = primer;
        while(aux.getNext() != null) {
            aux = aux.getNext();
        }
        cant++;
        aux.setNext(new Nodo<>(data, null));
        return true;
    }

    public void Remove(int pos){
        if (pos>0 && pos<cant){
            Nodo<T> aux= primer;
            Nodo<T> anterior=aux;
            while (pos--!=0){
                anterior=aux;
                aux=aux.getNext();
            }
            anterior.setNext(aux.getNext());
        }
    }
    public T Get(int pos) {
        if(!isEmpty()) {
            if (pos >= 0 && pos < cant) {
                Nodo<T> aux = primer;
                while (pos-- != 0) {
                    aux = aux.getNext();
                }
                return aux.getData();
            }
        }
        return null;
    }

    public int getCant(){
        return cant;
    }

    public boolean isEmpty(){
        return primer ==null;
    }

  @Override
    public String toString(){//muy Ineficiente por 'String'
        String out="[ ";
        Nodo aux= primer;
        while (aux!=null){
            out+=aux.getData();
            if(aux.getNext()!=null)
                out+=", ";
            aux=aux.getNext();
        }
        return out+" ]";
    }

}
