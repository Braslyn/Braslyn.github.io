public class main {

    public static void main(String[] args) {
        List<Integer> lista= new List<>();
        for(int i=0;i<10;i++) {
            lista.add(i);
        }
        System.out.println(lista.toString());
    }

}
