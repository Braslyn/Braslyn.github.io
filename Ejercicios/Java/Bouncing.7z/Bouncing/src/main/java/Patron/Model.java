/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Patron;

import Objects.Ball;
import Objects.Raqueta;
import Objects.Rectangle;
import java.util.Observable;
import java.util.Random;

/**
 *
 * @author Brazza
 */
public class Model extends Observable{
    private Rectangle R;
    private Ball B;
    private Raqueta ra;
    
    public Model(){
        ra=new Raqueta(155,350,20,20,80,20);
        B=new Ball(25,160,170,10,10);
        R=new Rectangle(500,400,50,50);
    }
    public void step(){
        Random rand = new Random();
        int randm =rand.nextInt(360);
        B.move(this);
       // ra.move(this, randm);
        this.setChanged();
        this.notifyObservers();
    }

    public Rectangle getR() {
        return R;
    }

    public void setR(Rectangle R) {
        this.R = R;
    }

    public Ball getB() {
        return B;
    }

    public void setB(Ball B) {
        this.B = B;
    }

    public Raqueta getRa() {
        return ra;
    }

    public void setRa(Raqueta ra) {
        this.ra = ra;
    }
    
    @Override
    public void addObserver(java.util.Observer o){
        super.addObserver(o);
        setChanged();
        notifyObservers();
    }
}
