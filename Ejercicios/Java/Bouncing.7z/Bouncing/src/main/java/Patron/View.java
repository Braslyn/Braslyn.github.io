/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Patron;

import Objects.Ball;
import Objects.Raqueta;
import Objects.Rectangle;
//import com.sun.prism.paint.Color;
import java.awt.Graphics;
import java.util.Observable;
import javax.swing.JFrame;

/**
 *
 * @author Brazza
 */
public class View extends JFrame implements java.util.Observer{
    Model model;
    Controller controller;
    public View(){
        this.setSize(800,600);
        this.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
    }

    public Model getModel() {
        return model;
    }

    public void setModel(Model model) {
        this.model = model;
        model.addObserver(this);
    }

    public Controller getController() {
        return controller;
    }

    public void setController(Controller controller) {
        this.controller = controller;
    }
    
    @Override
    public void update(Observable o,Object arg){
        this.repaint();
    }

    private void RenderModel(Model m, Graphics g) {
      RenderRectangle(m.getR(),g);
      RenderRaqueta(m.getRa(),g);
      RenderBall(m.getB(),g);  
    }
    @Override
    public void paint(Graphics g){
        super.paint(g);
        this.RenderModel(model, g);
        
    }
    private void RenderRectangle(Rectangle r, Graphics g) {
        g.setColor(java.awt.Color.BLACK);
        g.drawRect(r.getX(), r.getY(),r.getWeight(), r.getHigh());
    }

    private void RenderRaqueta(Raqueta ra,Graphics g) {
        g.setColor(java.awt.Color.BLUE);
        g.fillRect(ra.getX(), ra.getY(), ra.getWidth(), ra.getHeight());
    }

    private void RenderBall(Ball b, Graphics g) {
         g.setColor(java.awt.Color.red);
         g.fillOval(b.getX(),b.getY(), 2*b.getRadio(), 2*b.getRadio());
        
    }
}