package Objects;

import Patron.Model;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Brazza
 */
public class Ball extends Actor {

    private int radio;

    @Override
    public void move(Model m) {



//        System.out.println("Y+radio="+ (y+radio) + " raY= "+ray);
//        System.out.println("Y+radio="+ (y-radio) + " raYH= "+(ray+rah));

        
        this.y+=this.getDy();
        this.setX(this.getDx());
    }

    public int getRadio() {
        return radio;
    }

    public void setRadio(int radio) {
        this.radio = radio;
    }

    public Ball(int radio, int x, int y, int dx, int dy) {
        super(x, y, dx, dy);
        this.radio = radio;
    }

}
