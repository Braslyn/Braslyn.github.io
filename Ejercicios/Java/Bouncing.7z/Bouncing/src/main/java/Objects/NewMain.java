package Objects;

import Patron.Controller;
import Patron.Model;
import Patron.View;

public class NewMain {
    public static void main(String[] args) throws InterruptedException{
        int N =3000;
        Model model=new Model();
        View view= new View();
        Controller contr=new Controller(model,view);
        view.setVisible(true);
        for (int i = 0; i < N; i++) {
            Thread.sleep(150);
            model.step();
        }
    }
}
