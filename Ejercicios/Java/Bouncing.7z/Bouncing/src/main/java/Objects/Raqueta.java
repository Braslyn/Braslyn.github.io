package Objects;


import Patron.Model;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Brazza
 */
public class Raqueta extends Actor{
    private int width;
    private int height;
    
    public int getWidth() {
        return width;
    }
    
    public void setWidth(int width) {
        this.width = width;
    }
    
    public int getHeight() {
        return height;
    }
    
    public void setHeight(int height) {
        this.height = height;
    }

    public Raqueta(int x, int y, int dx, int dy,int width, int height) {
        super(x, y, dx, dy);
        this.width = width;
        this.height = height;
    }
    
   public void move(Model m,int dir){
       int rh=m.getR().getHigh(),rx=m.getR().getX(),ry=m.getR().getY(),rw=m.getR().getWeight(),x=this.getX(),y=this.getY();
       System.out.println(dir);
       
       
       if(90>=dir && dir>0){//Derecha
           if(x+width < rx + rw ){
               this.setX(x+this.getDx());
           }
           
       }else if(90<dir && 180>=dir){//abajo
            if(y+height<ry+rh){
               this.setY(y+this.getDy());
           }
            
       }else if(180<dir && 270>=dir){//Izquierda
           if(x > rx){
              this.setX(x-this.getDx());
           }
           
       }else{//arriba
           
            if(y>ry){
               this.setY(this.getY()-this.getDy());
           }
       }
   }
}
