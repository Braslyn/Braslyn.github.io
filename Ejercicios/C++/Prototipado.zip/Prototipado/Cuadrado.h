#ifndef CUADRADO_H
#define CUADRADO_H
#include "Figura.h"
class Cuadrado :public Figura{
public:
	Cuadrado(int x,int y,string color,double lado);
	Cuadrado(Cuadrado& const cuadrado);
	~Cuadrado();
	virtual string toString();
	virtual Figura* clone();
	double area();
	double perimetro();
private:
	double lado;
};
#endif // !CUADRADO
