#include "Factory.h"

Factory::Factory(){
	figuras.push_back(new Circulo(0,0,"Rojo",2));
	figuras.push_back(new Cuadrado(0,0,"Rojo",2));
}

Factory::~Factory(){}

Figura* Factory::getfigura(Tipos tipo, Colores color)
{
	return figuras[tipo*color-1]->clone();
}

std::ostream& operator<<(std::ostream& out, Factory& fact){
	int index = 0;
	std::vector<Figura*>::iterator iterador;
	out << "Lista de Figuras\n";
	for (iterador = fact.figuras.begin(); iterador != fact.figuras.end(); iterador++) {
		out << "Numero #" << index++ << "\n";
		out << (*iterador)->toString();
	}
	return out;
}
