#include "Figura.h"

Figura::Figura(int x, int y, string color):x(x),y(y),color(color){}

Figura::Figura(Figura& const figura):x(figura.x),y(figura.y),color(figura.color){}//circulo->figura

Figura::~Figura(){}
