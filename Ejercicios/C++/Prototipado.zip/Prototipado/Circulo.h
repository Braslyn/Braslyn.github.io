#ifndef CIRCULO_H
#define CIRCULO_H
#include "Figura.h"
class Circulo :public Figura{
public:
	Circulo(int x,int y,string color,double r);
	Circulo(Circulo& const circulo);
	~Circulo();
	virtual Figura* clone();//obligado por figura
	double area();
	double perimetro();
	virtual string toString();//obligado por figura / java 
private:
	double r;
};
#endif // !CIRCULO_H