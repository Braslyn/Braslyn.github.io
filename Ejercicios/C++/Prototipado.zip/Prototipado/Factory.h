#ifndef FACTORY_H
#define FACTORY_H
#include "Circulo.h"
#include "Cuadrado.h"
#include <vector>
enum Colores {//clasecillas que guarda datos constantes
	rojo = 1
};

enum Tipos{
	cuadrado=2,circulo=1
};

class Factory{//repositorio de figuras
public:
	Factory();
	~Factory();
	Figura* getfigura(Tipos tipo,Colores color);
	friend std::ostream& operator<<(std::ostream& out, Factory&);
private:
	std::vector<Figura*> figuras;
};

#endif // !Factory
