#ifndef FIGURA_H
#define FIGURA_H
#include <string>
#include <sstream>
#define PI 3.1416 
using std::string;

class Figura{//C.abs -> Cliente
public:
	Figura(int x,int y,string color);
	Figura(Figura& figura);
	~Figura();
	virtual string toString()=0;
	virtual Figura* clone() = 0;
protected:
	int x;
	int y;
	string color;
};

#endif // FIGURA
