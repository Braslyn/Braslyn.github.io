#include "Circulo.h"

Circulo::Circulo(int x, int y, string color, double r):Figura(x,y,color),r(r){}

Circulo::Circulo(Circulo& const circulo):Figura(circulo),r(circulo.r){}

Circulo::~Circulo(){}

Figura* Circulo::clone(){
	return new Circulo(*this);
}

double Circulo::area(){
	return PI*r*r;
}

double Circulo::perimetro(){
	return PI*2*r;
}

string Circulo::toString(){
	std::stringstream out;
	out << "Circulo\n"<<"(x,y)= "<<x<<","<<y<<"\n";
	out << "(Area,Perimetro)= " << area() << "," << perimetro() << "\n";
	out << "Color= " << color<<"\n";
	return out.str();
}
