#include "Factory.h"
#include <iostream>
#include <Windows.h>
enum Opciones{//Clase repositorio -> variables constantes
	lista='1',pedir='2',salir='3'
};

int main() {
	Factory fact;
	char index=' ';
	while (index!='3'){
		std::cout << "1 Lista de Figuras\n2 Pedir Figura \n3 Salir\n->";
		std::cin >> index;
		switch (index) {
		case Opciones::lista:
			std::cout << fact;
			system("pause");
			break;
		case Opciones::pedir: {

			std::cout << "Digite La figura que desea\n";
			auto x = fact.getfigura(Tipos::circulo, Colores::rojo);
			std::cout << x->toString();
			delete x;
			system("pause");
		}
			break;
		case Opciones::salir:

			break;
		default:
			std::cout << "Opcion invalida!";
			system("pause");
			break;
		}
		system("cls");
	}



	auto figura =fact.getfigura(Tipos::circulo, Colores::rojo);
	auto x = figura->clone();
	std::cout << x;
	return 0;
}