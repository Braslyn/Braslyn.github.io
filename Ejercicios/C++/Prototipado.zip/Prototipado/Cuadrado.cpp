#include "Cuadrado.h"

Cuadrado::Cuadrado(int x, int y, string color, double lado):Figura(x,y,color),lado(lado){}

Cuadrado::Cuadrado(Cuadrado& const cuadrado):Figura(cuadrado),lado(cuadrado.lado){}

Cuadrado::~Cuadrado(){}

string Cuadrado::toString(){
	std::stringstream out;
	out << "Cuadrado\n" << "(x,y)= " << x << "," << y << "\n";
	out << "(Area,Perimetro)= " << area() << "," << perimetro() << "\n";
	out << "Color= " << color << "\n";
	return out.str();
}

Figura* Cuadrado::clone(){
	return new Cuadrado(*this);
}

double Cuadrado::area(){
	return lado*lado;
}

double Cuadrado::perimetro(){
	return 4*lado;
}
