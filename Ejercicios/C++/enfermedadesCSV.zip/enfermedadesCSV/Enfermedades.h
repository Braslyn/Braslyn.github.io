#ifndef ENFERMEDADES_H
#define ENFERMEDADES_H
#include "Enfermedad.h"
#include "Persona.h"
#include <fstream>
#include <sstream>
#include <vector>
#include <regex>
using std::vector;
class Enfermedades
{
public:
	Enfermedades(string archivo);
	~Enfermedades();
	vector<Enfermedad*>* AnalisisPersona(Persona& persona);
private:
	vector<Enfermedad*> lista;
};
#endif // !ENFERMEDADES_H
