#include "Enfermedades.h"
#include "json.hpp"


using json = nlohmann::json;
int main() {
	//Lectura de Json
	Enfermedades listaenf("enfermedades");
	vector<Persona*> personas;
	std::ifstream file("personas.json", std::ios::in);
	string result,aux;
	while (file.good()){
		std::getline(file,aux);
		result += aux + "\n";
	}
	auto parse = json::parse(result);
	//auto elem =parse[1];
	//auto x= elem["nombre"].get<string>();
	for (auto& ele : parse) {
		personas.push_back(new Persona(ele["nombre"].get<string>(), ele["adn"].get<string>()));
	}

	std::cout << "Lista de personas\n";
	for (auto& per:personas){
		std::cout << per->getNombre() << "Tiene:\n";
		for (auto& enf:*listaenf.AnalisisPersona(*per)){
			std::cout << *enf;
		}
	}
	
	//Termina la lectura
	return 0;
}