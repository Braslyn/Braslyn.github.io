#include "Persona.h"

Persona::Persona(string nombre, string adn):nombre(nombre),ADN(adn)
{
}

Persona::~Persona()
{
}

string Persona::getNombre()
{
	return nombre;
}

string Persona::getADN()
{
	return ADN;
}

void Persona::setNombre(string nombre){
	this->nombre = nombre;
}

void Persona::setADN(string adn){
	this->ADN = adn;
}
