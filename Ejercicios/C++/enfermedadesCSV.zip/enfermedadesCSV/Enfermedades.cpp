#include "Enfermedades.h"

Enfermedades::Enfermedades(string archivo){
	std::ifstream file(archivo+".csv", std::ios::in);
	string line,nombre, cadena;
	std::getline(file, line, '\n');
	while (file.good()){
		std::getline(file, line, '\n');
		std::stringstream aux(line);
		std::getline(aux, nombre, ',');
		std::getline(aux, cadena);//[CTGA]+
		lista.push_back(new Enfermedad(nombre, cadena));
	}
	lista.pop_back();
	file.close();
}

Enfermedades::~Enfermedades(){
	for (auto& el:lista ){//Podria no ser necesario
		delete el;
	}
}

vector<Enfermedad*>* Enfermedades::AnalisisPersona(Persona& persona){
	//aqui el regex --- RE
	auto lista = new vector<Enfermedad*>();

	std::smatch mt;

	for (auto& enf:this->lista){
		if (persona.getADN().find(enf->getCoincidencia()) != string::npos)
			lista->push_back(enf);
	}
	return lista;
}
