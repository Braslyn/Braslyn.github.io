#ifndef ENFERMEDAD_H
#define ENFERMEDAD_H
#include "Persona.h"
class Enfermedad{
public:
	Enfermedad(string nombre,string coincidencia);
	~Enfermedad();
	string getCoincidencia();
	friend std::ostream& operator<<(std::ostream& out, Enfermedad& enf);
private:
	string nombre;
	string coincidencia;
};

#endif // !ENFERMEDAD_H
