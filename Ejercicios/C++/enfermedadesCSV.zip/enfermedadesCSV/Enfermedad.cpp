#include "Enfermedad.h"

Enfermedad::Enfermedad(string nombre, string coincidencia):nombre(nombre),coincidencia(coincidencia)
{
}

Enfermedad::~Enfermedad()
{
}

string Enfermedad::getCoincidencia()
{
	return coincidencia;
}

std::ostream& operator<<(std::ostream& out, Enfermedad& enf){
	out << enf.nombre << "->" << enf.coincidencia << "\n";
	return out;
}
