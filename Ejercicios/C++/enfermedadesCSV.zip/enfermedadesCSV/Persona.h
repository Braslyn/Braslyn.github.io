#ifndef PERSONA_H
#define PERSONA_H
#include <string>
using std::string;
#include <iostream>
class Persona
{
public:
	Persona(string nombre,string adn);
	~Persona();
	string getNombre();
	string getADN();
	void setNombre(string nombre);
	void setADN(string adn);
private:
	std::string nombre;
	std::string ADN;
};


#endif // !PERSONA_H
