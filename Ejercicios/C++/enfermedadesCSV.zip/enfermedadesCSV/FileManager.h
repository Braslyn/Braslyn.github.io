//
// Created by Maikol Guzman on 10/16/20.
//

#ifndef SERIALIZATION_JSON_FILEMANAGER_H
#define SERIALIZATION_JSON_FILEMANAGER_H

#include "json.hpp"

#include <string>
#include "Persona.h"

using namespace std;
using nlohmann::json;

class FileManager {
public:
    static string serialize(const vector<Persona>& _personList);
    static vector<Persona> deserialize(const string& _data);
};


#endif //SERIALIZATION_JSON_FILEMANAGER_H
