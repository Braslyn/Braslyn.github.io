//
// Created by Maikol Guzman on 10/16/20.
//

#include "FileManager.h"


/**
 * Custom to_json method automatically called.
 * @param _json the Json Object
 * @param _person the Model
 */
void to_json(json &_json, Persona &_person) {
    _json = json{
            {"nombre", _person.getNombre()},
            {"adn", _person.getADN()},
    };
}

/**
 * Custom from_json method automatically called.
 * @param _json  the Json Object
 * @param _person the Model
 */
void from_json(const json&_json, Persona&_person) {
    _person.setNombre(_json.at("nombre").get<string>());
    _person.setADN(_json.at("ADN").get<std::string>());
}

/**
 * This method will serialize the vector
 * @param _personList
 * @return the string with the json array
 */
string FileManager::serialize(const vector<Persona>& _personList) {
    //json jsonData(_personList);
    //string jsonArray = jsonData.dump();
    return "";
}

/**
 * This method deserialize the string to object
 * @param _data the string json data
 * @return the array of objects
 */
vector<Persona> FileManager::deserialize(const string& _data) {
    json jsonData = json::parse(_data);
    vector<Persona> personList;

    return personList;
}
