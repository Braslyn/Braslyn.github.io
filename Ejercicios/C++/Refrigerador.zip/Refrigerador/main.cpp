#include "Refrigedor.h"

int main() {
	bool salida = false;
	Refrigerador R;
	try {
		char menu;
		while (!salida){
			std::cout << "Menu\n1)a�adir Alimento\n2)Mostrar inventario\n3)salir\n";
			std::cin >> menu;
			switch (menu)
			{
			case '1':{
				char submenu;
				std::string nombre,color;
				int proteina;
				bool congelado;
				system("cls");
				std::cout << "1)Carne 2)Vegetal\n";
				std::cin >> submenu;
				switch (submenu) {
				case '1':
					std::cout << "Digite Nombre,proteina,congelado\n";
					std::cin>>nombre;
					std::cin >> proteina;
					std::cin >> congelado;
					R.guardarAlimento(new Carne(nombre, proteina, congelado));
					break;
				case '2':
					std::cout << "Digite Nombre,proteina,color\n";
					std::cin >> nombre;
					std::cin >> proteina;
					std::cin >> color;
					R.guardarAlimento(new Vegetal(nombre, proteina, color));
					break;
				}
				}break;
			case '2':
				system("cls");
				std::cout << R;
				break;
			case '3':
				std::cout << "Apagando.....\n";
				salida = true;
				break;
			default:
				std::cout << "Comando desconocido";
				break;
			}
			system("pause");
			system("cls");
			R.ComprobarEstado();
		}
	}catch (RefriExcepcion& RE){
		std::cout << RE.What();
	}catch (const std::exception& Ex) {
		std::cout << Ex.what();
	}catch (...) {
		std::cout << "Error desconocido --- estado critico\n";
	}

	return 0;
}