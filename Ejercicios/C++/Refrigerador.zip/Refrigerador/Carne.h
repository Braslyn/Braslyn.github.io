#ifndef CARNE_H
#define CARNE_H
#include "Alimento.h"

class Carne:public Alimento{
public:
	Carne(std::string nombre, int proteina,bool congelado);
	~Carne();
	std::string toString();
	friend std::ostream& operator<<(std::ostream& out,Carne* veg);
private:
	bool congelado;
};

#endif // !CARNE_H
