#include "Carne.h"

Carne::Carne(std::string nombre, int proteina, bool congelado):Alimento(nombre,proteina),congelado(congelado){}

Carne::~Carne(){}

std::string Carne::toString(){
	return Alimento::toString()+" congelado: "+(congelado?"si":"no" )+"\n";
}

std::ostream& operator<<(std::ostream& out, Carne& veg)
{
	out << veg.toString();
	return out;
}

std::ostream& operator<<(std::ostream& out, Carne* veg)
{
	out << veg->toString();
	return out;
}
