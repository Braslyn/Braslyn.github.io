#ifndef LISTA_H
#define LISTA_H
#include <iostream>

template <class T>
struct Nodo{
	T dato;
	Nodo* next;
	Nodo* last;
};

template <class T>
class Lista{
public:
	Lista();
	~Lista();
	void operator+(T&);//a�adir
	template <class R>
	friend std::ostream& operator<<(std::ostream& out, Lista<R>& lista);
	int getCant();
private:
	int cant;
	Nodo<T>* primero;
};



#endif // !LISTA_H

template<class T>
inline Lista<T>::Lista():primero(nullptr),cant(0){}

template<class T>
inline Lista<T>::~Lista(){}

template<class T>
inline void Lista<T>::operator+(T& dato){
	Nodo<T>* nuevo= new Nodo<T>();
	nuevo->dato = dato;
	nuevo->next = nullptr;
	if (primero==nullptr) {
		primero = nuevo;
		nuevo->last = nullptr;
		cant++;
		return;
	}
	Nodo<T>* aux = primero;
	while (aux->next!=nullptr){
		aux = aux->next;
	}
	cant++;
	aux->next = nuevo;
	nuevo->last = aux;
}

template<class T>
inline int Lista<T>::getCant()
{
	return cant;
}

template<class R>
inline std::ostream& operator<<(std::ostream& out, Lista<R>& lista){
	out << "[";
	Nodo<R>* aux = lista.primero;
	while (aux!=nullptr){
		out << aux->dato;
		if (aux->next != nullptr)
			out << ",";
		aux=aux->next;
	}
	out << "]";
	return out;
}
