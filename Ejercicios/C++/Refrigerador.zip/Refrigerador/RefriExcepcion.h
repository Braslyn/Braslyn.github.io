#ifndef REFRIEXCEPCION_H
#define REFRIEXCEPCION_H
#include <string>
class RefriExcepcion{
public:
	RefriExcepcion(int codigo);
	~RefriExcepcion();
	std::string What();
private:
	int codigo;
};

#endif // !REFRIEXCEPCION_H
