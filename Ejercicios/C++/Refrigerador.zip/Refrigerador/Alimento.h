#ifndef ALIMENTO_H
#define ALIMENTO_H
#include <string>
#include <sstream>
class Alimento{
public:
	Alimento(std::string nombre,int proteina);
	~Alimento();
	virtual std::string toString();
	friend std::ostream& operator<<(std::ostream& out, Alimento* veg);
private:
	std::string nombre;
	int proteina;
};

#endif // !ALIMENTO_H
