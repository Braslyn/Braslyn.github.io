#include "Refrigedor.h"

Refrigerador::Refrigerador(){}

Refrigerador::~Refrigerador()
{
}

void Refrigerador::guardarAlimento(Alimento* alimento){
	if (lista.getCant()>=MAX){
		throw std::exception("El almacenamiento maximo de el refigerador ha sido alcanzado",200);
	}
	lista + alimento;
}

void Refrigerador::ComprobarEstado(){
	srand(static_cast<unsigned int>(time(NULL)));
	int estado = rand() % 400 + 100;
	if (estado<100){
		throw RefriExcepcion(150);
	}
	else if (estado > 300) {
		throw RefriExcepcion(300);
	}
}

std::ostream& operator<<(std::ostream& out, Refrigerador& R)
{
	out << "---- Refrigerador ---- \n";
	out << R.lista;
	return out;
}
