#ifndef REFRIGEDOR_H
#define REFRIGEDOR_H
#define MAX 10
#include "RefriExcepcion.h"
#include "Carne.h"
#include "Vegetales.h"
#include "Lista.h"
#include <stdlib.h>     /* srand, rand */
#include <time.h>  
#include <Windows.h>

class Refrigerador
{
public:
	Refrigerador();
	~Refrigerador();
	void guardarAlimento(Alimento* alimento);
	void ComprobarEstado();
	friend std::ostream& operator<<(std::ostream& out, Refrigerador& R);
private:
	Lista<Alimento*> lista;
};

#endif // !REFRIGEDOR_H



