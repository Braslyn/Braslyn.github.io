#include "Alimento.h"

Alimento::Alimento(std::string nombre, int proteina):nombre(nombre),proteina(proteina){}

Alimento::~Alimento()
{
}

std::string Alimento::toString(){
	std::stringstream out;
	out << "Nombre: " << nombre << " proteina: " << proteina;
	return out.str();
}

std::ostream& operator<<(std::ostream& out, Alimento* veg)
{
	out << veg->toString();
	return out;
}
