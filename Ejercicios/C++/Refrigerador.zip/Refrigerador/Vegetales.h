#ifndef VEGETAL_H
#define VEGETAL_H
#include "Alimento.h"
class Vegetal: public Alimento{
public:
	Vegetal(std::string nombre, int proteina,std::string color);
	~Vegetal();
	std::string toString();
	friend std::ostream& operator<<(std::ostream& out, Vegetal* veg);
private:
	std::string color;
};


#endif // !VEGETAL_H
