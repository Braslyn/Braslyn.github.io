#include "RefriExcepcion.h"

RefriExcepcion::RefriExcepcion(int codigo):codigo(codigo){}

RefriExcepcion::~RefriExcepcion(){}

std::string RefriExcepcion::What(){
	switch (codigo){
	case 300:
		return "Fallo de motor";
		break;
	case 150:
		return "Fallo de congelador";
		break;
	default:
		return "Error desconocido";
		break;
	}
}
