#include "Vegetales.h"

Vegetal::Vegetal(std::string nombre, int proteina, std::string color):Alimento(nombre,proteina),color(color){}

Vegetal::~Vegetal(){}

std::string Vegetal::toString()
{
	return Alimento::toString()+" color:"+color+"\n";
}

std::ostream& operator<<(std::ostream& out, Vegetal& veg)
{
	out << veg.toString();
	return out;
}

std::ostream& operator<<(std::ostream& out, Vegetal* veg)
{
	out << veg->toString();
	return out;
}
