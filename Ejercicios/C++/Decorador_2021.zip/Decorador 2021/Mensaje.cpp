#include "Mensaje.h"

std::ostream& operator<<(std::ostream& out, Mesaje* obj)
{
	out << obj->toString();
	return out;
}
