#include "consola.h"

Consola::Consola(std::string Nombre):Nombre(Nombre){}

Consola::~Consola(){}

std::string Consola::getNombre()
{
	return Nombre;
}

void Consola::enviar(std::string mensaje){
	std::cout <<"Enviando Mensaje {\""<<mensaje<<"\"} a aplicacion de consola\n";
}

int Consola::tipos()
{
	return 1;
}

std::string Consola::toString(){
	return "Aplicacion de consola -- "+Nombre;
}
