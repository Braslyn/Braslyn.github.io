#include "Correo.h"

Correo::Correo(std::string nombre, Mesaje& next):Internet(next),nombre(nombre){}

Correo::~Correo(){}

void Correo::enviar(std::string Nombre){
	std::cout << "Enviando Mensaje: {\"" << Nombre << "\"} a correo\n";
	this->next->enviar(Nombre);
}

int Correo::tipos(){
	return 0;
}

std::string Correo::toString(){
	std::stringstream out;
	out << "Correo " << nombre << "\n-------------------------------\n"<<next->toString();
	return out.str();
}
