#ifndef LOCAL_H
#define LOCAL_H
#include "Mensaje.h"
class Local :public Mesaje{// clase concreta
public:
	//Local(std::string mensaje);
	//~Local();
	virtual void enviar(std::string Nombre) = 0;
	virtual int tipos() = 0;
	virtual std::string toString() = 0;
private:
	//std::string mensaje;
};



#endif // !LOCAL_H
