#ifndef MENSAJE_H
#define MENSAJE_H
#include <string>
#include <iostream>
class Mesaje{
public:
	virtual void enviar(std::string mensaje)=0;
	virtual int tipos()=0;
	virtual std::string toString()=0;
	//friend -- no me gusta el toString
	friend std::ostream& operator<<(std::ostream& out, Mesaje* obj);
};

#endif // !MENSAJE_H
