#ifndef CONSOLA_H
#define CONSOLA_H
#include "Local.h"

class Consola : public Local{
public:
	Consola(std::string Nombre);
	~Consola();
	std::string getNombre();
	int tipos();
	void enviar(std::string Nombre);
	std::string toString();
private:
	std::string Nombre;
};

#endif // !CONSOLA_H
