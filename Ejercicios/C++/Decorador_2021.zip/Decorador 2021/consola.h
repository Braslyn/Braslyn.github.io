#ifndef CONSOLA_H
#define CONSOLA_H
#include "Local.h"

class Consola : public Local{
public:
	Consola(std::string Nombre);
	~Consola();
	std::string getNombre();
	void enviar(std::string Nombre);
	int tipos();
	std::string toString();
private:
	std::string Nombre;
};

#endif // !CONSOLA_H
