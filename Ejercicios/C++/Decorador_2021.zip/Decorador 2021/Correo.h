#ifndef CORREO_H
#define CORREO_H
#include "Internet.h"
class Correo: public Internet{
public:
	Correo(std::string nombre,Mesaje& next);
	~Correo();
	void enviar(std::string Nombre);
	std::string toString();
private:
	std::string nombre;
};

#endif // !CORREO_H
