#include "Facebook.h"

Facebook::Facebook(Mesaje& next):Internet(next){}

Facebook::~Facebook(){}

void Facebook::enviar(std::string Nombre){
	std::cout << "Enviando Mensaje: {\"" << Nombre << "\"} a Facebook\n";
	this->next->enviar(Nombre);
}

int Facebook::tipos()
{
	return 0;
}

std::string Facebook::toString()
{
	std::stringstream out;
	out << "Facebook\n-------------------------------\n" << next->toString();
	return out.str();
}
