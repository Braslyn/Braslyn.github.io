#include "Facebook.h"

Facebook::Facebook(Mesaje& next):Internet(next){}

Facebook::~Facebook() { }

void Facebook::enviar(std::string Nombre){
	std::cout << "Enviando Mensaje: {\"" << Nombre << "\"} a Facebook\n";
	this->next->enviar(Nombre);
}

std::string Facebook::toString()
{
	std::stringstream out;
	out << "Facebook\n-------------------------------\n" << next->toString();
	return out.str();
}
