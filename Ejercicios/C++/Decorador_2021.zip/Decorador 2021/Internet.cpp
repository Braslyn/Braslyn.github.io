#include "Internet.h"

Internet::Internet(Mesaje& next):next(&next){}

Internet::~Internet(){
	delete next;
	next = nullptr;
}

Mesaje* Internet::getNext()
{
	return next;
}

void Internet::setNext(Mesaje& next){
	this->next = &next;
}

int Internet::tipos(){
	return 1+this->next->tipos();
}
