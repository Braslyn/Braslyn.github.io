#include "Internet.h"

Internet::Internet(Mesaje& next):next(&next){}

Internet::~Internet(){}

Mesaje* Internet::getNext()
{
	return next;
}

void Internet::setNext(Mesaje& next){
	this->next = &next;
}
