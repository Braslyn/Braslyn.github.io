#ifndef FACEBOOK_H
#define FACEBOOK_H
#include "Internet.h"
class Facebook: public Internet{
public:
	Facebook(Mesaje& next);
	~Facebook();
	void enviar(std::string Nombre);
	std::string toString();
};

#endif // !FACEBOOK
