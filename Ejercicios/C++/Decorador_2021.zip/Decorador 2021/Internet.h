#ifndef INTERNET_H
#define INTERNET_H
#include "Mensaje.h"
#include <sstream>
class Internet:public Mesaje{
public:
	Internet(Mesaje& next);
	~Internet();
	Mesaje* getNext();
	void setNext(Mesaje& next);
	virtual void enviar(std::string Nombre) = 0;
	virtual int tipos();
	virtual std::string toString() = 0;
protected:
	Mesaje* next;
};



#endif // !INTERNET_H
