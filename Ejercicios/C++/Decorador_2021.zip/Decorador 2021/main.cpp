#include "consola.h"
#include "Correo.h"
#include "Facebook.h"

int main() {
	Mesaje* var = new Consola("RGBA");
	var = new Correo("Gmail",*var);
	var = new Facebook(*var);
	var->enviar("cambio de normas");
	std::cout<<"-------------------------------\n"<<var<<"\n";
	std::cout << "-------------------------------\n";
	std::cout <<"Cantidad de mensajes por clase: "<<var->tipos();

	return 0;
}