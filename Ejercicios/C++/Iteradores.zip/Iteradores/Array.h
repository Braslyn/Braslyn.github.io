#ifndef ARRAY_H
#define ARRAY_H
#include "List.h"

template<class T>
class Array:public List<T>{
public:
	Array();
	~Array();
	typedef Iterator<T>* iterador;
	void operator<<(T);
	T* operator[](int);
	unsigned int Count() const;
	Iterator<T>* CreateIterator();
private:
	void aumentar();
	T* array;
	int cant;
};

template <class T>
class IteradorArray :public Iterator<T> {
public:
	IteradorArray(Array<T>& arr);
	~IteradorArray();
	void First();
	void Next();
	bool IsDone() const;
	T CurrentItem() const;
private:
	T* first;
	T* current;
	T* Final;
};
#endif // !ARRAY



template<class T>
inline Array<T>::Array():array(new T[10]), cant(0){}

template<class T>
inline Array<T>::~Array(){}

template<class T>
inline void Array<T>::operator<<(T obj){
	if (cant<sizeof(*array)/sizeof(T)){
		array[cant++] = obj;
	}else {
		aumentar();
		array[cant++] = obj;
	}
	return;
}

template<class T>
inline T* Array<T>::operator[](int index){
	return &array[index];
}

template<class T>
inline unsigned int Array<T>::Count()const
{
	return cant;
}

template<class T>
inline Iterator<T>* Array<T>::CreateIterator(){
	return new IteradorArray<T>(*this);
}

template<class T>
inline void Array<T>::aumentar(){
	T* nuevo= new T[cant+10];
	for (int i = 0; i < cant; i++){
		nuevo[i] = array[i];
	}
	delete[] array;
	array = nuevo;
}


template<class T>
inline IteradorArray<T>::IteradorArray(Array<T>& arr) {
	first = arr[0];
	current = first;
	Final = arr[arr.Count()];
}

template<class T>
inline IteradorArray<T>::~IteradorArray() {
	first = nullptr;
	current = nullptr;
	Final = nullptr;
}

template<class T>
inline void IteradorArray<T>::First() {
	current = first;
}

template<class T>
inline void IteradorArray<T>::Next() {
	current++;
}

template<class T>
inline bool IteradorArray<T>::IsDone() const {
	return current == Final;
}

template<class T>
inline T IteradorArray<T>::CurrentItem() const {
	return *current;
}
