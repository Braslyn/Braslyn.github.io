#include "Array.h"
#include "ListaPunteros.h"
#include <vector>
#include <iostream>
using std::cout;
int main() {
	cout << "Iterador con Lista -> \n";
	Lista<int> list;
	list << 1;
	list << 2;
	list << 3;
	Lista<int>::iterador x = list.CreateIterator();
	while (!x->IsDone()){
		cout << x->CurrentItem()<<"\n";
		x->Next();
	}
	cout << "Iterador con Array [] -> \n";
	Array<int> arr;
	arr << 1;
	arr << 2;
	arr << 3;
	Array<int>::iterador y = arr.CreateIterator();
	while (!y->IsDone()) {
		cout << y->CurrentItem() << "\n";
		y->Next();
	}
	return 0;
}