#include "Persona.h"

Persona::Persona(string nombre, int edad, string fecha):nombre(nombre),edad(edad),nacimiento(new Fecha(fecha)){}

Persona::~Persona(){
	if (!nacimiento)
		delete nacimiento;
}

string Persona::getNombre()
{
	return nombre;
}

Fecha* Persona::getFecha(){
	return nacimiento;
}

int Persona::getEdad()
{
	return edad;
}

std::ostream& operator<<(std::ostream& out, Persona& persona){
	out << persona.nombre << " con " << persona.edad << " nacio el " << *persona.nacimiento;
	return out;
}
