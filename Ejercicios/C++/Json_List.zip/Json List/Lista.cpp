#include "Lista.h"
template<class T>
Lista<T>::Lista() :primero(nullptr), cant(0) {}

template<class T>
Lista<T>::~Lista() { this->BorrarTodo(); }

template<class T>
Nodo<T>* Lista<T>::Crearnodo(T x)
{
	return new Nodo<T>(x);
}

template<class T>
void Lista<T>::operator+(T& x) {
	insertar(*this->Crearnodo(x));
}

template<class T>
void Lista<T>::operator+(T* x) {
	insertar(*this->Crearnodo(*x));
}

template<class T>
void Lista<T>::insertar(Nodo<T>& nodo) {
	if (this->IsEmpty()) {
		primero = &nodo;
		cant++;
		return;
	}
	Nodo<T>* aux = primero;
	while (aux->next != nullptr) {
		aux = aux->next;
	}
	aux->next = &nodo;
	cant++;
}

template<class T>
void Lista<T>::borrar(int num) {
	Nodo* aux = primero;
	if (aux->dato == num) {
		primero = aux->next;
		delete aux;//[delete]->[primero]
		cant--;
		return;
	}
	Nodo* anterior = aux;
	aux = aux->next;
	while (aux->next != nullptr) {
		if (aux->dato == num) {
			anterior->next = aux->next;//[]->[]
			delete aux;
			cant--;
			return;
		}
		anterior = aux;
		aux = aux->next;
	}
}

template<class T>
T* Lista<T>::get(int pos) {
	if (pos >= 0) {
		int index = 0;
		if (pos < cant) {
			Nodo<T>* aux = primero;
			while (index++ < pos) {
				aux = aux->next;
			}
			auto x = &aux->data;
			return &aux->data;
		}
	}
	return nullptr;
}

template<class T>
T* Lista<T>::operator[](int pos) {
	return get(pos);
}

template<class T>
void Lista<T>::BorrarTodo() {
	Nodo<T>* aux = primero;
	while (aux != nullptr) {//[p/a]-> null
		primero = aux->next;
		delete aux;
		aux = primero;
	}
	cant = 0;
	primero = nullptr;
}

template<class T>
int Lista<T>::getCant()
{
	return cant;
}

template<class T>
void Lista<T>::swap(int pos1, int pos2) {
	if (pos1 >= 0 && pos2 >= 0) {
		if (pos1 < cant && pos2 < cant) {
			Nodo<T>* aux1 = primero;
			Nodo<T>* aux2 = primero;
			int index = 0;
			if (pos1 > pos2) {
				while (index++ < pos1) {
					aux1 = aux1->next;
					if (index == pos2)
						aux2 = aux1;
				}
			}
			else {
				while (index++ < pos2) {
					aux1 = aux1->next;
					if (index == pos1)
						aux2 = aux1;
				}
			}
			T x = aux1->dato;
			aux1->dato = aux2->dato;
			aux2->dato = x;
		}
	}
}

template<class T>
bool Lista<T>::IsEmpty() {
	return primero == nullptr;
}

template<class U>
std::ostream& operator<<(std::ostream& out, Lista<U>& lista){
	Nodo<U>* aux = lista.primero;
	out << "[ ";
	while (aux != nullptr) {
		out << aux->data;
		if (aux->next != nullptr)
			out << ",\n";
		aux = aux->next;
	}
	out << " ]";
	return out;
}
