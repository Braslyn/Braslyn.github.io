#ifndef FECHA_H
#define FECHA_H
#include <string>
#include <sstream>
#include <regex>
using std::string;
class Fecha{
public:
	Fecha(std::string fecha);
	~Fecha();
	int getDia();
	int getMes();
	int getAnio();
	friend std::ostream& operator<<(std::ostream& out, Fecha& fecha);
private:
	int dia;
	int mes;
	int anio;
};
#endif // !FECHA
