#ifndef ORGANIZACION_H
#define ORGANIZACION_H
#include "Lista.h"
#include "Lista.cpp"
#include "Persona.h"
#include "json/json.h"
#include <fstream>
class Organizacion{
public:
	Organizacion();
	Organizacion(string doc);
	~Organizacion();
	void operator+(Persona& persona);
	void guardar(string nombre);
	friend std::ostream& operator<<(std::ostream& out, Organizacion& org);
private:
	Lista<Persona> Empleados;
};

#endif // !ORGANIZACION_H
