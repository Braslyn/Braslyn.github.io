#include "Organizacion.h"
#include <iostream>
#include <Windows.h>

int main(int arg,char** argv){
	Organizacion* org;
	Persona* persona;
	if (arg<2){
		org= new Organizacion();
	}else {
		org = new Organizacion(argv[1]);
	}
	std::cout << *org;
	system("pause");
	bool salir = false;
	char menu;
	string nombre,fecha;
	int numeros;
	while (!salir){
		system("cls");
		std::cout << "1)Ingresar Empleado\n2)Ver lista\n3)Guardar\n4)Salir\n";
		std::cin >> menu;
		switch (menu){
		case '1':
			system("cls");
			std::cout << "Digite el nombre\n";
			std::cin >> nombre;
			std::cout << "Digite la edad\n";
			std::cin >> numeros;
			std::cout << "Digite la fecha de nacimiento\n";
			std::cin >> fecha;
			persona=new Persona(nombre,numeros,fecha);
			*org + *persona;
			system("pause");
			break;
		case '2':
			system("cls");
			std::cout << *org;
			system("pause");
			break;
		case '3':
			system("cls");
			std::cout << "Digite el nombre del archivo\n";
			std::cin >> nombre;
			org->guardar(nombre);
			std::cout << "Guardado!";
			system("pause");
			break;
		case '4':
			system("cls");
			salir = true;
			break;
		default:
			std::cout << "Opcion invalida\n";
			system("pause");
			break;
		}

	}
	return 0;
}