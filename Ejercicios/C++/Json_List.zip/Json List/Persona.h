#ifndef PERSONA_H
#define PERSONA_H
#include "Fecha.h"
class Persona{
public:
	Persona(string nombre,int edad,string fecha);
	~Persona();
	string getNombre();
	Fecha* getFecha();
	int getEdad();
	friend std::ostream& operator<<(std::ostream& out, Persona& persona);
private:
	string nombre;
	int edad;
	Fecha* nacimiento;
};


#endif // !PERSONA_H
