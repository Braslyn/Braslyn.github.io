#include "Organizacion.h"

Organizacion::Organizacion(){}

Organizacion::Organizacion(string doc){
	Json::Value root;
	Json::String errs;
	std::ifstream archivo(doc+".json", std::ios::in);
	Json::CharReaderBuilder builder;
	builder["collectComments"] = true;
	if (!parseFromStream(builder, archivo, &root, &errs)) {
		throw errs;
	}
	string fecha;
	for (unsigned int i = 0; i < root.size(); i++){
		fecha = root[i]["Fecha"]["Dia"].asString() + "-" + root[i]["Fecha"]["Mes"].asString() + "-" + root[i]["Fecha"]["Anio"].asString();
		Empleados + *new Persona(root[i]["Nombre"].asString(), root[i]["Edad"].asInt(), fecha );
	}
}

Organizacion::~Organizacion()
{
}

void Organizacion::operator+(Persona& persona){
	Empleados + persona;
}

void Organizacion::guardar(string nombre){
	std::ofstream archivo(nombre + ".json", std::ios::out);
	Json::Value lista;
	Json::Value persona;
	Json::Value fecha;
	Json::StreamWriterBuilder builder;
	const std::unique_ptr<Json::StreamWriter> writer(builder.newStreamWriter());
	for(short int i=0;i<Empleados.getCant();i++){
		persona["Nombre"] = Empleados[i]->getNombre();
		persona["Edad"] = Empleados[i]->getEdad();
		fecha["Dia"] = Empleados[i]->getFecha()->getDia();
		fecha["Mes"]= Empleados[i]->getFecha()->getMes();
		fecha["Anio"]= Empleados[i]->getFecha()->getAnio();
		persona["Fecha"] = fecha;
		lista.append(persona);
	}
	writer->write(lista, &archivo);
}

std::ostream& operator<<(std::ostream& out, Organizacion& org)
{
	out << "Organizacion\nLista de Empleados:\n" << org.Empleados;
	return out;
}
