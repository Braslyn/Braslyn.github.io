#include "Fecha.h"

Fecha::Fecha(std::string fecha){
    std::regex RE("([123][\\d])[-|\\/]([01]?[\\d])[-|\\/]([\\d]+)");
    std::match_results< std::string::const_iterator > mr;
    std::regex_search(fecha, mr, RE);
    dia = std::stoi(mr[1]);
    mes = std::stoi(mr[2]);
    anio = std::stoi(mr[3]);
}

Fecha::~Fecha(){}

int Fecha::getDia()
{
    return dia;
}

int Fecha::getMes()
{
    return mes;
}

int Fecha::getAnio()
{
    return anio;
}

std::ostream& operator<<(std::ostream& out, Fecha& fecha)
{
    out << fecha.dia << "/" << fecha.mes << "/" << fecha.anio;
    return out;
}
