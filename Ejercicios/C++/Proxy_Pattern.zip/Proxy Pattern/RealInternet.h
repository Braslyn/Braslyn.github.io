#ifndef REALINTERNET_H
#define REALINTERNET_H
#include "Internet.h"
#include <iostream>
class RealInternet:public Internet{
public:
	RealInternet();
	~RealInternet();
	void ConnectTo(std::string Url);
};
#endif // !REALINTERNET_H
