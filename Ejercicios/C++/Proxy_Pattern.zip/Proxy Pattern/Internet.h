#ifndef INTERNET_H
#define INTERNET_H
#include <string>
class Internet{
public:
	virtual void ConnectTo(std::string Url) = 0;
};

#endif // !INTERNET_H
