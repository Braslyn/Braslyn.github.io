#ifndef PROXYINTERNET_H
#define PROXYINTERNET_H
#include "RealInternet.h"
#include <memory>
#include <vector>
class ProxyInternet:public Internet{
public:
	ProxyInternet();
	~ProxyInternet();
	void ConnectTo(std::string Url);
private:
	std::unique_ptr<RealInternet> internet;
	std::vector<std::string> sitiosBaneados;
};
#endif // !PROXYINTERNET_H
