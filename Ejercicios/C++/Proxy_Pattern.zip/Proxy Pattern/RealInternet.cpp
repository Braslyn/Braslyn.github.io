#include "RealInternet.h"

RealInternet::RealInternet(){}

RealInternet::~RealInternet(){}

void RealInternet::ConnectTo(std::string Url){
	std::cout << "Conectando a " << Url<<"\n";
}
