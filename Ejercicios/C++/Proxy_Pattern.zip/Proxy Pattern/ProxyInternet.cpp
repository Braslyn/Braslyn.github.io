#include "ProxyInternet.h"

ProxyInternet::ProxyInternet():internet(new RealInternet()){
	sitiosBaneados.push_back("xxx.com");
	sitiosBaneados.push_back("picanton.com");
}

ProxyInternet::~ProxyInternet(){}

void ProxyInternet::ConnectTo(std::string Url){
	if (std::find(sitiosBaneados.begin(),sitiosBaneados.end(),Url)==sitiosBaneados.end()){
		internet->ConnectTo(Url);
	}else{
		throw std::exception("Sitio Baneado!!");
	}
}
