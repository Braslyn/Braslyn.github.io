#include "ProxyInternet.h"

int main(int arg,char** args) {
	if (arg>1){
		ProxyInternet internet;
		try {
			internet.ConnectTo(args[1]);
			internet.ConnectTo("picanton.com");
		}
		catch (const std::exception& e) {
			std::cout << e.what() << "\n";
		}
	}
	else {
		std::cout << "Introduce un Url como parametro!";
	}

	return 0;
}