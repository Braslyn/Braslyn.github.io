class Nodo:
    def __init__(self,valor,ptr=None):
        self.valor=valor
        self.ptr=ptr
class Lista:


    def __init__(self):
        self.cant=0
        self.root=None
    def append(self,valor):
        nuevo= Nodo(valor)
        if self.root==None:
            self.root=nuevo
        else:
            aux=self.root
            while(aux.ptr!=None):
                aux=aux.ptr
            aux.ptr=nuevo
    def __iter__(self):
        aux=self.root
        while(aux!=None):
            yield aux.valor
            aux=aux.ptr
            
if __name__=="__main__":
    lista=Lista()
    lista.append(1)
    lista.append(2)
    lista.append(3)
    for x in lista:
        print(x)