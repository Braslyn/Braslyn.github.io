def Menor(a,b):
    return a<b

def DuplicarTexto(texto):
    return texto*2

def sumaHastaN(n):
    suma=0
    for x in range(0,n):
        suma+=x
    return suma