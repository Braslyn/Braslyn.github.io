#include "Aves.h"

Aves::Aves(string col, string nom, int edad, string plumas):plumas(plumas),Animales(col,nom,edad){}

Aves::~Aves(){}

string Aves::getPlumas()
{
	return plumas;
}

void Aves::andar(){
	std::cout << "Vuelo para moverme\n";
}

void Aves::respira(){
	std::cout << "Utilizo mis pulomenos para sobrevivir\n";
}
