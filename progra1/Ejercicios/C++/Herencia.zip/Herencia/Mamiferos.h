#ifndef MAMIFEROS_H
#define MAMIFEROS_H
#include "Animales.h"
class Mamiferos: public Animales{
public:
	Mamiferos(string col="Blanco",string nom="mamifero",int edad=2,string pelo="Mucho");
	~Mamiferos();
	string getPelo();
	virtual void andar();
	virtual string toString();
protected:
	string pelo;
};

#endif // !MAMIFEROS_H

