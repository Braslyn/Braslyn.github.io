#include "Humano.h"
#include "Aves.h"
int main() {
	Animales* vec[3];
	vec[0] = new Aves();
	vec[1] = new Humano();//[1]-> humano <-x vec
	vec[2] = new Mamiferos();
	//std::cout<<vec[0]->toString()<<"\n";
	//std::cout<<vec[1]->toString();
	Humano* hum;
	Aves* ave;
	int x= atoi("12");
	std::cout << x;
	for (short int i = 0; i < 3; i++){
		if (hum = dynamic_cast<Humano*>(vec[i])) {
			std::cout<<"Mi IQ es "<<hum->getIQ()<<"\n";
		}else if(ave = dynamic_cast<Aves*>(vec[i])){
			
			std::cout << "Tengo "<< ave->getPlumas()<<" plumas\n";
		}
		else {
			std::cout << vec[i]->toString();
		}
	}

}