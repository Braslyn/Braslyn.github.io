#include "Animales.h"

Animales::Animales(string col, string nom, int edad):color(col),nombre(nom),edad(edad){}

Animales::~Animales(){}

void Animales::Comer(){
	std::cout << "Comiendo..\n";
}

void Animales::andar(){
	std::cout << "Desplazandose\n";
}

void Animales::respira(){
	std::cout << "Utilizando el sistema respiratorio\n";
}

string Animales::getColor()
{
	return color;
}

string Animales::getNombre()
{
	return nombre;
}

int Animales::getEdad()
{
	return edad;
}

string Animales::toString(){
	std::stringstream out;
	out << "Animal de color " << color << ", con nombre " << nombre << ", con edad: " << edad;
	return out.str();
}
