#include "Humano.h"

int Humano::getIQ(){
    return IQ;
}

void Humano::andar(){
    std::cout << "Me muevo con mis piernas";
}

string Humano::toString() {
    std::stringstream out;
    out<< Mamiferos::toString() <<", con un IQ de " << IQ;
    return out.str();
}

Humano::Humano(string col, string nom, int edad, string pelo, int IQ):IQ(IQ),Mamiferos(col,nom,edad,pelo){}

Humano::~Humano(){}
