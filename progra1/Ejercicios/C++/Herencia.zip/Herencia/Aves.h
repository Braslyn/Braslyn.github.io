#ifndef AVES_H
#define AVES_H
#include "Animales.h"

class Aves: public Animales{
public:
	Aves(string col="Verder",string nom="ave",int edad=10, string plumas="Muchas");
	~Aves();
	string getPlumas();
	void andar();
	void respira();
protected:
	string plumas;
};

#endif // !AVES_H
