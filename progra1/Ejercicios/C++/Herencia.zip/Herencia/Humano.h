#ifndef HUMANO_H
#define HUMANO_H
#include "Mamiferos.h"
class Humano: public Mamiferos{
public:
	Humano(string col="piel", string nom="humano",int edad=30,string pelo="Poco",int IQ=300);
	~Humano();
	int getIQ();
	void andar();
	string toString();
private:
	int IQ;
};

#endif // !HUMANO_H

