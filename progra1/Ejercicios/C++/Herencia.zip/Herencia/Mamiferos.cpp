#include "Mamiferos.h"

Mamiferos::Mamiferos(string col, string nom, int edad, string pelo):pelo(pelo),Animales(col,nom,edad){}

Mamiferos::~Mamiferos(){}

string Mamiferos::getPelo(){
    return pelo;
}

void Mamiferos::andar(){
    std::cout << "Ultilizo extemidades para moverme\n";
}

string Mamiferos::toString(){
    std::stringstream out;
    out << Animales::toString()<<" , con "<<pelo<<" pelo";
    return out.str();
}
