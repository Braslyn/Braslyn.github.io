#ifndef ANIMALES_H
#define ANIMALES_H
#include <string>
#include <sstream>
#include <iostream>
using std::string;

class Animales{
public:
	Animales(string col="amarillo",string nom="nombre",int edad=5);
	~Animales();
	void Comer();
	virtual void andar();//este metodo puede sobreescrito x -> y
	virtual void respira();//metodo virtual puro
	string getColor();
	string getNombre();
	int getEdad();
	virtual string toString();
protected:
	string color;
	string nombre;
	int edad;
};


#endif // 
