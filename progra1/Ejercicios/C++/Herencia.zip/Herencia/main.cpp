#include "Animales.h"

int Main() {
	Animales anl;
	std::cout <<"Color: " <<anl.getColor() <<"nombre: "<< anl.getNombre()<<"edad: "<<anl.getNombre();
	anl.andar();
	anl.Comer();
	anl.respira();
	return 0;
}