#ifndef COLECCION_H
#define COLECCION_H
#include <vector>
#include "Vehiculo.h"
#include <fstream>
#include <algorithm>

class Coleccion
{
public:
	Coleccion();
	~Coleccion();
	void add(Vehiculo* veh);
	void add(Propietario* prop);
	void Guardar();
	void Cargar();
	void informe();
private:
	Propietario* buscar(string id);
	int cantidadVehiculos(string id);
	std::vector<Vehiculo> listaVehiculos;
	std::vector<Propietario> listaPropietarios;
};



#endif // !COLECCION_H
