#pragma once
#include "Propietario.h"
using namespace std;
class Vehiculo
{
private:
	string placa;
	int annio;
	string marca;
	string modelo;
	Propietario* propietario;
public:
	Vehiculo(string = "", int = 0, string = "", string = "" , Propietario* prop=nullptr);
	virtual ~Vehiculo();

	string getPlaca();
	int getAnnio();
	string getMarca();
	string getModelo();
	Propietario& getPropietario();
	void setPlaca(string);
	void setAnnio(int);
	void setMarca(string);
	void setModelo(string);

	string toString(bool=true);

};

