#include "Coleccion.h"

int main() {
	Coleccion lista;
	//Propietario* prop=new Propietario("Paco","42","000");
	//Vehiculo* veh=new Vehiculo("123",2000,"pocho","500",prop);
	//lista.add(prop);
	//lista.add(veh);
	lista.Cargar();
	lista.informe();
	//lista.Guardar();
	return 0;
}