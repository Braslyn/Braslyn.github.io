#include "Propietario.h"

Propietario::Propietario(string nombre, string id, string telefono)
{
	Propietario::nombre = nombre;
	Propietario::id = id;
	Propietario::telefono = telefono;
}

Propietario::~Propietario()
{
}

string Propietario::getNombre()
{
	return nombre;
}

string Propietario::getId()
{
	return id;
}

string Propietario::getTelefono()
{
	return telefono;
}

void Propietario::setNombre(string nombre)
{
	Propietario::nombre = nombre;
}

void Propietario::setId(string id)
{
	Propietario::id = id;
}

void Propietario::setTelefono(string telefono)
{
	Propietario::telefono = telefono;
}

string Propietario::toString(bool bandera)
{
	
	stringstream s;

	if (bandera) {
		s << "----------PROPIETARIO-----------" << endl;
		s << "Nombre........" << nombre << endl;
		s << "Identificacion........" << id << endl;
		s << "Telefono........" << telefono << endl;
	}
	else {
		s << nombre << '\t';
		s << id << '\t';
		s << telefono << '\t';
		

	}




	return s.str();
}
