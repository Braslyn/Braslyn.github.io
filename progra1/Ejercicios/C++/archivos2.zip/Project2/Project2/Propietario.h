#pragma once
#include <iostream>
#include <sstream>
#include <string>

using namespace std;
class Propietario
{
private:
	string nombre;
	string id;
	string telefono;
public:
	Propietario(string = "", string = "", string = "");
	virtual ~Propietario();

	string getNombre();
	string getId();
	string getTelefono();

	void setNombre(string);
	void setId(string);
	void setTelefono(string);

	string toString(bool=true);
};

