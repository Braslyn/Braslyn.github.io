#include "Vehiculo.h"

Vehiculo::Vehiculo(string placa, int annio, string marca, string modelo,Propietario* prop)
{
	Vehiculo::propietario = prop;
	Vehiculo::placa = placa;
	Vehiculo::annio = annio;
	Vehiculo::marca = marca;
	Vehiculo::modelo = modelo;
}

Vehiculo::~Vehiculo()
{
	//if (!propietario)
		//delete propietario;
}

string Vehiculo::getPlaca()
{
	return placa;
}

int Vehiculo::getAnnio()
{
	return annio;
}

string Vehiculo::getMarca()
{
	return marca;
}

string Vehiculo::getModelo()
{
	return modelo;
}

Propietario& Vehiculo::getPropietario()
{
	return *propietario;
}

void Vehiculo::setPlaca(string placa)
{
	Vehiculo::placa = placa;
}

void Vehiculo::setAnnio(int annio)
{
	Vehiculo::annio = annio;
}

void Vehiculo::setMarca(string marca)
{
	Vehiculo::marca = marca;
}

void Vehiculo::setModelo(string modelo)
{
	Vehiculo::modelo = modelo;
}

string Vehiculo::toString(bool bandera)
{
	stringstream s;


	if (bandera) {
		s << "----------VEHICULO-----------" << endl;
		s << "Placa........" << placa << endl;
		s << "Annio........" << annio << endl;
		s << "Marca........" << marca << endl;
		s << "Modelo........" << modelo << endl;
	}
	else {
		s << placa << '\t';
		s << annio << '\t';
		s << marca << '\t';
		s << modelo << '\t';


	}


	return s.str();
}
