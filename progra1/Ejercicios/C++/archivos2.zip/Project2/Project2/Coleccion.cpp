#include "Coleccion.h"

Coleccion::Coleccion()
{
}

Coleccion::~Coleccion()
{
}

void Coleccion::add(Vehiculo* veh)
{
	listaVehiculos.push_back(*veh);
}

void Coleccion::add(Propietario* prop)
{
	listaPropietarios.push_back(*prop);
}

void Coleccion::Guardar()
{
	// propietarios.txt
	std::ofstream archivo("propietarios.csv",std::ios::out);
	archivo << listaPropietarios.size()<<"\n";
	for (auto prop: listaPropietarios){
		archivo<<prop.getId()<<";";
		archivo << prop.getNombre() << ";";
		archivo << prop.getTelefono() << "\n";
	}
	archivo.close();
	//vehiculos.txt
	std::ofstream archivo1("vehiculo.csv", std::ios::out);
	archivo1 << listaVehiculos.size() << "\n";
	for (auto veh : listaVehiculos) {
		archivo1 << veh.getPlaca() << ";";
		archivo1 << veh.getModelo() << ";";
		archivo1 << veh.getMarca() << ";";
		archivo1 << veh.getAnnio() << ";";
		archivo1 << veh.getPropietario().getId() << "\n";
	}
	archivo1.close();

}

void Coleccion::Cargar(){
	string valores[5];
	std::ifstream archivo("propietarios.csv",std::ios::in);
	int tam = 0;
	getline(archivo, valores[0], '\n');
	tam = stoi(valores[0]);
	for (int i = 0; i < tam; i++){
		getline(archivo, valores[0], ';');
		getline(archivo, valores[1], ';');
		getline(archivo, valores[2], '\n');
		listaPropietarios.push_back(*new Propietario(valores[1], valores[0], valores[2]));
	}
	archivo.close();
	archivo.open("vehiculo.csv", std::ios::in);
	getline(archivo, valores[0], '\n');
	tam = stoi(valores[0]);
	for (int i = 0; i < tam; i++) {
		getline(archivo, valores[0], ';');
		getline(archivo, valores[1], ';');
		getline(archivo, valores[2], ';');
		getline(archivo, valores[3], ';');
		getline(archivo, valores[4], '\n');
		listaVehiculos.push_back(*new Vehiculo(valores[0], std::stoi(valores[3]),valores[2],valores[1],buscar(valores[4])));
	}
}

void Coleccion::informe(){

	std::ofstream archivo1("informe.txt", std::ios::out);
		for (auto i:listaPropietarios ){
			archivo1 << i.getId() << " carros: " << cantidadVehiculos(i.getId())<<"\n";
		}
	archivo1.close();
}



Propietario* Coleccion::buscar(string id)
{
	for (auto& prop:listaPropietarios){
		if (prop.getId()==id)
		{
			return &prop;
		}
	}
	return nullptr;
}

int Coleccion::cantidadVehiculos(string id){
	int sum = 0;
	for (auto veh : listaVehiculos) {
		if (veh.getPropietario().getId()==id){
			sum++;
		}
	}
	return sum;
}
