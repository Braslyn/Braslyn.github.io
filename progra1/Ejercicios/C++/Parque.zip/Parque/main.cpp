#include "Banca.h"
#include <iostream>

int main() {
	Banca* vector[10];
	Banca* banca = new Banca(0, "Mueblecito","Norte",3000);

	vector[0] = banca;
	for (short i = 1; i < 10; i++){
		vector[i] = new Banca(*vector[i - 1],"este");
	}
	banca->setImpuesto(6);
	std::cout << "Las bancas de mi parque son:\n";
	for (short int i = 0; i < 10; i++){
		std::cout << vector[i]->toString();
	}
	Banca::setImpuesto(1.13);
	std::cout << "Las bancas de mi parque son:\n";
	for (short int i = 0; i < 10; i++) {
		std::cout << vector[i]->toString();
	}
	return 0;
}