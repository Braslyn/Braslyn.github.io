#include "Banca.h"

void Banca::setImpuesto(float imp){
	impuesto = imp;
}

Banca::Banca(int numero, std::string Marca,std::string posicion,double precio):numero(numero),Marca(Marca),posicion(posicion),precio(precio){
	for (short int i = 0; i < 3; i++){
		espacios[i] = nullptr;
	}
}

Banca::Banca(Banca& banca, std::string posicion):numero(banca.numero+1),Marca(banca.Marca),posicion(posicion),precio(banca.precio){
	for (short int i = 0; i < 3; i++) {
		espacios[i] = nullptr;
	}
}

double Banca::getPrecio(){
	return precio*impuesto;
}

Banca::~Banca()
{
}

std::string Banca::toString(){
	std::stringstream out;
	out << "[" << numero << " " << Marca <<" precio:"<<this->getPrecio()<<" ]\n";
	return out.str();
}
