#ifndef BANCA_H
#define BANCA_H
#include <string>
#include <sstream>
struct Persona {
	std::string nombre;
	Persona(std::string nombre):nombre(nombre) {}
};

static float impuesto=13;// Singleton

class Banca{
public:
	static void setImpuesto(float imp);
	Banca(int numero,std::string Marca,std::string posicion,double precio);
	Banca(Banca& banca,std::string posicion);
	double getPrecio();
	~Banca();
	std::string toString();
private:
	int numero;
	double precio;
	std::string posicion;
	std::string Marca;
	Persona* espacios[3];
};
#endif // !BANCA_H
