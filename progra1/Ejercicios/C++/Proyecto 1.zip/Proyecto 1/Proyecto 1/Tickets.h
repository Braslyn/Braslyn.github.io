#ifndef TICKET_H
#define TICKET_H
#include <string>

class Ticket{
public:
	Ticket(std::string,int,bool,int,int,std::string);
	~Ticket();
	void setValor(int);
	short int getFila();
	short int getColumna();
	int getValor();
	std::string getLugar();
	int getprecio();
	bool getVip();
	void setVip(bool);
	void setFila(int);
	void setColumna(int);
	void setFechaCompra(std::string);
	std::string getFechaCompra();
private:
	std::string lugar;
	int fila;
	int columna;
	int valor;
	bool vip;
	std::string fechacompra;
};

#endif //

