#include "Tickets.h"


Ticket::Ticket(std::string Lug,int Valor,bool Vip,int F,int C,std::string FC)//recibe lugar , valor, estado vip , fila , columna , fecha de 
{
	lugar = Lug; //inica los valores segun el Gym
	valor = Valor;
	vip = Vip;
	fila = F;
	columna = C;
	fechacompra = FC;
}

Ticket::~Ticket()
{

}

void Ticket::setFechaCompra(std::string F) {
	fechacompra = F;
}
std::string Ticket::getFechaCompra() {
	return fechacompra;
}

void Ticket::setValor(int Val) {//resive un valor de la entrada y lo a�ade
	valor = Val;
}

short int Ticket::getFila() {//devuleve las filas
	return fila;
}

void Ticket::setFila(int F) {//a�ade un numero de filas recibe un numero
	fila = F;
}

void Ticket::setColumna(int C) {//a�ade las columnas resive un numero
	columna = C;
}

short int Ticket::getColumna() {//devuellve las columnas
	return columna;
}

 int Ticket::getValor() {//devuelve el valor plano
	return valor;
}

 std::string Ticket::getLugar() {//devulve el lugar
	 return lugar;
 }

 int Ticket::getprecio() {
	 return (vip == true) ? static_cast<unsigned int>((valor*1.13) * 1.5) : static_cast<unsigned int>(valor*1.13);//retorna precion vip e con iva
 }

 bool Ticket::getVip() { //retorna estado vip o standard
	 return vip;
 }

 void Ticket::setVip(bool E) {
	 vip = E;
 }