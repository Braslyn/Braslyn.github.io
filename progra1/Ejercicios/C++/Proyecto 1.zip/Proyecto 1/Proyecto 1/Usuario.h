#ifndef USUARIO_H
#define USUARIO_H
#include "Tickets.h"
#include <iostream>
#include <string>
using std::cout;
using std::endl;
using std::string;


class Usuario {
public:
	Usuario();
	Usuario(std::string, int);
	~Usuario();
	bool setTickets(int);
	std::string getNombre();
	int getID();
	short int getTicketAtc();
	void setPTicket(Ticket *);
	std::string getTLugar(int);
	short int getTFila(int);
	short int getTColumna(int);
	int getTPrecio(int);
	bool getTVip(short int);
	void SetFilCol(int,int,int);
	friend std::ostream& operator<<(std::ostream&,const Usuario*);
	Ticket* getTicket(int,int,std::string);
	void EliminarTikets(std::string);
	bool EliminacionTicket(int, int, std::string);
	short int getNTicket(int F, int C, std::string L);
	void setTVip(bool, short int);

private:
	string nombre;
	int id;
	Ticket **ptrT;
	int ticketAtc;//Ticketsa ctuales
};

#endif