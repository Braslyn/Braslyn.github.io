#include "Gym.h"


Gym::Gym(){
	lugar = "Arisona";
	capacidad = CAPACIDAD;
	filas = FILAS;
	columnas = capacidad / filas;
	dia = 11;
	mes = 2;
	anio=2019;
	valor = COSTO;
	//iniciar puntero
	ptrS = new Usuario**[filas];//crea el numero de Filas
	for (int i = 0; i < filas; i++)
	{
		ptrS[i] = new Usuario*[columnas];//crea las columnas
	}
	for (int i = 0; i < filas; i++)
		for (int j = 0; j < columnas; j++)
			ptrS[i][j] = nullptr;//inicia los lugares en nulo

}
Gym::Gym(int Cap, int Fil, std::string Lug,std::string Des, short int Dia, short int Mes,short int Anio,int Val) {
	lugar = Lug;
	descripcion = Des;
	capacidad = Cap;
	camposRestantes = Cap;
	filas = Fil;
	if (Cap%Fil==0)
	{
		columnas = Cap / Fil;
	}
	else {
		columnas = (Cap / Fil)+1;
	}
	dia = Dia;
	mes = Mes;
	anio = Anio;
	valor = Val;
	//iniciar puntero
	ptrS = new Usuario**[filas];//crea las filas del usuario;
	for (int i = 0; i < filas; i++)
	{
		ptrS[i] = new Usuario*[columnas];//crea las columnas del usuario
	}

	for (int i = 0; i < filas; i++)
		for (int j = 0; j < columnas; j++)
			ptrS[i][j] = nullptr;//inicia las diecciones de usuario en nulo
}

Gym::Gym(Gym& gym,string nombre):lugar(gym.lugar){

}

Gym::~Gym(){//destructor
	for (int i = 0; i < filas; i++)
	{
		for (int j=0; j < columnas;j++) {

			if (ptrS[i][j] != nullptr) {
					ptrS[i][j]->EliminarTikets(lugar);
					if (ptrS[i][j]->getTicketAtc() == 0) {
						delete ptrS[i][j];
						ptrS[i][j] = nullptr;
					}
			}
		}
	}


	for (int i = 0;i < filas; i++)
	{
		delete[] ptrS[i];//destruye la matriz de sillas;
	}
	delete[] ptrS;//destruye las filas
	ptrS = nullptr;

}

void Gym::setLugar(std::string Lug) {
	lugar = Lug;
}
void Gym::setDescripcion(std::string Des) {
	descripcion = Des;
}
void Gym::setDia(short int D) {
	dia = D;
}
void Gym::setMes(short int M) {
	mes = M;
}
void Gym::setAno(short int A) {
	anio = A;
}

int Gym::getFilas() {//obtiene Filas
	return filas;
}

int Gym::getColumnas() {//obtiene columnas
	return columnas;
}

void Gym::setValor(int Val) {
	valor = Val;
}

int Gym::getCR() {//retorna los espacios disponibles
	return camposRestantes;
}

int Gym::getValor() {
	return valor;
}

Usuario *Gym::getSilla(int i, int j) {//obtiene direccion de la silla
	return ptrS[i][j];// A - 1 
}// char '64' A

std::string Gym::getNombre(int i, int j) {//obtiene nombre de el usuario en la matriz
	return ptrS[i][j]->getNombre();
}

int Gym::getID(int i, int j) {//obtiene silla
	return ptrS[i][j]->getID();
}

short int Gym::getTicketAtc(int i, int j) {//obtiene el actual numero de tickets
	return ptrS[i][j]->getTicketAtc();
}

bool Gym::ExistUser(std::string Nom) {//comprueba si el usurio existe en el registro
	for (int i = 0; i < filas; i++)
		for (int j = 0; j < columnas; i++)
			if (ptrS[i][j]->getNombre() == Nom)
				return true;

	return false;
}

bool Gym::XYUser(int &i , int &j ,std::string Nom) {//Devuelve por referencia cordenadas del usurio.
	for (i = 0; i < filas; i++)
		for (j = 0; j < columnas; i++)
			if (ptrS[i][j]->getNombre() == Nom)
				return true;

	return false;
}

void Gym::setSilla(int i, int j,Usuario *US) {//ubica al nuevo usuario en un lugar de la matriz
	ptrS[i][j] = US;
	if (US != nullptr) {
		camposRestantes -= 1;
	}
	else {
		camposRestantes += 1;
	}
	
}

void Gym::setPTicket(int i,int j ,Ticket *Tic) {//asigna un ticket al usuario
	ptrS[i][j]->setPTicket(Tic);
} 

std::string Gym::getDescripcion() {//devuleve la descripcion de gym
	return descripcion;
}

std::string Gym::getLugar() {//devuelve el lugar del gym
	return lugar;
}
//Ntic = numero de ticket

std::string Gym::GetTLugar(int i, int j,int Ntic) {//resive filas y columnas mas numero de ticket, devuelve el lugar string del tiecket
	return ptrS[i][j]->getTLugar(Ntic);
}

short int Gym::GetTFila(int i, int j, int Ntic) {//resive filas y columnas mas numero de ticket, devuelve la fila del ticket
	return ptrS[i][j]->getTFila(Ntic);
}

short int Gym::GetTColumna(int i, int j, int Ntic) {//resive filas y columnas mas numero de ticket, devuelve la columna del ticket
	return ptrS[i][j]->getTColumna(Ntic);

}

short int Gym::GetTPrecio(int i, int j, int Ntic) {//resive filas y columnas mas numero de ticket, devuelve del ticket
	return ptrS[i][j]->getTPrecio(Ntic);

}


std::ostream& operator<<(std::ostream&out, const Gym *G) {//sobreacarga para mostrar  info de los gyms
	out << "Lugar: " << G->lugar << endl;
	out << "Descripcion: " << G->descripcion << endl;
	out << "Capacidad: " << G->capacidad << endl;
	out << "Costo standar: " << static_cast<unsigned int>(G->valor*1.13) << endl;
	out << "Costo vip: " << static_cast<unsigned int>((G->valor*1.13)*1.5) << endl;
	out << "Campos Restantes: " << G->camposRestantes << endl;
	out << "Fecha: " << G->dia << "/" << G->mes << "/" << G->anio << endl;
	return out;
}



std::string Gym::ImprimiFila(int Fil) {//recibe una fila y devulve un dibujo coloreado de cual esta disponible o denegado (verde/rojo)
	std::stringstream s;
	int col = getColumnas();
	for (int i = 0; i < col; i++){
		if (getSilla(Fil, i) ==nullptr){

			s << "\x1b[32m"<<char(201)<<"-"<<char(187)<<" \x1b[0m";
		}
		else {
			s << "\x1b[31m" << char(201) << "-" << char(187) << " \x1b[0m";
		}
	}
	return s.str();
}

//apartado Visual
void Gym::Animacion(int x, int y) {// animacion de concierto
	Gotoxy(x, y);
	short int N = 1;//numero de animacion;
	for (int i = 0; i < 23; i++) {
		switch (N)
		{
		case 1:

			printf("0");
			Gotoxy(x, y + 1);
			printf("|");
			Gotoxy(x - 2, y + 1);
			printf("_/");
			Gotoxy(x + 1, y);
			printf("/");
			Gotoxy(x - 2, y + 2);
			printf("_/");
			Gotoxy(x + 1, y + 2);
			printf("|_");
			Sleep(250);
			N = 6;
			break;
		case 2:
			printf("0");
			Gotoxy(x, y + 1);
			printf("|");
			Gotoxy(x - 2, y + 1);
			printf("--");
			Gotoxy(x + 1, y + 1);
			printf(">");
			Gotoxy(x - 1, y + 2);
			printf("|");
			Gotoxy(x + 1, y + 2);
			printf("|");
			Sleep(250);
			N = 8;
			break;
		case 3:
			printf("0");
			Gotoxy(x, y + 1);
			printf("|");
			Gotoxy(x - 1, y + 1);
			printf("<");
			Gotoxy(x + 1, y + 1);
			printf("--");
			Gotoxy(x - 1, y + 2);
			printf("|");
			Gotoxy(x + 1, y + 2);
			printf("|");
			Sleep(250);
			N = 7;
			break;
		case 4:
			printf("0");
			Gotoxy(x, y + 1);
			printf("|");
			Gotoxy(x - 1, y);
			std::cout << char(92);
			Gotoxy(x + 1, y + 1);
			std::cout << char(92);
			Gotoxy(x, y + 2);
			printf("|");
			Gotoxy(x + 1, y + 2);
			std::cout << char(92);
			Sleep(250);
			N = 10;

			break;
		case 5:
			printf("0");
			Gotoxy(x, y + 1);
			printf("|");
			Gotoxy(x - 1, y);
			std::cout << char(92);
			Gotoxy(x + 1, y + 1);
			std::cout << "/";
			Gotoxy(x + 1, y + 2);
			printf("/");
			Gotoxy(x - 1, y + 2);
			std::cout << char(92);
			Sleep(250);
			N = 9;

			break;
		default:
			Gotoxy(x - 3, y);
			printf("      ");
			Gotoxy(x - 3, y + 1);
			printf("      ");
			Gotoxy(x - 2, y + 1);
			printf("      ");
			Gotoxy(x + 1, y);
			printf("      ");
			Gotoxy(x - 2, y + 2);
			printf("      ");
			Gotoxy(x + 1, y + 2);
			printf("      ");

			switch (N)
			{
			case 6:
				N = 3;
				break;
			case 7:
				N = 2;
				break;
			case 8:
				N = 5;
				break;
			case 9:
				N = 4;
				break;
			default:
				N = 1;
				break;
			}
			break;
		}
		Gotoxy(x, y);
	}
}



void Gym::Concierto(int x, int  y) {//funcion vacia para dibujar el escenario
	//arriba hacia abajo
	for (int i = 0; i < 10; i++) {
		Gotoxy(x, y + i);
		printf("|");
	}
	//izquierda a derecha
	for (int i = 0; i < 50; i++) {
		Gotoxy(x + i, y);
		printf("-");
	}//linea media de la tarima
	for (int i = 0; i < 50; i++) {
		Gotoxy(x + 1 + i, y + 7);
		printf("-");
	}
	//derecha a izquierda
	for (int i = 0; i < 50; i++) {//???
		Gotoxy(x + 50 - i, y + 11);
		printf("-");
	}
	//abajo hacia arriba
	for (int i = 0; i < 10; i++) {
		Gotoxy(x + 50, y + 11 - i);
		printf("|");
	}
}
void Gym::Gotoxy(int x, int y) {//Handle puntero inteligente de los sistemas operativos en este caso windows
	HANDLE hcon;//permiste controlar memoria o objetos del SO en este caso windows 
	hcon = GetStdHandle(STD_OUTPUT_HANDLE);//actica el control del screen este caso el cmd
	COORD dwPos;//crear un tipo de cordenadas.
	dwPos.X = x;//cordenada X
	dwPos.Y = y;//cordenada Y
	SetConsoleCursorPosition(hcon, dwPos);//Ubica el cursor en las cordenadas.
}

