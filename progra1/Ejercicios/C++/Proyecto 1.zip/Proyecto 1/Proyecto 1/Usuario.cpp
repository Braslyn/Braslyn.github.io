#include "Usuario.h"

Usuario::Usuario() {
	nombre = "Paco";
	id = 402420750;
	ptrT = new Ticket*[5];//inicia la candidad maxima de tickets maximos
	for (short int i = 0; i < 5;i++) {
		ptrT[i] = nullptr; //los inicia en nulo
	}
	ticketAtc = 0;//conteo de cuantos tickets tiene actual mente
}

Usuario::Usuario(std::string Nombre,int Id) {//lo de arriba pero con parametros
	nombre = Nombre;
	id = Id;
	ptrT = new Ticket*[5];
	for (short int i = 0; i < 5; i++) {
		ptrT[i] = nullptr;
	}
	ticketAtc = 0;
}


Usuario::~Usuario() {
	for (int i = 0; i < 5; i++) {//destruye tickets
		if (ptrT[i] != nullptr)
		{
				delete ptrT[i];
		}

	}
	delete[] ptrT;//destruye el almacen de tickets
	ptrT = nullptr;
}

bool Usuario::setTickets(int T) {//recibe un numero para aumento de tickets 
	if (ticketAtc + T <= 5 && ticketAtc+T>-1) {//a�ade o elimina tickets , ademas devuelve si es posible efectual la accion
		ticketAtc += T;
		return true;
	}
	else {
		return false;
	}
}



void Usuario::SetFilCol(int F, int C,int Ntic) {
	ptrT[Ntic]->setFila(F);
	ptrT[Ntic]->setColumna(C);
}

std::string Usuario::getNombre() {//retorna nombre del Usuario
	return nombre;
}

int Usuario::getID() {//retorna id del usuario
	return id;
}

short int Usuario::getTicketAtc() {//devuelve el nuemro de tickets que tiene el usuario
	return ticketAtc;
}

Ticket* Usuario::getTicket(int F, int C, std::string L) {//recibe Filas columnas y luga , retorna un puntero de ticket
	for (int i = 0; i < 5; i++)
	{
		if (ptrT[i]!= nullptr && ptrT[i]->getFila()==F&& ptrT[i]->getColumna()==C&& ptrT[i]->getLugar()==L) {
			return ptrT[i];
		}
	}
	return nullptr;
	
}

short int Usuario::getNTicket(int F, int C, std::string L) {//recibe Filas columnas y luga , retorna un puntero de ticket
	for (int i = 0; i < 5; i++)
	{
		if (ptrT[i] != nullptr && ptrT[i]->getFila() == F && ptrT[i]->getColumna() == C && ptrT[i]->getLugar() == L) {
			return i;
		}
	}
}

void Usuario::setTVip(bool E, short int Ntic) {//recibe el estado vip y numero de ticket para a�adirlo al ticket
	ptrT[Ntic]->setVip(E);
}

void Usuario::setPTicket(Ticket *Tic) {//a�ade una direccion de ticket al usuario , resibe una clase ticket y no retorna ningun parametro
	for (short int i = 0; i < 5; i++){
		if (ptrT[i] == nullptr) {
			ptrT[i] = Tic;
			i = 5;
		}
	}
}
//Ntic = numero de Tickets del usurario | max 5!
std::string Usuario::getTLugar(int Ntic) {//devuelve el lugar del concierto en el ticket
	return ptrT[Ntic]->getLugar();
}

short int Usuario::getTFila(int Ntic){//devuelve la fila del concierto en el ticket
    return ptrT[Ntic]->getFila();
}

short int Usuario::getTColumna(int Ntic) {//devuelve la columna del concierto en el ticket
	return ptrT[Ntic]->getColumna();
}

int Usuario::getTPrecio(int Ntic) {//devulve el monto a pagar con iv y si es vip -- 
	return ptrT[Ntic]->getprecio();
}

bool Usuario::getTVip(short int Ntic) {//a�ade una direccion de ticket al usuario 
	return ptrT[Ntic]->getVip();
}


std::ostream& operator<<(std::ostream&out, const Usuario *U) {//muestra todos los tickes que tiene un usuario , sobrecarga << y recibe un puntero de usuario
	int NV = U->ticketAtc;
		out << "-----------------------------------------" << endl;
		for (short int i = 0; i < 5 && NV>0; i++){
			if (U->ptrT[i]!=nullptr){
				out << "\t Ticket  " << i + 1 << endl;
				out << "Lugar/Gimnasio: " << U->ptrT[i]->getLugar() << endl;
				out << "Fila: " << U->ptrT[i]->getFila()+1 << endl;
				out << "Campo: " << U->ptrT[i]->getColumna()+1 << endl;
				U->ptrT[i]->getVip() == true ? out << "Estado: VIP" : out << "Estado: standar" << endl;
				out << "Precio: " << U->ptrT[i]->getprecio() << endl;
				out << "fecha de compra: " << U->ptrT[i]->getFechaCompra()<<endl;
				NV--;
			}
			out << "-----------------------------------------" << endl;
		}
	return out;
}



void Usuario::EliminarTikets(std::string Lug) {//recibe un lugar y elimina todos los tickets con ese lugar
	for (int i = 0; i < 5; i++){
		if (ptrT[i]!=nullptr)
		{
			if (ptrT[i]->getLugar() == Lug) {
				delete ptrT[i];
				ptrT[i] = nullptr;
				setTickets(-1);
			}
		}
		
	}
}


bool Usuario::EliminacionTicket(int F, int C, std::string Lugar) {//elimina un solo ticket , recibe fila columna y lugar para identificarlo
	//Adicionalmente devuelve si se efectuo

	for(int i = 0; i < 5;i++) {
		if(ptrT[i] != nullptr) {
			if (ptrT[i]->getLugar() == Lugar && ptrT[i]->getFila() == F && ptrT[i]->getColumna() == C) {
				delete ptrT[i];
				ptrT[i] = nullptr;
				return true;
			}
		}
	}
	return false;
}