#ifndef GYM_H

#define GYM_H
#define CAPACIDAD 500
#define FILAS	50
#define COSTO 2500

#define ANSI_COLOR_RED     "\x1b[31m"
#define ANSI_COLOR_GREEN   "\x1b[32m"
#define ANSI_COLOR_YELLOW  "\x1b[33m"
#define ANSI_COLOR_BLUE    "\x1b[34m"
#define ANSI_COLOR_MAGENTA "\x1b[35m"
#define ANSI_COLOR_CYAN    "\x1b[36m"
#define ANSI_COLOR_BRIGHT  "\x1b[1m"
#define ANSI_COLOR_RESET   "\x1b[0m"
#define ANSI_BACKGROUND_RED     "\x1b[41m"
#define ANSI_BACKGROUND_GREEN   "\x1b[42m"
#define ANSI_BACKGROUND_YELLOW  "\x1b[43m"
#define ANSI_BACKGROUND_BLUE    "\x1b[44m"
#define ANSI_BACKGROUND_MAGENTA "\x1b[45m"

#include "Usuario.h"
#include "Tickets.h"
#include <iostream>
#include <string>
#include <sstream>
#include <conio.h>
#include <windows.h>  
#include <stdio.h>  
#include <wchar.h>


class Gym
{
public:

	Gym();
	Gym(int,int,std::string,std::string,short int,short int,short int,int);
	Gym(Gym& gym,string);
	~Gym();

	void Gotoxy(int, int);
	void Animacion(int, int);
	void Concierto(int, int);
	friend std::ostream& operator<<(std::ostream&,const Gym *);//equivalente toString c++
	int getColumnas();
	int getFilas();
	Usuario *getSilla(int,int);//devuleve una direccion de memoria donde se ubica una compra
	bool ExistUser(std::string);
	void setSilla(int, int,Usuario *);//asigna un campo en el GYM
	std::string getNombre(int, int);
	int getID(int, int);
	short int getTicketAtc(int, int);//
	int getValor();
	int getCR();//campos Restantes
	std::string getDescripcion();
	void setLugar(std::string);
	void setDescripcion(std::string);
	void setDia(short int);
	void setMes(short int);
	void setAno(short int);
	void setValor(int);
	void setPTicket(int,int,Ticket *Tic);
	std::string ImprimiFila(int);
	bool XYUser(int&,int&, std::string Nom);
	std::string getLugar();//obtiene el lugar del gym
	std::string GetTLugar(int,int,int);//obtiene  el lugar del ticket
	short int GetTFila(int, int, int);//obtiene  la fila del ticket
	short int GetTColumna(int, int, int);//obtiene  la columna del ticket
	short int GetTPrecio(int, int, int);//obtiene  el precio con impuesto del ticket
private:
	Usuario ***ptrS;
	short int dia;
	short int mes;
	short int anio;
	int capacidad;
	int camposRestantes;
	int filas;
	int columnas;
	std::string lugar;
	std::string descripcion;
	int valor;
};

#endif