﻿#include <iostream>
#include <conio.h>
#include "Gym.h"
#include "Tickets.h"
#include "Usuario.h"
#include <stdio.h>
#include "dos.h"
#include <time.h>

using std::cout;
using std::endl;
using std::string;

int main() {
	// A-1\n getline(stream,variable,'-')
	//     getline(stream,variable,'\n')
	//char a = 'B';//1
	//int b = a-65;
	// std::cout << "B es igual al indice " << b << "\n";
	
	
	//codigo para usar colores en las view
	HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
	if (hOut == INVALID_HANDLE_VALUE)
	{
		return GetLastError();
	}

	DWORD dwMode = 0;
	if (!GetConsoleMode(hOut, &dwMode))
	{
		return GetLastError();
	}

	dwMode |= ENABLE_VIRTUAL_TERMINAL_PROCESSING;
	if (!SetConsoleMode(hOut, dwMode))
	{
		return GetLastError();
	}



	Usuario *NewUser=nullptr;
	Ticket *newTicket=nullptr;
	Gym **Gyms;
	Gyms = new Gym*[3];
	for (short int i = 0; i < 3; i++)//inicia el vector de gyms
	{
		Gyms[i] = nullptr;
	}
	short int CGyms=0;//comprobacion de Gyms
	short int Num=0;//Uso para repeticiones de accion , como añadir varios Gyms
	string nombre;//Variable de condicion Admin/user
	string Lugar;//Variable de saber a 

	int fil1, col1;//Para mantener la ubicacion del usuario en la matriz
	int campo=0;//se utiliza para seleccionar un asiento
	short int k = 0;//se utiliza para buscar personas en los gyms
	bool ExisteU=false;//utilizado para verificar si el usuario ya existe en alguno de los gimnasios
	bool FindUser=false;

	std::string Sllenar[2];//utilizada para llenar datos de Usuario/GYM
	int Illenar[3];//utilizada para llenar datos de Usuario/GYM
	short int SIllenar[3];//utilizada para llenar datos de Usuario/GYM
	std::string fecha;//fecha del sistema
	std::string fecha2;//fecha del sistema
	bool Salir=false;//variable para salir del programa
	bool bMenu = false;//variable para salir del programa
	short int mode=3;//inicia el sistema a default
	short int SelectMenu=0;//accede a alguna funcion del submenu

	cout << "digite la Fecha de hoy -> formato DD/MM/AAAA" << endl;
	std::getline(std::cin, fecha);
	do {
		//comprobacion Admin/user
		system("cls");
		cout << "\t Bienvenido al sistema de compra Navide" << char(164)<< "o "<<endl;
		cout << " Digite su nombre para iniciar el proceso de compra \n 0) para salir del sistema" << endl;
		std::getline(std::cin, nombre);
		if (nombre == "Admin" || nombre == "admin")//utiliza nombre de nuevo para verificar el acceso , ya que nombre pierda importancia en administrador.
		{
			for (short int i = 3; i > 0; i--) {
				system("cls");
				cout << "Ha entrado al sistema de administrador!" << endl;//inicia el modo administrador
				cout << "Digite la clave de acceso de administrador" << endl;
				cout << "Posee " << i << " intentos" << endl;
				std::getline(std::cin, nombre);//pide la clave de autoidentificacion.
				if (nombre == "ad12ac")
				{
					i = 0;
					mode = 1;//pasa valor para el modo admin
				}
			}
			system("cls");
			if (mode == 3) {
			std::cout << "Clave de administrador invalida - inicie de nuevo sesion como administrador" << endl;
			std::cin.clear();
			std::cin.ignore(1024, '\n');
			Sleep(2000);
		}
			system("cls");
		}
		else {
			mode = 2;//valor al modo user
			if (nombre=="0")
			{
				mode = 0;//valor al modo default
				Salir = true;
			}
			
		}

		do {

			switch (mode)
			{
			case 1://ADMIN
				bMenu = false;
				system("cls");
				cout << "Bienvenido administrador" << endl;
				cout << "1)Agregar Gimnasio" << endl;
				cout << "2)Modificar Gimnasio" << endl;
				cout << "3)Mostrar Gimnasios" << endl;
				cout << "4)Eliminar Gimnasio" << endl;
				cout << "5)Salir al menu" << endl;
				cout << "6)Salir del programa" << endl;
				std::cin >> SelectMenu;
				std::cin.ignore();
				//std::cin.clear();
				system("cls");
				switch (SelectMenu)
				{
				case 1:
					CGyms = 0;
					for (short int i = 0; i < 3; i++)//define si es posible añadir gyms
					{
						if (Gyms[i] != nullptr) {
							CGyms += 1;
						}
					}
					if (CGyms > 2) {
						cout << "no puede agregar mas Gimnasios" << endl;
						Sleep(2000);
					}
					else {
						do {
							cout << "Puede a"<<char(164)<<"adir " << 3 - CGyms << " Gimnasios" << endl;//valida si es posible añadir x cantidad de gimnasios
							std::cout << "Cuantos desea a" << char(164) << "adir " << endl;
							if (std::cin >> Num) {

							}
							else {
								std::cout << "Caracter invalido" << endl;
								std::cin.clear();
								std::cin.ignore(1024, '\n');
								Num = 4;
								Sleep(2000);
							}
							system("cls");
						} while (Num >= 4 - CGyms);
						for (short int i = 0; i < Num; i++)//añade la cantidad deseada de gyms
						{
							int NG = 0;//inicia lugar para añadir gym
							bool crear = false;
							do {
								if (Gyms[NG] == nullptr) {
									crear = true;
								}
								else {
									NG++;
								}
							} while (crear == false);
							system("cls");
							cout << "Digite el Lugar donde se ubica el Gym" << endl;
							std::cin.ignore();
							std::getline(std::cin, Sllenar[0]);
							cout << "Digite la descripcion del evento/concierto " << endl;
							std::getline(std::cin, Sllenar[1]);
							cout << "Digite la capacidad del Gimnasio" << endl;
							std::cin >> Illenar[0];
							do {
								cout << "Digite las filas del Gimnasio" << endl;
								std::cin >> Illenar[1];
							} while (Illenar[1]>Illenar[0]);
							cout << "Digite el valor de la entrada sin impuestos ni Vip" << endl;
							std::cin >> Illenar[2];
							cout << "Digite el numero de dia del evento/concierto" << endl;
							std::cin >> SIllenar[0];
							cout << "Digite el mes del evento/concierto" << endl;
							std::cin >> SIllenar[1];
							cout << "Digite el a" << char(164) << "o del evento/concierto" << endl;
							std::cin >> SIllenar[2];
							Gyms[NG] = new Gym(Illenar[0], Illenar[1], Sllenar[0], Sllenar[1], SIllenar[0], SIllenar[1], SIllenar[2], Illenar[2]);
						}
						break;
				case 2:
					for (short int i = 0; i < 3; i++)//define si es posible mostrar gyms
					{
						if (Gyms[i] != nullptr) {
							cout << "Gym #" << i + 1;
							cout << Gyms[i];
							CGyms += 1;
							std::cin.get();
							system("cls");
						}
					}
					if (CGyms == 0) {
						cout << "No hay Gimnasios disponibles" << endl;
						Sleep(2000);
					}
					else {
						short int prueba;
						do {
							cout << "Que Gym desea modificar | 0) para salir" << endl;//modifica el gym
							std::cin >> prueba;
							switch (prueba) {
							case 0:
								break;
							case 1:
								std::cin.ignore();
								if (Gyms[prueba-1]!=nullptr) {
									cout << "Digite un nuevo lugar para el gimnasio" << endl;
									std::getline(std::cin, Sllenar[0]);
									cout << "Digite una nueva descripcion para el gimnasio" << endl;
									std::getline(std::cin, Sllenar[1]);
									cout << "Digite un nuevo precio sin vip ni iva" << endl;
									std::cin >> Illenar[0];
									cout << "Digite un nuevo dia" << endl;
									std::cin >> SIllenar[0];
									cout << "Digite un nuevo mes" << endl;
									std::cin >> SIllenar[1];
									cout << "Digite un nuevo a"<<char(164)<<"o" << endl;
									std::cin >> SIllenar[2];
									Gyms[prueba - 1]->setLugar(Sllenar[0]);
									Gyms[prueba - 1]->setDescripcion(Sllenar[1]);
									Gyms[prueba - 1]->setDia(SIllenar[0]);
									Gyms[prueba - 1]->setMes(SIllenar[1]);
									Gyms[prueba - 1]->setAno(SIllenar[2]);
									Gyms[prueba - 1]->setValor(Illenar[0]);
									cout << "Modificado!!" << endl;
									Sleep(2000);
									prueba = 0;
								}
								else {
									cout << "Gimnasio "<<prueba<<" no existe" << endl;
								}
								break;
							case 2:
								std::cin.ignore();
								if (Gyms[prueba-1] != nullptr) {
									cout << "Digite un nuevo lugar para el gimnasio" << endl;
									std::getline(std::cin, Sllenar[0]);
									cout << "Digite una nueva descripcion para el gimnasio" << endl;
									std::getline(std::cin, Sllenar[1]);
									cout << "Digite un nuevo precio sin vip ni iva" << endl;
									std::cin >> Illenar[0];
									cout << "Digite un nuevo dia" << endl;
									std::cin >> SIllenar[0];
									cout << "Digite un nuevo mes" << endl;
									std::cin >> SIllenar[1];
									cout << "Digite un nuevo a" << char(164) << "o" << endl;
									std::cin >> SIllenar[2];
									Gyms[prueba - 1]->setLugar(Sllenar[0]);
									Gyms[prueba - 1]->setDescripcion(Sllenar[1]);
									Gyms[prueba - 1]->setDia(SIllenar[0]);
									Gyms[prueba - 1]->setMes(SIllenar[1]);
									Gyms[prueba - 1]->setAno(SIllenar[2]);
									Gyms[prueba - 1]->setValor(Illenar[0]);
									cout << "Modificado!!" << endl;
									Sleep(2000);
									prueba = 0;
								}
								else {
									cout << "Gimnasio " << prueba << " no existe" << endl;
								}
								break;
							case 3:
								if (Gyms[prueba-1] != nullptr) {
									std::cin.ignore();
									cout << "Digite un nuevo lugar para el gimnasio" << endl;
									std::getline(std::cin, Sllenar[0]);
									cout << "Digite una nueva descripcion para el gimnasio" << endl;
									std::getline(std::cin, Sllenar[1]);
									cout << "Digite un nuevo precio sin vip ni iva" << endl;
									std::cin >> Illenar[0];
									cout << "Digite un nuevo dia" << endl;
									std::cin >> SIllenar[0];
									cout << "Digite un nuevo mes" << endl;
									std::cin >> SIllenar[1];
									cout << "Digite un nuevo a" << char(164) << "o" << endl;
									std::cin >> SIllenar[2];
									Gyms[prueba - 1]->setLugar(Sllenar[0]);
									Gyms[prueba - 1]->setDescripcion(Sllenar[1]);
									Gyms[prueba - 1]->setDia(SIllenar[0]);
									Gyms[prueba - 1]->setMes(SIllenar[1]);
									Gyms[prueba - 1]->setAno(SIllenar[2]);
									Gyms[prueba - 1]->setValor(Illenar[0]);
									cout << "Modificado!!" << endl;
									Sleep(2000);
									prueba = 0;
								}
								else {
									cout << "Gimnasio " << prueba << " no existe" << endl;
								}
								break;
							default:
								cout << "Invalido";
								break;
							}
						} while(prueba!=0);
					}
					break;
				case 3://muestra los Gyms
					CGyms= 0;
					for (short int i = 0; i < 3; i++)//define si es posible mostrar gyms
					{
						if (Gyms[i] != nullptr) {
							cout << Gyms[i];
							CGyms += 1;
							std::cin.get();
							system("cls");
						}
					}
					if (CGyms==0) {
						cout << "No hay Gimnasios disponibles" << endl;
						Sleep(2000);
					}
					break;
				case 4://eliminar Gyms
					for (short int i = 0; i < 3; i++)//define si es posible mostrar gyms
					{
						if (Gyms[i] != nullptr) {
							cout << "Gym #" << i + 1;
							cout << Gyms[i];
							CGyms += 1;
							std::cin.get();
							system("cls");
						}
					}
					if (CGyms == 0) {
						cout << "No hay Gimnasios disponibles" << endl;
						Sleep(2000);
					}
					else {
						short int prueba;
						do {
							system("cls");
							cout << "Que Gym desea Eliminar | 0) para salir" << endl;
							std::cin >> prueba;
						} while (prueba>3 && prueba<0);
						switch (prueba) {
						case 0:
							
							break;
						case 1:
							delete Gyms[0];
							Gyms[0] = nullptr;
							cout << "Gimnasio " << prueba << " Eliminado!" << endl;
							Sleep(2000);
							break;
						case 2:
							delete Gyms[1];
							Gyms[1] = nullptr;
							Sleep(2000);
							cout << "Gimnasio " << prueba << " Eliminado!" << endl;
							break;
						case 3:
							delete Gyms[2];
							Gyms[2] = nullptr;
							Sleep(2000);
							cout << "Gimnasio " << prueba << " Eliminado!" << endl;
							break;
						}
					}
					
					break;
				case 5:
					bMenu = true;
					Salir = false;
					system("cls");
					break;
				case 6:
					bMenu = true;
					Salir = true;
					break;
				default:
					break;
					}
				}
				break;
			case 2://USER
				k = 0;
				fil1 = 0;
				col1 = 0;
				system("cls");
				cout << "Bienvenido " << nombre << endl;
				for (short int i = 0; i < 3; i++)//define si hay gyms en los cuales comprar entradas
				{
					if (Gyms[i]!=nullptr)
					{
						CGyms += 1;
					}
				}
				if (CGyms > 0) {

					if (ExisteU == false) {

						for (k = 0; k < 3; k++) {
							if (Gyms[k] != nullptr) {
								fil1 = Gyms[k]->getFilas();
								col1 = Gyms[k]->getColumnas();

								for (int i = 0; i < fil1; i++) {
									for (int j = 0; j < col1; j++) {
										if (Gyms[k]->getSilla(i, j) != nullptr) {
											if (Gyms[k]->getNombre(i, j) == nombre)
												ExisteU = true; col1 = j; fil1 = i; NewUser = Gyms[k]->getSilla(fil1, col1);
										}

									}
								}
							}
						}
					}

					if (ExisteU==true) {
						bMenu = false;
						cout<<"Tiene " << NewUser->getTicketAtc() << " tickets comprados" << endl;
						cout << "1)Comprar/asignar Ticket" << endl;
						cout << "2)Modificar compra de ticket" << endl;
						cout << "3)Eliminar compra de ticket" << endl;
						cout << "4)imprimir compras" << endl;
						cout << "5)Cerrar sesion" << endl;
						std::cin >> SelectMenu;
						std::cin.ignore();
					}else{
						cout << "Digite su cedula porfavor" << endl;
						std::cin >> Illenar[0];
						NewUser = new Usuario(nombre,Illenar[0]);
						bMenu = false;
						system("cls");
						cout << "Tiene " << NewUser->getTicketAtc() << " tickets comprados" << endl;
						cout << "1)Comprar/asignar Ticket" << endl;
						cout << "2)Modificar compra de ticket" << endl;
						cout << "3)Eliminar compra de ticket" << endl;
						cout << "4)imprimir compras" << endl;
						cout << "5)Cerrar sesion" << endl;
						std::cin >> SelectMenu;
						std::cin.ignore();
						ExisteU = true;
					}
					//std::cin.clear();
					switch (SelectMenu) {
					case 1:

						short int SG;//Select Gym
						CGyms = 0;
						system("cls");
						for (short int i = 0; i < 3; i++)//define si es posible mostrar gyms
						{
							if (Gyms[i] != nullptr) {
								cout << "Gimnasio #" << i + 1 << endl;
								cout << Gyms[i];
								CGyms += 1;
								std::cin.get();
								system("cls");
							}
						}
						if (CGyms == 0) {
							cout << "No hay Gimnasios disponibles" << endl;
							Sleep(2000);
						}
						else {
							bool repetir = true;
							do {
								do {
									system("cls");
									cout << "En Cual Gimnasio desea comprar una entrada?? | 0) Salir" << endl;
									std::cin >> SG;
								} while (Gyms[SG - 1] == nullptr || SG < 0);

								switch (SG) {
								case 0:
									repetir = false;
									break;
								case 1:
									cout << "Nota: Sillas verder=Sillas Disponibles , sillas rojas = sillas no disponibles" << endl;
									cout << "Precio estandar " << Gyms[SG - 1]->getValor()*1.13 << " Precio Vip(PriSG - 1eras 20 filas): " << Gyms[SG - 1]->getValor()*1.13*1.5 << endl;
									cout << "El gimnasio tiene " << Gyms[SG - 1]->getFilas() << " filas , Cual desea ver" << endl;
									std::cin >> fil1;
									system("cls");
									Gyms[SG - 1]->Concierto(25, 1);
									Gyms[SG - 1]->Animacion(50, 5);
									Gyms[SG - 1]->Gotoxy(1, 15);
									cout << "\t Fila #" << fil1 << endl;
									for (int i = 0; i < Gyms[SG - 1]->getColumnas(); i++) {
										if (i < 9) {
											cout << " " << i + 1 << "  ";
										}
										else {
											cout << " " << i + 1 << " ";
										}

									}
									cout << endl << Gyms[SG - 1]->ImprimiFila(fil1 - 1) << endl;
									std::cin.ignore();
									cout << "Que campo desea comprar? 0)Ningino" << endl;
									std::cin >> campo;
									if (campo == 0) {
										cout << "desea volver a seleccion de fila u otro gimnasio? 1)si 0)no" << endl;
										std::cin >> campo;
										if (campo == 0) {
											repetir = false;
										}
									}
									else {

										if (Gyms[SG - 1]->getSilla(fil1 - 1, campo - 1) == nullptr) {
											if (NewUser->setTickets(1))
											{
												Gyms[SG - 1]->setSilla(fil1 - 1, campo - 1, NewUser);
												int vip = false;
												if (fil1 <= 20)
													vip = true;

												newTicket = new Ticket(Gyms[SG - 1]->getLugar(), Gyms[SG - 1]->getValor(), vip, fil1 - 1, campo - 1,fecha);
												Gyms[SG - 1]->setPTicket(fil1 - 1, campo - 1, newTicket);
												newTicket = nullptr;
												system("cls");
												cout << "Transaccion Efectiva! Gracias por comprar" << endl;
												repetir = false;
												system("pause");
											}
											else {
												system("cls");
												cout << "Su cuenta ya tiene el maximo de tickets posibles" << endl;
												repetir = false;
												system("pause");
											}
										}
										else {
											cout << "campo " << campo << " ya fue Comprado" << endl;
											system("pause");
											repetir = true;
										}

									}
									break;
								case 2:
									cout << "Nota: Sillas verder=Sillas Disponibles , sillas rojas = sillas no disponibles" << endl;
									cout << "Precio estandar " << Gyms[SG - 1]->getValor()*1.13 << " Precio Vip(PriSG - 1eras 20 filas): " << Gyms[SG - 1]->getValor()*1.13*1.5 << endl;
									cout << "El gimnasio tiene " << Gyms[SG - 1]->getFilas() << " filas , Cual desea ver" << endl;
									std::cin >> fil1;
									system("cls");
									Gyms[SG - 1]->Concierto(25, 1);
									Gyms[SG - 1]->Animacion(50, 5);
									Gyms[SG - 1]->Gotoxy(1, 15);
									cout << "\t Fila #" << fil1 << endl;
									for (int i = 0; i < Gyms[SG - 1]->getColumnas(); i++) {
										if (i < 9) {
											cout << " " << i + 1 << "  ";
										}
										else {
											cout << " " << i + 1 << " ";
										}

									}
									cout << endl << Gyms[SG - 1]->ImprimiFila(fil1 - 1) << endl;
									std::cin.ignore();
									cout << "Que campo desea comprar? 0)Ningino" << endl;
									std::cin >> campo;
									if (campo == 0) {
										cout << "desea volver a seleccion de fila u otro gimnasio? 1)si 0)no" << endl;
										std::cin >> campo;
										if (campo == 0) {
											repetir = false;
										}
									}
									else {

										if (Gyms[SG - 1]->getSilla(fil1 - 1, campo - 1) == nullptr) {
											if (NewUser->setTickets(1))
											{
												Gyms[SG - 1]->setSilla(fil1 - 1, campo - 1, NewUser);
												int vip = false;
												if (fil1 <= 20)
													vip = true;

												newTicket = new Ticket(Gyms[SG - 1]->getLugar(), Gyms[SG - 1]->getValor(), vip, fil1 - 1, campo - 1, fecha);
												Gyms[SG - 1]->setPTicket(fil1 - 1, campo - 1, newTicket);
												newTicket = nullptr;
												system("cls");
												cout << "Transaccion Efectiva! Gracias por comprar" << endl;
												repetir = false;
												system("pause");
											}
											else {
												system("cls");
												cout << "Su cuenta ya tiene el maximo de tickets posibles" << endl;
												repetir = false;
												system("pause");
											}
										}
										else {
											cout << "campo " << campo << " ya fue Comprado" << endl;
											system("pause");
											repetir = true;
										}

									}
									break;
								case 3:
									cout << "Nota: Sillas verder=Sillas Disponibles , sillas rojas = sillas no disponibles" << endl;
									cout << "Precio estandar " << Gyms[SG - 1]->getValor()*1.13 << " Precio Vip(PriSG - 1eras 20 filas): " << Gyms[SG - 1]->getValor()*1.13*1.5 << endl;
									cout << "El gimnasio tiene " << Gyms[SG - 1]->getFilas() << " filas , Cual desea ver" << endl;
									std::cin >> fil1;
									system("cls");
									Gyms[SG - 1]->Concierto(25, 1);
									Gyms[SG - 1]->Animacion(50, 5);
									Gyms[SG - 1]->Gotoxy(1, 15);
									cout << "\t Fila #" << fil1 << endl;
									for (int i = 0; i < Gyms[SG - 1]->getColumnas(); i++) {
										if (i < 9) {
											cout << " " << i + 1 << "  ";
										}
										else {
											cout << " " << i + 1 << " ";
										}

									}
									cout << endl << Gyms[SG - 1]->ImprimiFila(fil1 - 1) << endl;
									std::cin.ignore();
									cout << "Que campo desea comprar? 0)Ningino" << endl;
									std::cin >> campo;
									if (campo == 0) {
										cout << "desea volver a seleccion de fila u otro gimnasio? 1)si 0)no" << endl;
										std::cin >> campo;
										if (campo == 0) {
											repetir = false;
										}
									}
									else {

										if (Gyms[SG - 1]->getSilla(fil1 - 1, campo - 1) == nullptr) {
											if (NewUser->setTickets(1))
											{
												Gyms[SG - 1]->setSilla(fil1 - 1, campo - 1, NewUser);
												int vip = false;
												if (fil1 <= 20)
													vip = true;

												newTicket = new Ticket(Gyms[SG - 1]->getLugar(), Gyms[SG - 1]->getValor(), vip, fil1 - 1, campo - 1, fecha);
												Gyms[SG - 1]->setPTicket(fil1 - 1, campo - 1, newTicket);
												newTicket = nullptr;
												system("cls");
												cout << "Transaccion Efectiva! Gracias por comprar" << endl;
												repetir = false;
												system("pause");
											}
											else {
												system("cls");
												cout << "Su cuenta ya tiene el maximo de tickets posibles" << endl;
												repetir = false;
												system("pause");
											}
										}
										else {
											cout << "campo " << campo << " ya fue Comprado" << endl;
											system("pause");
											repetir = true;
										}

									}
									break;
								default:
									break;
								}

							} while (repetir == true);
						}
						break;
					case 2://Modificar/ cambiar de lugar el asiento
						Sllenar[0] = ""; Illenar[0] = 0; Illenar[1] = 0;
						fil1 = 0;campo = 0;
						if (NewUser->getTicketAtc() > 0){
							bool avanzar = true;
							do {
								system("cls");
								cout << "Cambio de Asiento / Repetir este proceso signica que los datos no son correctos" << endl;
								cout << "Digite el lugar del evento donde desea cambiar el lugar / 0)salir " << endl;
								std::getline(std::cin, Sllenar[0]);
								if (Sllenar[0]!="0") {
									cout << "Digite la fila donde se encuentra su asiento" << endl;
									std::cin >> Illenar[0];
									cout << "Digite el campo de su asciento" << endl;
									std::cin >> Illenar[1];
									std::cin.ignore();
									avanzar = true;
									if (NewUser->getTicket(Illenar[0] - 1, Illenar[1] - 1, Sllenar[0]) == nullptr) {
										avanzar = false;
									}
								}
								else {
									avanzar = true;
								}

							} while (avanzar==false);
							if (Sllenar[0]!="0") {
								short int m = 0;
								for (m = 0; m < 3; m++){
									if (Gyms[m] != nullptr) {
										if (Sllenar[0] == Gyms[m]->getLugar()) {
											break;
										}
									}
								}
								system("cls");
								cout << "Nota: Sillas verder=Sillas Disponibles , sillas rojas = sillas no disponibles" << endl;
								cout << "Precio estandar " << Gyms[m]->getValor()*1.13 << " Precio Vip(Primeras 20 filas): "<< Gyms[m]->getValor()*1.13*1.5 << endl;
								cout << "El gimnasio tiene " << Gyms[m]->getFilas() << " filas , Cual desea ver" << endl;
								std::cin >> fil1;
								system("cls");
								Gyms[m]->Concierto(25, 1);
								Gyms[m]->Animacion(50, 5);
								Gyms[m]->Gotoxy(1, 15);
								cout << "\t Fila #" << fil1 << endl;
								for (int i = 0; i < Gyms[m]->getColumnas(); i++) {
									if (i < 9) {
										cout << " " << i + 1 << "  ";
									}
									else {
										cout << " " << i + 1 << " ";
									}

								}
								cout << endl << Gyms[m]->ImprimiFila(fil1 - 1) << endl;
								std::cin.ignore();
								do {
									cout << "Que campo desea intercambiar? 0)No intercambiar" << endl;
									std::cin >> campo;
								} while (campo < 0 && campo>Gyms[m]->getColumnas()&&Gyms[m]->getSilla(fil1,campo));
								if (Gyms[m]->getSilla(fil1 - 1, campo - 1) == nullptr) {
									if (campo != 0) {
										bool estado = true;
										if (fil1 > 20)
											estado = false;
										Gyms[m]->setSilla(fil1 - 1, campo - 1, NewUser);
										Gyms[m]->setSilla(Illenar[0] - 1, Illenar[1] - 1, nullptr);
										NewUser->setTVip(estado, NewUser->getNTicket(Illenar[0] - 1, Illenar[1] - 1, Sllenar[0]));
										NewUser->SetFilCol(fil1 - 1, campo - 1, NewUser->getNTicket(Illenar[0] - 1, Illenar[1] - 1, Sllenar[0]));
										cout << "Actualizado" << endl;
										system("pause");
									}
									else {

										cout << "Este campo ya ha sido comprado"<<endl;
										system("cls");
									}
								}
							}

						}
						else {
							cout << "No ha comprado ningun ticket!" << endl;
							system("pause");
						}

						break;
					case 3://eliminar
						if (NewUser->getTicketAtc() > 0){

							int cord[2] = { 0,0 };
							std::string lug;

							cout << "Digite el lugar del evento" << endl;
							std::getline(std::cin, lug);
							cout << "Digite la fila donde se encuentra su asiento" << endl;
							std::cin >> cord[0];
							cout << "Digite el campo de su asciento" << endl;
							std::cin >> cord[1];
							if (NewUser->EliminacionTicket(cord[0]-1, cord[1]-1, lug)) {
								short int i=0;
								for (i = 0; i < 3; i++)
								{
									if (Gyms[i] != nullptr) {
										if (lug == Gyms[i]->getLugar()) {
											Gyms[i]->setSilla(cord[0]-1, cord[1]-1, nullptr);
											NewUser->setTickets(-1);
											
										}
									}
								}
								cout << "Ticket Eliminado" << endl;
								system("pause");
							}
							else {
								cout << "Datos incorrectos" << endl;
								system("pause");
							}


						}else {
							cout << "No ha comprado ningun ticket!" << endl;
							system("pause");
						}
						

						break;
					case 4:
						system("cls");
						cout <<NewUser<<endl;
						cout << "Presione cualquiere tecla para continuar" << endl;
						std::cin.get();
						break;
					case 5:
						if(NewUser->getTicketAtc() == 0)
							delete NewUser;
						bMenu = true;
						Salir = false;
						ExisteU = false;
						NewUser = nullptr;
						break;
					default:
						break;
					}
				}
				else {
					cout << "No hay Conciertos disponibles" << endl;
					Sleep(2000);
					bMenu = true;
					Salir = false;
				}
				

				break;
			case 0://SALIR

				bMenu = true;
				Salir = true;
				break;
			case 3:
				bMenu = true;
				break;
			default:

				break;
			}

		}while (bMenu == false);
	} while (Salir == false);
	system("cls");
	cout << "\t Gracias por utlizar nuestro sistema";
	Sleep(2000);
	return 0;
}
