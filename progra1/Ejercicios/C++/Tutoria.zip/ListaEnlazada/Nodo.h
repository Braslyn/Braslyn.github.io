#ifndef NODO_H
#define NODO_H
#include "Persona.h"

struct Nodo{// por defecto el es publico
	Persona* valor;
	Nodo* siguiente;          // si no hay nodo siguiente entonces nullptr
	Nodo(Persona& valor,Nodo* siguiente=nullptr):valor(&valor),siguiente(siguiente){}
	// valor se quiera ingresar
};

#endif // !NODO_H
