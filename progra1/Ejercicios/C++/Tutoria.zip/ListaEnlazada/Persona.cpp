#include "Persona.h"

Persona::Persona(std::string nombre, int edad):nombre(nombre),edad(edad){}

std::string Persona::getNombre()
{
	return nombre;
}

int Persona::getEdad()
{
	return edad;
}

std::string Persona::toString(){
	std::stringstream out;
	out <<"{nombre:"<<nombre << ", Edad:" << edad<<"}";
	return out.str();
}

Persona::~Persona(){}
