#include "tutoria.h"
#include <iostream>
#include <vector>

int main() {

	Tutoria tutoria;
	Tutoria tutoria2(*tutoria.getTutor());
	tutoria.addEstudiante(*new Persona("Braslyn",22));
	tutoria.addEstudiante(*new Persona("Paco", 5));
	tutoria.addEstudiante(*new Persona("Hermegilda", 50));
	tutoria.addEstudiante(*new Persona("Anacleto", 70));
	tutoria.addEstudiante(*new Persona("Heiner", 21));
	std::cout << tutoria.toString();

	/*std::cout << "Inicio de lista\n\n";
	std::cout << lista.toString()<<"\n\n";
	lista.invertir();
	std::cout << "lista Revertida\n\n";
	std::cout <<lista.toString() << "\n\n";
	std::cout << "Lista ordenada\n\n";
	lista.ordenar();
	std::cout << lista.toString() << "\n\n";
	std::cout << "Promedio de edades:"<< lista.promedio() << "\n\n";
	*/


	return 0;
}