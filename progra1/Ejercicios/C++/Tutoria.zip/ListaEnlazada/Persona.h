#ifndef PERSONA_H
#define PERSONA_H
#include <string>
#include <sstream>

class Persona
{
public:
	Persona(std::string nombre,int edad);
	std::string getNombre();
	int getEdad();
	std::string toString();
	~Persona();

private:
	std::string nombre;
	int edad;
};


#endif // !PERSONA_H
