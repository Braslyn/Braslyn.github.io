#ifndef TUTORIA_H
#define TUTORIA_H
#include "Lista.h"

class Tutoria{
public:
	Tutoria();
	Tutoria(Persona& tutor);
	void addEstudiante(Persona& estudiante);
	std::string toString();
	Persona* getTutor();
	void setTutor(Persona* tutor);
	~Tutoria();
private:
	Persona* tutor;//Obligatorio
	Persona* tutorAuxiliar;//opcional
	Lista listaDeEstudiantes;// aqui estan los estudiante implicitamente
};

#endif // !TUTURIA_H
