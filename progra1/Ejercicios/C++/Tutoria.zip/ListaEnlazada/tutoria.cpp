#include "tutoria.h"

Tutoria::Tutoria():tutor(new Persona("Braslyn",22)),tutorAuxiliar(nullptr){}

Tutoria::Tutoria(Persona& tutor) : tutor(&tutor), tutorAuxiliar(nullptr) {}
void Tutoria::addEstudiante(Persona& estudiante){
	listaDeEstudiantes.insertarAlFinal(estudiante);
}
std::string Tutoria::toString(){
	std::stringstream out;
	out << "Tutor:" << tutor->toString();
	out << "\nLista de participante: \n" << listaDeEstudiantes.toString();
	return out.str();
}
Persona* Tutoria::getTutor()
{
	return tutor;
}
void Tutoria::setTutor(Persona* tutor){
	tutor = tutor;
}
Tutoria::~Tutoria(){}
