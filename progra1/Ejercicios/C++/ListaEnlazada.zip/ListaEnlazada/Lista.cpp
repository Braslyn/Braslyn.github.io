#include "Lista.h"

Lista::Lista():root(nullptr),cant(0){}

void Lista::insertar(int numero){//inicio es la m�s facil(Gano), insertar al final.
	Nodo* nuevo = new Nodo(numero,root);// ya tenemos el numero adentro del nodo
	//nuevo->siguiente = root;// le pregunto al primero. se coloca detras
	root = nuevo; // se convierte en el nuevo primero
	cant++;
}

void Lista::insertarAlFinal(int numero){// primero si no hay elementos -- hay elementos
	Nodo* nuevo = new Nodo(numero);
	if (this->esVacio()) {
		root =nuevo;
		cant++;
	}else {
		Nodo* aux=root;
		while (aux->siguiente!=nullptr){
			aux = aux->siguiente;
		}
		aux->siguiente = nuevo;
		cant++;
	}

}

void Lista::insertarEnPosicion(int posicion,int numero){
	Nodo* nuevo = new Nodo(numero);
	Nodo* aux = root;
	if (posicion < 1) {
		nuevo->siguiente = root;
		root = nuevo;
	}else {
		for (int i = 0; i < posicion; i++) {
			aux = aux->siguiente;
		}
		nuevo->siguiente = aux->siguiente;
		aux->siguiente = nuevo;
	}
}

void Lista::eliminarEnPosicion(int posicion){
	Nodo* aux = root;
	Nodo* anterior = aux;
	if (posicion < 1) {
		root = root->siguiente;
		delete aux;
	}
	else {
		for (int i = 0; i < posicion; i++) {
			anterior = aux;
			aux = aux->siguiente;
		}
		anterior->siguiente = aux->siguiente;
		delete aux;
	}
	cant--;
}

int Lista::getCant(){
	return cant;
}

void Lista::eliminar(){// eliminar al inicio
	if (!this->esVacio()) {
		Nodo* aux = root;
		root = root->siguiente;
		delete aux;
		cant--;
	}
}

void Lista::eliminarAlFinal(){
	Nodo* aux=root;
	Nodo* anterior=aux;
	if (!this->esVacio()){
		while (aux->siguiente!=nullptr){// si termina, estamos en el ultimo
			anterior = aux;
			aux = aux->siguiente;
		}
		if (aux==root){
			delete root;
			root = nullptr;
		}else {
			anterior->siguiente = nullptr;
			delete aux;
		}
		cant--;
	}
}


int Lista::Obtener(int posicion){// quedre a razon del primero que se inserto, el primero es el primero(Gano);
	Nodo* aux;// el esta pensado para tomar el correspiente y devolver el dato
	aux = root;
	while (posicion>0){
		aux = aux->siguiente;
		posicion--;
	}
	return aux->valor;// falto algo importante , no valide si posicion es valida;
}

void Lista::borrarTodo(){
	Nodo* primero;
	while (!esVacio()){
		primero = root;
		root = root->siguiente;
		delete primero;
	}
}

bool Lista::esVacio(){
	return root==nullptr;
}

std::string Lista::toString(){
	std::stringstream out;
	out << "[";
	Nodo* aux=root;
	for (int i = 0; i < cant ; i++){
		out << aux->valor;
		if (i<cant-1){
			out << ",";
		}
		aux = aux->siguiente;
	}
	out << "]\n";
	return out.str();
}

Lista::~Lista(){
	this->borrarTodo();
}
