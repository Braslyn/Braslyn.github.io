#ifndef LISTA_H
#define LISTA_H
#include "Nodo.h"
#include <string>
#include <sstream>
class Lista
{
public:
	Lista();
	void insertar(int numero);
	void insertarAlFinal(int numero);
	void insertarEnPosicion(int posicion,int numero);
	void eliminarEnPosicion(int posicion);
	int getCant();// n -> constante
	void eliminar();
	void eliminarAlFinal();
	int Obtener(int posicion);
	void borrarTodo();
	bool esVacio();
	std::string toString();
	~Lista();
private:
	Nodo* root;//en un inicio deberia ser nullptr
	int cant;
};


#endif // !LISTA_H
