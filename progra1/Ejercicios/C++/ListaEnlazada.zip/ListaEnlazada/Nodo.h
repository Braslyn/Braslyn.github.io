#ifndef NODO_H
#define NODO_H

struct Nodo{// por defecto el es publico
	int valor;
	Nodo* siguiente;          // si no hay nodo siguiente entonces nullptr
	Nodo(int valor,Nodo* siguiente=nullptr):valor(valor),siguiente(siguiente){}
	// valor se quiera ingresar
};

#endif // !NODO_H
