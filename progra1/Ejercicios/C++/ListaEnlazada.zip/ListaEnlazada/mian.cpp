#include "Lista.h"
#include <iostream>


int main() {
	Lista lista;
	for (short int i = 1; i < 11; i++){
		lista.insertarAlFinal(i);
	}
	std::cout << lista.toString();
	lista.eliminar();
	std::cout << lista.toString();
	lista.eliminarAlFinal();
	std::cout << lista.toString();
	lista.eliminarEnPosicion(4);
	std::cout << lista.toString();
	lista.insertarEnPosicion(2,25);
	std::cout << lista.toString();
	return 0;
}