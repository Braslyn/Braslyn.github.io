#include "Gallinero.h"
#include <iostream>
Gallinero::Gallinero(int fila, int columna):cant(0){
	this->fila = fila;
	this->columna = columna;
	// ya tenemos el valor fila y la columna
	//----------------------M.D O.D--------------------------------------
	this->matriz1 = new Gallina **[fila];
	for (short int i = 0; i < fila; i++){
		this->matriz1[i] = new Gallina* [columna];
	}

	for (short int i = 0; i < fila; i++){// Fila -> Columna
		for (short int j = 0; j < columna; j++) {
			//LLenar la matriz
			this->matriz1[i][j] = nullptr;
		}
	}
	
	std::cout << "M.D O.D\n";
	for (short int i = 0; i < fila; i++) {// Fila -> Columna
		for (short int j = 0; j < columna; j++) {
			std::cout << matriz1[i][j] <<" ";
		}
		std::cout << "\n";
	}

	//--------------------M.D O.A-------------------------------
	std::cout << "\n";
	std::cout << "\n";
	
	this->matriz2 = new Gallina*[fila];
	for (short int i = 0; i < fila; i++) {
		this->matriz2[i] = new Gallina[columna];
		}
	std::cout << "M.D O.A\n";// esto no es parte del algoritmo
	for (short int i = 0; i < fila; i++) {// Fila -> Columna
		for (short int j = 0; j < columna; j++) {
			std::cout<< matriz2[i][j].toString() << " ";
		}
		std::cout << "\n";
	}

	//-------------------M.A O.D-----------------------
	std::cout << "\n";
	std::cout << "\n";
	
	for (short int i = 0; i < 2; i++) {// Fila -> Columna
		for (short int j = 0; j < 2; j++) {
			//LLenar la matriz
			this->matriz3[i][j] = nullptr;
		}
	}
	std::cout << "M.A O.D\n";// esta fuera del algoritmo
	for (short int i = 0; i < MAXFILAS; i++) {// Fila -> Columna
		for (short int j = 0; j < MAXCOLUMNAS; j++) {
			std::cout << matriz3[i][j] << " ";
		}
		std::cout << "\n";
	}
	std::cout << "\n";
	std::cout << "\n";
	// Doble automatico

	for (short int i = 0; i < MAXFILAS; i++) {// Fila -> Columna
		for (short int j = 0; j < MAXCOLUMNAS; j++) {
			std::cout << matriz4[i][j].toString() << " ";
		}
		std::cout << "\n";
	}


}

Gallinero::~Gallinero(){
	//----------------------M.D O.D--------------------------------------

	for (short int i = 0; i < fila; i++) {// Fila -> Columna
		for (short int j = 0; j < columna; j++) {
			delete this->matriz1[fila][columna];
		}
	}
	for (short int i = 0; i < fila; i++) {
		delete[] this->matriz1[i];
	}
	delete[] this->matriz1;
	this->matriz1 = nullptr;
	// Queda finalizado Doble dinamico
	// MD OA
	for (short int i = 0; i < fila; i++) {
		delete[] this->matriz2[i];
	}
	delete[] this->matriz2;
	this->matriz2 = nullptr;

	//queda terminado
	// MA OD
	for (short int i = 0; i < 2; i++) {// Fila -> Columna
		for (short int j = 0; j < 2; j++) {
			//LLenar la matriz
			delete this->matriz3[i][j];
		}
	}// queda terminado
}

void Gallinero::EliminarGallina(int fila, int columna){
	delete this->matriz1[fila][columna];
	this->matriz1[fila][columna] = nullptr;
	this->matriz3[fila][columna] = nullptr;
}

void Gallinero::AddGallina(int fila, int columna, Gallina* gallina){
	if (gallina != nullptr) {
		this->matriz1[fila][columna]= gallina;
		this->matriz2[fila][columna] = *gallina;
		this->matriz3[fila][columna] = gallina;
		this->matriz4[fila][columna] = *gallina;
		cant++;
	}
}



string Gallinero::toString(){
	std::stringstream out;
	out << "M.D O.D\n";
	for (short int i = 0; i < fila; i++) {// Fila -> Columna
		for (short int j = 0; j < columna; j++) {
			out << matriz1[i][j] << " ";
		}
		out << "\n";
	}
	out << "\n";
	out << "M.D O.A\n";
	for (short int i = 0; i < fila; i++) {// Fila -> Columna
		for (short int j = 0; j < columna; j++) {
			out << matriz2[i][j].toString() << " ";
		}
		out << "\n";
	}
	out << "\n";
	out << "M.A O.D\n";
	for (short int i = 0; i < MAXFILAS; i++) {// Fila -> Columna
		for (short int j = 0; j < MAXCOLUMNAS; j++) {
			out << matriz3[i][j] << " ";
		}
		out << "\n";
	}
	out << "\n";

	for (short int i = 0; i < MAXFILAS; i++) {// Fila -> Columna
		for (short int j = 0; j < MAXCOLUMNAS; j++) {
			out << matriz4[i][j].toString() << " ";
		}
		out << "\n";
	}

	return out.str();
}

void Gallinero::swap(int fila1, int column1, int fila2, int column2){
	Gallina* aux;

	aux = this->matriz1[fila1][column1];
	this->matriz1[fila1][column1]= this->matriz1[fila2][column2];
	this->matriz1[fila2][column2] = aux;

	aux = &this->matriz2[fila1][column1];
	this->matriz2[fila1][column1] = this->matriz2[fila2][column2];
	this->matriz2[fila2][column2] = *aux;

	aux = this->matriz3[fila1][column1];
	this->matriz3[fila1][column1] = this->matriz3[fila2][column2];
	this->matriz3[fila2][column2] = aux;

	aux = &this->matriz4[fila1][column1];
	this->matriz4[fila1][column1] = this->matriz4[fila2][column2];
	this->matriz4[fila2][column2] = *aux;
}
