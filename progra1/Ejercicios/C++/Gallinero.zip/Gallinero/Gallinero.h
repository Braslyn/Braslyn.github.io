#ifndef GALLINERO_H
#define GALLINERO_H
#include "Gallina.h"
#define MAXFILAS 2
#define MAXCOLUMNAS 2
class Gallinero
{
public:
	Gallinero(int fila=2,int columna=2);
	~Gallinero();
	void EliminarGallina(int fila,int columna);
	void AddGallina(int fila,int columna,Gallina* gallina);
	string toString();
	void swap(int fila1, int colum1, int fila2, int culmn2);
private:
	int fila;
	int columna;
	int cant;
	Gallina*** matriz1;// M. dinamica O.dinamica <------ por ahora solo existe esta
	Gallina** matriz2;// M. dinamica O. automaticos
	Gallina* matriz3[MAXFILAS][MAXCOLUMNAS];// M.M.automatica O.dinamicos
	Gallina matriz4[MAXFILAS][MAXCOLUMNAS];// M. automatica O. Automaticos
};

#endif // !GALLINERO_H
