#ifndef ILUSTRACION_H
#define ILUSTRACION_H

class Ilustracion
{
public:
	Ilustracion();
	~Ilustracion();

private:

};


#endif // !ILUSTRACION_H
