#include <iostream>
#include "Gallinero.h"
int main(){
    Gallinero gallinero(3,3);
    gallinero.AddGallina(0,0,new Gallina(2,2,"Paco","13/4/2020"));
    gallinero.AddGallina(0, 1, new Gallina(5, 10, "Anacleto", "22/4/2021"));
    gallinero.swap(0, 0, 1, 1);
    gallinero.EliminarGallina(1, 1);
    std::cout << "----------------------------------------------\n\n\n";
    std::cout << gallinero.toString();
    return 0;
}
