#include "Gallina.h"

Gallina::Gallina(int edad, int peso, string nombre,string fecha):edad(edad),peso(peso),nombre(nombre),fecha(new Fecha(fecha)){}

Gallina::~Gallina(){// PAso RTV
	delete fecha;
	fecha = nullptr;
}

int Gallina::getEdad(){
	return edad;
}

int Gallina::getPeso(){
	return peso;
}

string Gallina::getNombre(){
	return nombre;
}

string Gallina::toString(){
	std::stringstream out;
	out << " Nombre: " << nombre << " Peso: " << peso << " edad: " << edad<<"F.I"<<fecha->toString();
	return out.str();
}
