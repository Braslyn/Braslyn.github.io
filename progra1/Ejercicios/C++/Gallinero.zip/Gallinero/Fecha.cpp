#include "Fecha.h"

Fecha::Fecha(string fecha){
	dia= std::stoi(fecha.substr(0, 2));
	mes= std::stoi(fecha.substr(3, 5));
	a�o= std::stoi(fecha.substr(7, 9));
}

Fecha::~Fecha(){}

string Fecha::toString()
{
	std::stringstream out;
	out << dia << "/" << mes << "/" << a�o;
	return out.str();
}

bool Fecha::mayorque(Fecha& fecha){
	if (a�o <= fecha.a�o) {
		if (mes<=fecha.mes){
			if (dia<=fecha.dia)
			{
				return false;
			}

		}
	}
	return true;
}
