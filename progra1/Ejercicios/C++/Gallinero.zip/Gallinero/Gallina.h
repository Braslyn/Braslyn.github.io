#ifndef GALLINA_H
#define GALLINA_H
#include "Fecha.h"

class Gallina
{
public:
	Gallina(int edad=1, int peso=1, string nombre="Heiner",string fecha="28/1/1999");
	~Gallina();
	int getEdad();
	int getPeso();
	string getNombre();
	string toString();
private:
	int edad;
	int peso;
	string nombre;
	Fecha* fecha;// Composicion
};

#endif // !GALLINA_H

