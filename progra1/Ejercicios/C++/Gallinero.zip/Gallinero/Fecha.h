#ifndef FECHA_H
#define FECHA_H
#include <string>
#include <sstream>
using std::string;
class Fecha
{
public:
	Fecha(string fecha);
	~Fecha();
	string toString();
	bool mayorque(Fecha& fecha);

private:
	int dia;
	int mes;
	int a�o;
};

#endif // !FECHA_H
