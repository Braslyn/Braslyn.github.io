#include "ilustracion.h"

Ilustracion::Ilustracion(){
}

Ilustracion::~Ilustracion()
{
}
