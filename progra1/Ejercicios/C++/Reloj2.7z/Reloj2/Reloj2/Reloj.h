#ifndef RELOJ_H
#define RELOJ_H
#include "Hora.h"
#include "Minuto.h"
class Reloj{
public:
	Reloj(const char* hora);
	~Reloj();
	friend std::ostream& operator<<(std::ostream&, Reloj&);
	void avanzar();
private:
	Minuto* segundo;
	Minuto* minuto;
	Hora* hora;
	std::string tiempo;
};

#endif // !RELOJ__H
