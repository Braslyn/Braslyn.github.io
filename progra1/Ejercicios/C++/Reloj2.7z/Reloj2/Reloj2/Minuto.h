#ifndef MINUTO_H
#define MINUTO_H
#define MAX 60
#include <iostream>
class Minuto{
public:
	Minuto(short int);
	~Minuto();
	bool avanzar();
	friend std::ostream& operator<<(std::ostream&, Minuto* m);
private:
	short int count;
};
#endif // !MINUTO_H
