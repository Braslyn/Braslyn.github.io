#include "Hora.h"

Hora::Hora(short int mh, short int h):hora(h){
	switch (mh){
	case 1:
		max = 12;
		break;
	case 2:
		max = 24;
		break;
	default:
		max = 12;
		break;
	}
	if (hora > max || hora < 0)
		hora = 0;
}

bool Hora::avanzar(){
	if (++hora == max && militar()) {
		hora = 0;
		return true;
	}else if(hora==max+1){
		hora = 1;
		return true;
	}
	return false;
}



bool Hora::militar()
{
	return max>12;
}

Hora::~Hora(){}

std::ostream& operator<<(std::ostream& out, Hora* h){
	out << h->hora;
	return out;
}
