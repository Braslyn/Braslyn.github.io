#ifndef HORA_H
#define HORA_H
#include <iostream>
class Hora{
public:
	Hora(short int,short int);
	bool avanzar();
	bool militar();
	~Hora();
	friend std::ostream& operator<<(std::ostream&, Hora* h);
private:
	short int max;
	short int hora;
};
#endif // !HORA_H
