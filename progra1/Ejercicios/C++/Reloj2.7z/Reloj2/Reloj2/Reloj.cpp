#include "Reloj.h"

Reloj::Reloj(const char* hora){
	//inserte algoritmo que divida la hora 
	// 12:34:12 am por ej 
	//porque a su tutor le da pereza
	this->hora = new Hora(1, 11);
	minuto = new Minuto(59);
	segundo = new Minuto(50);
	tiempo = "am";
}

Reloj::~Reloj(){}

void Reloj::avanzar(){
	if (segundo->avanzar()){
		if (minuto->avanzar()){
			if (hora->avanzar()) {
				if (!hora->militar())
					tiempo = "am";//inserte conversion de am a pm
			}
		}
	}
}

std::ostream& operator<<(std::ostream& out, Reloj& r){
	out << r.hora <<":"<< r.minuto <<":"<<r.segundo <<" "<<r.tiempo;
	return out;
}
