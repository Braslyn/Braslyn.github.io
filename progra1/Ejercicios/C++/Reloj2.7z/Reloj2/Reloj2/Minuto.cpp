#include "Minuto.h"

Minuto::Minuto(short int m):count(m){
	if (m > 60 || m < 0)
		m = 0;
}

Minuto::~Minuto()
{
}

bool Minuto::avanzar() {
	if (++count == MAX) {
		count = 0;
		return true;
	}
	return false;
}

std::ostream& operator<<(std::ostream& out, Minuto* m){
	out << m->count;
	return out;
}
