#include "Reloj.h"
#include <Windows.h>

int main() {
	Reloj j = "11:59:50 am";
	while (true){
		std::cout << j;
		j.avanzar();
		Sleep(1000);
		system("cls");
	}
	return 0;
}