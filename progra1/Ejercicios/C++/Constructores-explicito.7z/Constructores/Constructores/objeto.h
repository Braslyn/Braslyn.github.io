#ifndef OBJETO_H
#define OBJETO_H
#include <string>
class Objeto{
public:
	explicit Objeto(const char*);
	~Objeto();
	const char* n;
};



#endif // !#OBJETO_H
