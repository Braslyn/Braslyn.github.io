#include "objeto.h"
#include <iostream>
int main() {
	Objeto b = Objeto("Gollo\n");//explicito
	Objeto b1("Gollo2");
	std::cout << b.n;
	std::cout << b1.n;
	return 0;
}