#include "objeto.h"



Objeto::Objeto(const char* n):n(n){}

Objeto::~Objeto(){}
