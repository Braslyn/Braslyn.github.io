#include "Parque.h"
#include <iostream>

int main() {
	Parque parque;
	Persona* persona = new Persona(402420750,"Braslyn",22);
	parque.personaTomaBanca(0,0,0,persona);
	persona = new Persona(402420751,"Heiner",23);
	parque.personaTomaBanca(0, 1, 0, persona);
	persona = new Persona(402420757, "Dominique", 23);
	parque.personaTomaBanca(0, 1, 1, persona);
	persona = new Persona(302540823,"Anacleto",50);
	parque.personaTomaBanca(1, 0, 0, persona);
	persona = new Persona(205240698,"Hermengilda",60);
	parque.personaTomaBanca(2, 2, 0, persona);
	persona = new Persona(102520365,"Paco",30); 
	parque.personaTomaBanca(2, 1, 0, persona);
	persona = new Persona(402420753,"Pipiolo",40);
	parque.personaTomaBanca(1, 2, 0, persona);
	std::cout << "Estado del parque\n";
	std::cout << parque.toString()<<"\n";
	std::cout << "Existe 402420750 en el parque\n";
	Persona* aux = parque.BuscarPersona(402420750);
	aux != nullptr ? std::cout << aux->toString()<<"\n" : std::cout << "No esta!\n";
	std::cout << "La banca de 402420751 tiene a\n";
	Banca* auxB = parque.bucarBancaPorPersona(402420751);
	auxB != nullptr ? std::cout << auxB->toString() << "\n" : std::cout << "No hay nadie en esa banca!\n";
	std::cout << "El promedio de edad en el parque es:"<<parque.promedioDeEdad();
	return 0;
}