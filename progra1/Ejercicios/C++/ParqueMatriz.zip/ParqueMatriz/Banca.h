#ifndef BANCA_H
#define BANCA_H
#include "Persona.h"
#define MAXASIENTOS 3
class Banca
{
public:
	Banca(int tam=MAXASIENTOS);
	~Banca();
	Persona* getPersonaPosicion(int pos);
	Persona* getPersonaID(int id);
	void setPersonaPosicion(int pos, Persona* persona);
	int promedioEdadBanca();
	std::string toString();
private:
	short int tamanio;
	short int cant;
	Persona** asientos;
};

#endif // !BANCA_H
