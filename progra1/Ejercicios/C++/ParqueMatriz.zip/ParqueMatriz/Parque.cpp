#include "Parque.h"

Parque::Parque(int fila, int columna):fila(fila),columna(columna),cant(0){
	this->bancas = new Banca **[fila];
	//[*|*|*]
	for (short int i = 0; i < fila; i++){
		this->bancas[i] = new Banca * [columna];
	}

	for (short fil = 0; fil < fila; fil++){
		for (short int  col = 0; col < columna; col++){
			this->bancas[fil][col] = new Banca(((fil+1)*(col+1))%4);
		}
	}
}

Parque::~Parque(){

	for (short fil = 0; fil < fila; fil++) {
		for (short int col = 0; col < columna; col++) {
			delete this->bancas[fil][col];
		}
	}
	for (short int i = 0; i < fila; i++) {
		delete[] this->bancas[i];
	}

	delete[] this->bancas;
}

void Parque::personaTomaBanca(int fila, int col,int pos, Persona* persona){
	cant++;
	this->bancas[fila][col]->setPersonaPosicion(pos,persona);
}

Persona* Parque::personaEnBanca(int fila, int col,int pos)
{
	return this->bancas[fila][col]->getPersonaPosicion(pos);
}

Persona* Parque::BuscarPersona(int id){
	Persona* aux=nullptr;
	for (short fil = 0; fil < fila; fil++) {
		for (short int col = 0; col < columna; col++) {
			aux=this->bancas[fil][col]->getPersonaID(id);

			if (aux!=nullptr){
				return aux;
			}
		}
	}

	return aux;
}

Banca* Parque::bucarBancaPorPersona(int id){
	Persona* aux = nullptr;
	for (short fil = 0; fil < fila; fil++) {
		for (short int col = 0; col < columna; col++) {
			aux = this->bancas[fil][col]->getPersonaID(id);

			if (aux != nullptr) {
				return this->bancas[fil][col];
			}
		}
	}

	return nullptr;
}

int Parque::promedioDeEdad(){
	int promedio = 0;
	int personas = 0;
	for (short fil = 0; fil < fila; fil++) {
		for (short int col = 0; col < columna; col++) {
			if (fil!=fila/2 || col!=columna/2){

				promedio += this->bancas[fil][col]->promedioEdadBanca();

			}
		}
	}
	return promedio/cant;
}

std::string Parque::toString()
{
	std::stringstream out;
	for (short fil = 0; fil < fila; fil++) {
		for (short int col = 0; col < columna; col++) {
			if (fil==fila/2&&col==columna/2){
				out << "Pozo Parque ";
			}else {
				out << this->bancas[fil][col]->toString() << " ";
			}
			
		}
		out << "\n";
	}
	return out.str();
}
