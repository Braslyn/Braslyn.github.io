#ifndef PARQUE_H
#define PARQUE_H
#include "Banca.h"

class Parque{
public:
	Parque(int fila=3,int columna=3);
	~Parque();
	void personaTomaBanca(int fila,int col,int pos,Persona* persona);
	Persona* personaEnBanca(int fila, int col,int pos);
	Persona* BuscarPersona(int id);
	Banca* bucarBancaPorPersona(int id);
	int promedioDeEdad();
	std::string toString();
private:
	short int fila;
	short int columna;
	short int cant;
	Banca*** bancas;
};

#endif // !PARQUE_H
