#include "Banca.h"

Banca::Banca(int tam):cant(0),tamanio(tam){
	if (tam<=0 && tam>MAXASIENTOS){
		this->tamanio = MAXASIENTOS;
	}
	this->asientos = new Persona*[tam];
	for (short int i = 0; i < tamanio; i++){
		this->asientos[i]=nullptr;
	}
}

Banca::~Banca(){
	for (short int i = 0; i < tamanio; i++){
		if (this->asientos[i] != nullptr)
			delete this->asientos[i];
	}
	delete[] this->asientos;
}

Persona* Banca::getPersonaPosicion(int pos){
	if (0<=pos && pos < tamanio)
		return this->asientos[pos];
	return nullptr;
}

Persona* Banca::getPersonaID(int id){
	for (short int i = 0; i < tamanio; i++) {
		if (this->asientos[i]!=nullptr){
			if (this->asientos[i]->getID() == id) {

				return this->asientos[i];
			}
		}
	}
	return nullptr;
}

void Banca::setPersonaPosicion(int pos, Persona* persona){
	if (0 <= pos && pos < tamanio)
		this->asientos[pos] = persona;
}

int Banca::promedioEdadBanca(){
	int promedio = 0;
	for (short int i = 0; i < tamanio; i++) {
		if (this->asientos[i] != nullptr) {
			promedio += this->asientos[i]->getEdad();
		}
	}
	return promedio;
}

std::string Banca::toString(){
	std::stringstream out;
	out << "[";
	for (short int i = 0; i < tamanio; i++){
		if (this->asientos[i] != nullptr)
		{
			out << this->asientos[i]->toString();
		}else {
			out << "vacio";
		}
		out << ",";
	}
	out << "\b";
	out<< "]";
	return out.str();
}
