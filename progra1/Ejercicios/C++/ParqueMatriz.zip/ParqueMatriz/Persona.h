#ifndef PERSONA_H
#define PERSONA_H
#include <string>
#include <sstream>

class Persona
{
public:
	Persona(int id,std::string nombre,int edad);
	~Persona();
	int getID();
	int getEdad();
	std::string getNombre();
	std::string toString();
private:
	int id;
	int edad;
	std::string nombre;
};


#endif // !PERSONA_H
