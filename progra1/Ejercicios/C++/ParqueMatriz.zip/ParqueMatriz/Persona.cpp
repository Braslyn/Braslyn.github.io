#include "Persona.h"

Persona::Persona(int id, std::string nombre,int edad):id(id),nombre(nombre),edad(edad){}


Persona::~Persona(){}

int Persona::getID()
{
	return id;
}

int Persona::getEdad(){
	return edad;
}

std::string Persona::getNombre()
{
	return nombre;
}

std::string Persona::toString(){
	std::stringstream out;
	out << "{" << id << "," << nombre << ","<<edad<<"}";
	return out.str();
}

