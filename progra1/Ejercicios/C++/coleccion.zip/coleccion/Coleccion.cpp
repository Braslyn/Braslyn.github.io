#include "Coleccion.h"

Coleccion::Coleccion(int tama�oMaximo):tama�oMaximo(tama�oMaximo),actual(0){
	//this->tama�oMaximo = tama�oMaximo; esto es valido tambien :D
	vector = new Persona*[tama�oMaximo];
	for (short int i = 0; i < tama�oMaximo; i++){
		vector[i] = nullptr;
		Vector2[i] = nullptr;
	}
}


Coleccion::~Coleccion(){
	for (short int i = 0; i < actual; i++){
		delete vector[i];
	}
	delete[] vector;
	vector = nullptr;
}

void Coleccion::add(Persona& persona){
	
	if (actual < tama�oMaximo) {
		//Vector2[++actual] = &persona;
		//----------------------------
		vector[actual++] = &persona;
	}else {
		//to do
		tama�oMaximo += 10;
		Persona** aux = new Persona * [tama�oMaximo];
		for (short int i = 0; i < tama�oMaximo; i++){
			if (i < actual) {
				aux[i] = vector[i];
			}else {
				aux[i] = nullptr;
			}
		}

	}
}

Persona* Coleccion::get(int index){
	if (0<=index && index<actual){
		return vector[index];
	}
	return nullptr;
}

Persona* Coleccion::MayorEdad(){
	Persona* mayor= vector[0];
	for (short int i = 1; i < actual; i++){
		
		if (*mayor->getEdad() < *vector[i]->getEdad())
			mayor = vector[i];
	}
	return mayor;
}												//actual 
Persona* Coleccion::MayorEdadRecursivo(Persona** vector,int max,Persona* mayor){
	if (max==0){
		return *vector[0]->getEdad()>*mayor->getEdad()? vector[0]: mayor;
	}
	return nullptr;
}



string Coleccion::toString(){
	std::stringstream out;
	out << "[";
	for (short int i = 0; i < actual; i++){
		out << vector[i]->toString()<<",";
	}
	out << "]";
	return out.str();
}

void Coleccion::swap(int index, int index2){
	Persona* aux=vector[index2];
	vector[index2] = vector[index];
	vector[index] = aux;
}
