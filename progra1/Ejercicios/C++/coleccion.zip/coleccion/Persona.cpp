#include "Persona.h"

Persona::Persona(string cedula, std::string nombre, int* edad):cedula(cedula),nombre(nombre),edad(edad){}

Persona::~Persona(){
	if (edad!=nullptr){
		delete edad;
		edad = nullptr;
	}
}

string Persona::getCedula()
{
	return cedula;
}

string Persona::getNombre()
{
	return nombre;
}

int* Persona::getEdad()
{
	
	return edad;
}

string Persona::toString(){
	std::stringstream out;
	out << "Cedula: "<<cedula<<" Nombre: "<<nombre<<" Edad: "<<*edad<<"\n";
	return out.str();
}
