#ifndef COLECCION_H
#define COLECCION_H
#include "Persona.h"
#define MAX 10

class Coleccion {
public:
	Coleccion(int tama�oMaximo=MAX);
	~Coleccion();
	void add(Persona& persona);
	Persona* get(int index);
	Persona* MayorEdad();
	Persona* MayorEdadRecursivo(Persona** vector,int max,Persona* mayor);
	string toString();
private:
	void swap(int index, int index2);
	int tama�oMaximo;
	int actual;
	Persona** vector;
	Persona* Vector2[MAX];
};

#endif // !COLECCION_H
