// coleccion.cpp : Este archivo contiene la función "main". La ejecución del programa comienza y termina ahí.
//


int SumarhastaCero(int numero) {
	if (numero == 0) {
		return 0;
	}
	return numero + SumarhastaCero(numero-1);//caso principal
}



#include "Coleccion.h"
int main(){
	Coleccion L;
	L.add(*new Persona("402420750","Braslyn",new int(22)));
	L.add(*new Persona("402420751","Paco",new int(50)));
	L.add(*new Persona("402420752","Anacleto", new int(35)));
	L.add(*new Persona("402410623","Heiner",new int(23)));
	std::cout << L.toString()<<"\n";
	std::cout <<"El mayor es: "<<L.MayorEdad()->toString()<<"\n";
	std::cout << "Recursividad hasta cero(5) = " << SumarhastaCero(5);
	return 0;
}
