#ifndef PERSONA_H
#define PERSONA_H
#include <string>
#include <sstream>
#include <iostream>
using std::string;

class Persona
{
public:
	Persona(string cedula="402420750",std::string nombre="Braslyn",int* edad=nullptr);
	~Persona();
	string getCedula();
	string getNombre();
	int* getEdad();
	string toString();
private:
	std::string cedula;
	std::string nombre;
	int* edad;
	//fecha ---> puntero
};


#endif // !PERSONA_H
