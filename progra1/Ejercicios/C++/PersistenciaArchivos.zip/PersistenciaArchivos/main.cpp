#include "Personas.h"
#include <iostream>
#include <vector>
#include <sstream>

int main(int arg, char* args[]) { //[dir,arg1,arg2,..,argN]
	std::vector<Persona*> lista;
	Persona* p= nullptr;
	// in out ifstream \r ofstream \w
	if (arg >=2) {
		if (std::atoi(args[1]) == 0) {
			delete p;
			std::ifstream archivo("Persona.txt", std::ios::in);
			int cantidad=0;
			if (archivo.good()) {
				archivo >> cantidad;
				for (int i = 0; i < cantidad; i++)
					lista.push_back(new Persona(archivo));
			}
			archivo.close();
			for (auto aux : lista) {
				std::cout << aux->toString();
			}
		}else { // Aqui vamos a realizar la escritura de personas segun el usuario
			std::ofstream archivo("Persona.txt", std::ios::out);
			int cantidad;
			int edad, cedula;
			std::string informacion,nombre;
			
			std::cout << "Cuantas personas desea digitar\n";
			std::cin >> cantidad;
			std::cin.ignore();
			while (cantidad-->0){
				std::cout << "Digite a la persona en el siguiente formato \n(cedula) (nombre) (edad)\n";
				std::getline(std::cin, informacion, '\n');
				std::stringstream info(informacion);
				info >> cedula;
				info >> nombre;
				info >> edad;
				lista.push_back(new Persona(cedula,nombre,edad));
			}
			archivo << lista.size() << "\n";
			for (auto aux : lista) {
				archivo << aux->toFile();
			}
			archivo.close();
		}
	}
	else
		std::cout << "No ingreso un parametro para indicar que operacion es solicitada";
	return 0;
}