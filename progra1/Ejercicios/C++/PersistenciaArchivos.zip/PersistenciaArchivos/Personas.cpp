#include "Personas.h"
#include <sstream>
Persona::Persona(int cedula, std::string nombre, int edad):cedula(cedula),nombre(nombre),edad(edad){}

Persona::Persona(std::ifstream& archivo){
	cedula = 0;
	edad = 0;
	archivo >> cedula;
	archivo >> nombre;
	archivo >> edad;
}

Persona::~Persona(){}

int Persona::getCedula()
{
	return cedula;
}

std::string Persona::getNombre()
{
	return nombre;
}

int Persona::getEdad()
{
	return edad;
}

std::string Persona::toString(){
	std::stringstream out;
	out << "Cedula: "<<cedula << " Nombre: "<<nombre << " Edad: "<<edad<<"\n";
	return out.str();
}

std::string Persona::toFile(){
	std::stringstream out; //cedula nombre edad\n
	out << cedula << " " << nombre << " " << edad << "\n";
	return out.str();
}
