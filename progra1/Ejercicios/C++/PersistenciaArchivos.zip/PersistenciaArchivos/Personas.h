#ifndef PERSONAS_H
#define PERSONAS_H
#include <string>
#include <fstream>// archivos
class Persona
{
public:
	Persona(int cedula,std::string nombre,int edad);
	Persona(std::ifstream& nombreArchivo);
	~Persona();
	int getCedula();
	std::string getNombre();
	int getEdad();
	std::string toString();
	std::string toFile();
private:
	int cedula;
	std::string nombre;
	int edad;
};


#endif // !PERSONAS_H
