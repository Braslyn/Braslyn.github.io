
#include "Oficina.h"
#include "Planta.h"
#include <iostream>
int main() {
	// Una persona administra otra persona que tiene una oficina o IT, 
	//dentro de esa tambien administras personas de planta

	Persona Jefe(402420750,"Braslyn",new Oficina(1000,"Vigila",6,"Negocio"));
	dynamic_cast<Oficina*>(Jefe.getPuesto())->insertarTrabajador(new Persona(402420751, "Hermenegilda", new Planta(200,"Manzanas",8)));
	dynamic_cast<Oficina*>(Jefe.getPuesto())->insertarTrabajador(new Persona(402420751, "Pinocho", new Planta(100, "Pinias", 8)));
	dynamic_cast<Oficina*>(Jefe.getPuesto())->insertarTrabajador(new Persona(402420751, "Anacleto", new Planta(150, "Peras", 8)));
	std::cout << "Informacion de Jefe:" << Jefe.toString();
	std::cout << "Salario a pagar:" << Jefe.getPuesto()->getSalario();
	
	return 0;
}