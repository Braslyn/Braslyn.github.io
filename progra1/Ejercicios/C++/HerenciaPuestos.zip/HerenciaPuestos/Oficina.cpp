#include "Oficina.h"

Oficina::Oficina(double salario, std::string descripcion, int horas,std::string nombre):Gerencia(salario,descripcion,horas),nombre(nombre){
}

Oficina::~Oficina()
{
}

std::string Oficina::getNombre()
{
	return nombre;
}

std::string Oficina::toString()
{
	std::stringstream out;
	out << "\nDescripcion: " << descripcion << "\nSalario: " << salario << "\nHoras: " << horas<<"\n";
	out << "Esta encargado de:\n";
	for (int i = 0; i < lista.getCant(); i++)
	{
		out << lista.Obtener(i)->toString()<<"\n";
	}
	return out.str();
}
