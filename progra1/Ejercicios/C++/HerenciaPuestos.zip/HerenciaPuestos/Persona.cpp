#include "Persona.h"

Persona::Persona(int id, std::string nombre, Puesto* puesto):id(id),nombre(nombre),puesto(puesto){}

Persona::~Persona(){
	delete puesto;
}

int Persona::getID()
{
	return id;
}

std::string Persona::getNombre()
{
	return nombre;
}
std::string Persona::toString(){
	std::stringstream out;
	out << "ID:" << id << "\nNombre: " << nombre << "Puesto:\n" << puesto->toString();
	return out.str();
}
Puesto* Persona::getPuesto(){
	return puesto;
}
