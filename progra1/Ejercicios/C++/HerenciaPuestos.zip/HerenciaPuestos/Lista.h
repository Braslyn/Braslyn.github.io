#ifndef LISTA_H
#define LISTA_H
#include <string>
#include <sstream>
#include "Persona.h"

struct Nodo {// por defecto el es publico
	Persona* valor;
	Nodo* siguiente;          // si no hay nodo siguiente entonces nullptr
	Nodo(Persona& valor, Nodo* siguiente = nullptr) :valor(&valor), siguiente(siguiente) {}
	// valor se quiera ingresar
};

class Lista
{
public:
	Lista();
	void insertar(Persona& numero);
	void insertarAlFinal(Persona& numero);
	void insertarEnPosicion(int posicion, Persona& numero);
	void eliminarEnPosicion(int posicion);
	int getCant();// n -> constante
	void eliminar();
	void invertir();
	void eliminarAlFinal();
	Persona* Obtener(int posicion);
	Persona* Buscar(std::string nombre);//que?
	void borrarTodo();
	int promedio();
	bool esVacio();
	void ordenar();// hay que definir a razon de que
	std::string toString();
	~Lista();
private:
	void intercambio(int pos1, int pos2);
	Nodo* ObtenerNodo(int posicion);
	Nodo* root;//en un inicio deberia ser nullptr
	int cant;
};


#endif // !LISTA_H

