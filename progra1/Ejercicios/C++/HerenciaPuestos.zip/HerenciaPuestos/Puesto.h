#ifndef PUESTO_H
#define PUESTO_H
#include <string>
#include <sstream>
class Puesto{  //interfaces metodos virtuales puros
public:
	Puesto(double salario,std::string descripcion,int horas);
	virtual ~Puesto();
	virtual double getSalario();
	std::string getDescripcion();
	int getHoras();
	virtual std::string toString() = 0; 
protected:
	std::string descripcion;
	double salario;
	int horas;
};

#endif // !PUESTO_H
