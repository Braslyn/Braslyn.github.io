#include "Gerencia.h"

Gerencia::Gerencia(double salario, std::string descripcion, int horas):Puesto(salario,descripcion,horas){
}

Gerencia::~Gerencia(){
	
}

void Gerencia::insertarTrabajador(Persona* persona){
	lista.insertarAlFinal(*persona);
}

double Gerencia::getSalario()
{
	double suma = 0.0;
	for (int i = 0; i < lista.getCant(); i++)
	{
		suma += lista.Obtener(i)->getPuesto()->getSalario();
	}
	return suma;
}