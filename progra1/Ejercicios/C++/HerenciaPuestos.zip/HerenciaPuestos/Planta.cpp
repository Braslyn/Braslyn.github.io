#include "Planta.h"

Planta::Planta(double salario, std::string descripcion, int horas):Puesto(salario,descripcion,horas){
}

Planta::~Planta(){}

std::string Planta::Trabajar()
{
	return "Trabajando";
}

std::string Planta::toString()
{
	std::stringstream out;
	out << "\nDescripcion: " << descripcion << "\nSalario:" << salario << "\nHoras:" << horas;
	return out.str();
}
