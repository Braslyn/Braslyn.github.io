#include "Puesto.h"

Puesto::Puesto(double salario, std::string descripcion, int horas):salario(salario),descripcion(descripcion),horas(horas){}

Puesto::~Puesto(){}

double Puesto::getSalario(){
	return salario;
}

std::string Puesto::getDescripcion(){
	return descripcion;
}

int Puesto::getHoras()
{
	return horas;
}
