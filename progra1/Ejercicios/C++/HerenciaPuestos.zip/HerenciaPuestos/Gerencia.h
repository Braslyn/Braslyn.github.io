#ifndef GERENCIA_H
#define GERENCIA_H
#include "Lista.h"


class Gerencia: public Puesto{
public:
	Gerencia(double salario, std::string descripcion, int horas);
	virtual ~Gerencia();
	void insertarTrabajador(Persona* persona);
	double getSalario();
	virtual std::string toString() = 0;
protected:
	Lista lista;
};
#endif // !GERENCIA_H
