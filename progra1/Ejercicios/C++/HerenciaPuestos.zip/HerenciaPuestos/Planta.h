#ifndef PLANTA_H
#define PLANTA_H
#include "Puesto.h"
class Planta: public Puesto{
public:
	Planta(double salario, std::string descripcion, int horas);
	~Planta();
	std::string Trabajar();
	std::string toString();
};

#endif // !PLANTA_H
