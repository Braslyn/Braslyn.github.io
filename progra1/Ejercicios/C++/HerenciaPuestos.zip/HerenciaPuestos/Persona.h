#ifndef PERSONA_H
#define PERSONA_H
#include <string>
#include <sstream>
#include "Puesto.h"
class Persona{
public:
	Persona(int id,std::string nombre,Puesto* puesto);
	~Persona();
	int getID();
	std::string getNombre();
	std::string toString();
	Puesto* getPuesto();
private:
	int id;
	std::string nombre;
	Puesto* puesto;
};


#endif // !PERSONA_H
