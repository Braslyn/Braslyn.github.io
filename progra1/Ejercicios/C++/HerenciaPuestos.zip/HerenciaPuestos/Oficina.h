#ifndef OFICINA_H
#define OFICINA_H
#include "Gerencia.h"

class Oficina: public Gerencia{
public:
	Oficina(double salario, std::string descripcion, int horas,std::string nombre);
	~Oficina();
	std::string getNombre();
	std::string toString();
private:
	std::string nombre;
};
#endif // !OFICINA_H
