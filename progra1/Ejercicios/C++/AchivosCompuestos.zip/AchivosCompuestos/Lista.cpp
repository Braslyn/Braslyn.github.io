#include "Lista.h"

Lista::Lista() :root(nullptr), cant(0) {}

Lista::Lista(std::string fileName) : root(nullptr), cant(0){
	std::ifstream archivo(fileName+".txt", std::ios::in);
	if (archivo.good()) {
		int cant = 0;
		archivo >> cant;
		for (int i = 0; i < cant; i++) {
			this->insertarAlFinal(*new Persona(archivo));
		}
	}
}

void Lista::insertar(Persona& numero) {//inicio es la m�s facil(Gano), insertar al final.
	Nodo* nuevo = new Nodo(numero, root);// ya tenemos el numero adentro del nodo
	root->anterior = nuevo;
	//nuevo->siguiente = root;// le pregunto al primero. se coloca detras
	root = nuevo; // se convierte en el nuevo primero
	cant++;
}

void Lista::insertarAlFinal(Persona& numero) {// primero si no hay elementos -- hay elementos
	Nodo* nuevo = new Nodo(numero);
	if (this->esVacio()) {
		nuevo->anterior = root;
		root = nuevo;
		cant++;
	}
	else {
		Nodo* aux = root;
		while (aux->siguiente != nullptr) {
			aux = aux->siguiente;
		}
		nuevo->anterior = aux;
		aux->siguiente = nuevo;
		cant++;
	}

}

void Lista::insertarEnPosicion(int posicion, Persona& numero) {
	Nodo* nuevo = new Nodo(numero);
	Nodo* aux = root;
	if (posicion < 1) {
		nuevo->siguiente = root;
		root = nuevo;
	}
	else {
		for (int i = 0; i < posicion; i++) {
			aux = aux->siguiente;
		}
		nuevo->siguiente = aux->siguiente;
		aux->siguiente = nuevo;
	}
}

void Lista::eliminarEnPosicion(int posicion) {
	Nodo* aux = root;
	Nodo* anterior = aux;
	if (posicion < 1) {
		root = root->siguiente;
		delete aux;
	}
	else {
		for (int i = 0; i < posicion; i++) {
			anterior = aux;
			aux = aux->siguiente;
		}
		anterior->siguiente = aux->siguiente;
		delete aux;
	}
	cant--;
}

int Lista::getCant() {
	return cant;
}

void Lista::eliminar() {// eliminar al inicio
	if (!this->esVacio()) {
		Nodo* aux = root;
		root = root->siguiente;
		delete aux;
		cant--;
	}
}

void Lista::invertir() {
	if (!esVacio()) {
		Nodo* anterior = nullptr, * siguiente = root, * actual = nullptr;
		while (siguiente != nullptr) {
			actual = siguiente;
			siguiente = siguiente->siguiente;
			actual->siguiente = anterior;
			anterior = actual;
		}
		root = actual;
	}
}

void Lista::eliminarAlFinal() {
	Nodo* aux = root;
	Nodo* anterior = aux;
	if (!this->esVacio()) {
		while (aux->siguiente != nullptr) {// si termina, estamos en el ultimo
			anterior = aux;
			aux = aux->siguiente;
		}
		if (aux == root) {
			delete root;
			root = nullptr;
		}
		else {
			anterior->siguiente = nullptr;
			delete aux;
		}
		cant--;
	}
}


Persona* Lista::Obtener(int posicion) {// quedre a razon del primero que se inserto, el primero es el primero(Gano);
	Nodo* aux;// el esta pensado para tomar el correspiente y devolver el dato
	aux = root;
	while (posicion > 0) {
		aux = aux->siguiente;
		posicion--;
	}
	return aux->valor;// falto algo importante , no valide si posicion es valida;
}

Persona* Lista::Buscar(std::string nombre)
{
	Persona* out;
	Nodo* aux;// el esta pensado para tomar el correspiente y devolver el dato
	aux = root;
	while (aux->siguiente != nullptr) {
		if (aux->valor->getNombre() == nombre)
			return aux->valor;
		aux = aux->siguiente;
	}
	return nullptr;
}

void Lista::borrarTodo() {
	Nodo* primero;
	while (!esVacio()) {
		primero = root;
		root = root->siguiente;
		delete primero;
	}
}

int Lista::promedio() {
	int promedio = 0;
	Nodo* aux = root;
	while (aux != nullptr) {
		promedio += aux->valor->getEdad();
		aux = aux->siguiente;
	}
	return promedio / cant;
}

bool Lista::esVacio() {
	return root == nullptr;
}

void Lista::ordenar() {
	Nodo* aux1 = nullptr, * aux2 = nullptr;
	for (int i = 0; i < this->cant; i++) {
		for (int j = 0; j < this->cant; j++) {
			aux1 = this->ObtenerNodo(i);
			aux2 = this->ObtenerNodo(j);
			if (aux1->valor->getEdad() < aux2->valor->getEdad()) {
				this->intercambio(i, j);
			}
		}
	}

}

void Lista::guardar(std::string nombre){
	std::ofstream archivo(nombre + ".txt",std::ios::out);
	archivo << cant<<"\n";
	Nodo* aux = root;
	for (int i = 0; i < cant; i++){
		root->valor->guardar(archivo);
	}
	archivo.close();
}

std::string Lista::toString() {
	std::stringstream out;
	out << "[";
	Nodo* aux = root;
	for (int i = 0; i < cant; i++) {
		out << aux->valor->toString();
		if (i < cant - 1) {
			out << ",";
		}
		aux = aux->siguiente;
	}
	out << "]\n";
	return out.str();
}

Lista::~Lista() {
	this->borrarTodo();
}

void Lista::intercambio(int pos1, int pos2) {
	Persona* aux = nullptr;
	Nodo* primero = ObtenerNodo(pos1), * segundo = ObtenerNodo(pos2);
	aux = primero->valor;
	primero->valor = segundo->valor;
	segundo->valor = aux;
}

Nodo* Lista::ObtenerNodo(int posicion)
{
	Nodo* aux;// el esta pensado para tomar el correspiente y devolver el dato
	aux = root;
	while (posicion > 0) {
		aux = aux->siguiente;
		posicion--;
	}
	return aux;// falto algo importante , no valide si posicion es valida;
}
