#include "Persona.h"

Persona::Persona(std::string nombre, int edad, string fecha) : nombre(nombre), edad(edad),fecha(new Fecha(fecha)){
}

Persona::Persona(std::ifstream& archivo):nombre(""),edad(0) {
	archivo >> nombre;
	archivo >> edad;
	fecha = new Fecha(archivo);
}

std::string Persona::getNombre()
{
	return nombre;
}

int Persona::getEdad()
{
	return edad;
}

Fecha* Persona::getFecha(){
	return fecha;
}

void Persona::guardar(std::ofstream& archivo){
	archivo << nombre << " " << edad << " "<<fecha->toString()<<"\n";
}

std::string Persona::toString() {
	std::stringstream out;
	out << "{nombre:" << nombre << ", Edad:" << edad << ", fecha:"<<fecha->toString() << "}";
	return out.str();
}

Persona::~Persona() {
	delete fecha;
}
