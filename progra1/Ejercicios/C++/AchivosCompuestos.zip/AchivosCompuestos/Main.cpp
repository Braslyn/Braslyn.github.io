#include "Lista.h"
#include <iostream>
#include <Windows.h>

int main(int arg, char* args[]){
	const char* fileName = arg < 2 ? "default" : args[1];
	std::string linea, valor[3];
	Lista listado(fileName);
	bool salir = false;
	char menu = ' ';
	std::cout << "Bienvenido al menu de Vacunacion\n";
	system("pause");
	while (!salir){
		system("cls");
		std::cout << "(I)ngresar Persona vacunada\n(M)ostrar Listado\n(L)impiar listado\n(S)alir\n-->";
		std::cin >> menu;
		std::cin.clear();
		switch (menu){
		case 'I':
		case 'i':{
			system("cls");
			std::cout << "Ingrese el nombre,edad,fecha\n";
			std::cin>>linea;
			std::stringstream out(linea);
			std::getline(out, valor[0], ',');
			std::getline(out, valor[1], ',');
			std::getline(out, valor[2], '\n');
			listado.insertarAlFinal(*new Persona(valor[0], std::stoi(valor[1]),valor[2]));
			listado.guardar(fileName);
			std::cout << "Insertado!!\n";
			system("pause");
		}
		break;
		case 'M':
		case 'm':
			system("cls");
			std::cout << listado.toString();
			system("pause");
			break;
		case 'L':
		case 'l':
			system("cls");
			listado.borrarTodo();
			listado.guardar(fileName);
			std::cout << "Borrado!!";
			system("pause");
			break;
		case 'S':
		case 's':
			system("cls");
			salir = !salir;
			std::cout << "Adios ;b \n";
			system("pause");
			break;
		default:
			system("cls");
			std::cout << "Opcion invalida\n";
			system("pause");
			break;
		}
	}
	return 0;
}