#ifndef PERSONA_H
#define PERSONA_H
#include "Fecha.h"

class Persona
{
public:
	Persona(std::string nombre, int edad,string fecha);
	Persona(std::ifstream& archivo);
	std::string getNombre();
	int getEdad();
	Fecha* getFecha();
	void guardar(std::ofstream& archivo);
	std::string toString();
	~Persona();

private:
	Fecha* fecha;
	std::string nombre;
	int edad;
};


#endif // !PERSONA_H
